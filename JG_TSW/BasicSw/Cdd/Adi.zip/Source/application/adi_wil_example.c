/**************************************************************************************************
 * @warning  This project is example code, user must ensure functionality before migration
 *
 * @brief    wBMS basic example code for IFX TC387 + ADRF8850 + ADRF8800 + (ADBMS6833 or ADBMS6830)
 * @version  ADK v1.9.21
 *
 * @remark   [Preparation]
 *            1. adi_wil_example_debug_function.h : 
 *               1) ADK_SPI_0 = define QSPI_x channel for SPI0_MASTER
 *               2) ADK_SPI_1 = define QSPI_x channel for SPI1_MASTER
 *               3) ADK_SPI_SPEED = Reserved, Now SPI speed has been fixed to 1Mhz
 *               4) ADK_ADBMS683x = define BMIC
 *            2. adi_wil_example_config.h : 
 *               1) ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL = BMS packet number per interval
 *                  This parameter depends on ADRF88xx configuration and container
 *                  In this example project, it is 3
 *            3. Check HAL driver configuration
 *               1) User must check all HAL driver configurations before build except osal
 *               2) Basically all HAL drivers are working when this example runs only
 *            4. Check configuration_files
 *               1) User must check ADRF88xx configuration based on their wBMS system
 *               2) Example configuration is under Tools.zip
 *            5. Check container_files
 *               1) User must check ADRF88xx container based on their wBMS system
 *               2) Example container is under Tools.zip
 *            6. OP FW must be downloaded to all managers and nodes
 *               1) This step should be done by external JTAG for all ADRF88xx
 *               2) OP FW 1.1.5 is used for this project
 *            7. adi_wil_example_acl.c :
 *               1) userAcl.iCount = number of nodes
 *               2) userAcl.Data = array of MAC address for all nodes
 * 
 * @details  [Display]    : "ADK_DEMO" structure
 * 
 * @details  [User input] : ADK_DEMO.DEMO_MODE
 *                        = 0 (NORMAL_BMS_SENSING)
 *                        = 1 (CELL_BALANCING_EVEN)
 *                        = 2 (CELL_BALANCING_ODD)
 *                        = 3 (OPEN_WIRE_DETECTION) --> Reserved, DO NOT USE
 *                        = 4 (KEY_ON_EVENT)
 *                        = 5 (KEY_OFF_EVENT)
 * 
 * @details  [Available wBMS function list (Available DEMO_MODE)] 
 *            1. Cell voltage read (0, 1, 2, 3, 4)
 *            2. PDR calculation (0, 1, 2, 3, 4)
 *            3. RSSI calculation (0, 1, 2, 3, 4)
 *            4. Aux channel voltage read for temp. sensor (0, 1, 2, 3, 4)
 *            5. Cell balancing (1, 2)
 *            6. Open wire detection (0, 1, 2, 3, 4)
 * 
 * @date     2022.09.27
 * @author   Analog Devices Korea Software FAE Team
 *
 * Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
 * This software is proprietary and confidential to Analog Devices, Inc. and its licensors.
**************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "adi_wil.h"
#include "adi_wil_example_app_version.h"
#include "adi_wil_example_config.h"
#include "adi_wil_example_utilities.h"
#include "adi_wil_example_functions.h"
#include "adi_wil_example_printf.h"
#include "adi_wil_example_acl.h"
#include "adi_wil_example_version.h"
#include "adi_wil_example_scheduler.h"
#include "adi_wil_example_cell_balance.h"
#include "adi_wil_example_owd.h"
#include "adi_bms_defs.h"
#include "adi_wil_hal_ticker.h"
#include "adi_wil_example_debug_functions.h"
#include "adi_wil_example_cfg_profiles.h"

#if 1 // for SPI test
#include "Cmic_Conf.h"
#endif

/******************************************************************************************/
/* Global Function Declarations                                                           */
/******************************************************************************************/
extern bool adi_wil_example_PeriodicallyCallProcessTask(void);
extern void adk_debug_Report(ADK_FAIL_API_NAME api, adi_wil_err_t rc );
extern void adk_debug_BootTimeLog(bool final, bool start, uint16_t step, ADK_LOG_FUNCTION api);
bool adi_wil_example_PeriodicallyCallProcessTaskCB(void);
extern uint32_t adi_wil_hal_TickerGetTimestamp(void);
extern void WaitForWilAPI(adi_wil_pack_t * const pPack);
extern adi_wil_err_t adi_wil_example_RetrySetMode(adi_wil_pack_t * const pPack, adi_wil_mode_t mode);
extern void Test_Spi_Hal_0(void);
extern void Test_Spi_Hal_1(void);
extern void adk_debug_log_GetDeviceVersion(ADK_OTAP_ARG_0 eDeviceID, ADK_OTAP_ARG_1 update, uint8_t idx);
extern void adi_wil_hal_TaskStop(void);

/******************************************************************************************/
/* Global Structure Declarations                                                          */
/******************************************************************************************/
extern DISPLAYSTR ADK_DEMO;
BOOTTIMESTR BOOT_TIME;
uint16_t G_BOOT_TIME_CNT = 1;
extern adi_wil_err_t gNotifRc;

/******************************************************************************************/
/* Global Variable Declarations                                                */
/******************************************************************************************/
extern volatile uint8_t iMgrConnectCount;
bool adi_gNotifyBms;
bool adi_gNotifyBmsData;
bool adi_gNotifyPms;
bool adi_gNotifyEms;
bool adi_gNotifyNetworkMeta;
volatile adi_wil_err_t adi_gProcessTaskErrorCode = ADI_WIL_ERR_SUCCESS;
adi_wil_network_status_t networkStatus;
adi_wil_network_data_t   networkDataBuffer[ADI_WIL_MAX_NODES*ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL];
adi_wil_pack_t packInstance; /* pack instance object */
adi_wil_acl_t realAcl;
#ifdef DBG_ACL_MAP_TEST
bool userAcl_map[ADK_MAX_node] = {false,};
bool realAcl_map[ADK_MAX_node] = {false,};
#endif

uint8_t gTotalNodes       = 0u;        /* @remark Variable to store total no. of Nodes in network */
bool gQueryDeviceRetry    = false;     /* @remark request by sure-soft */
extern uint8_t Spi_TxData_0[256];
extern uint8_t Spi_TxData_1[256];
uint8_t Test_RxData_0[256];
uint8_t Test_RxData_1[256];
extern bool ACL_EMPTY;

#if 1 // @SURE - ADDED
static ADK_DEMO_TYPE ADK_DEMO_MODE = NORMAL_BMS_SENSING;

extern bool CmicComm_GetSpiState(void);
#endif

/******************************************************************************************/
/* Local Variable Declarations                                                            */
/******************************************************************************************/
static adi_wil_sensor_data_t  wbmsSysSensorData[BMS_DATA_PACKET_COUNT + PMS_DATA_PACKET_COUNT + EMS_DATA_PACKET_COUNT];
static adi_wil_port_t portVar[PORT_COUNT];
static adi_wil_configuration_t portConfig[PORT_COUNT];

#if (CMIC_CONF_ONLY_SPI_TEST) // for SPI test
#include "wb_rsp_query_device.h"

#define TOTAL_ITER_TO_RUN               10   // Number of times to run the SPI test
uint8_t Spi_TxData_0[256];
static uint8_t Spi_RxData_0[256];
uint32_t Spi_TxData_0_Count = 0;
uint8_t Spi_TxData_1[256];
static uint8_t Spi_RxData_1[256];
uint32_t Spi_TxData_1_Count = 0;
static struct  wbms_cmd_resp_query_device_t QueryDeviceResp_0;
static struct  wbms_cmd_resp_query_device_t QueryDeviceResp_1;
static uint8_t Spi0_step = 0;
static uint8_t Spi1_step = 0;

void Spi_TxCompleteCbk_0(uint8_t iSPIDevice, uint8_t iChipSelect)
{
    if(Spi_RxData_0[0] == 0x3b && Spi_RxData_0[1] == 0xff && Spi_RxData_0[4] == 0x7F)
    {
        memcpy(&QueryDeviceResp_0, &Spi_RxData_0[6], sizeof(struct wbms_cmd_resp_query_device_t));
    }
}

void Spi_TxCompleteCbk_1(uint8_t iSPIDevice, uint8_t iChipSelect)
{
    if(Spi_RxData_1[0] == 0x3b && Spi_RxData_1[1] == 0xff && Spi_RxData_1[4] == 0x7F)
    {
        memcpy(&QueryDeviceResp_1, &Spi_RxData_1[6], sizeof(struct wbms_cmd_resp_query_device_t));
    }
}

void Test_Spi_Hal_0(void)
{
    int i = 0;

    memset(&Spi_TxData_0[0], 0, 256);

#if 0
    static int xxx = 0;
    if(xxx == 0)
    {
        xxx = 1;
        Spi_TxData_0[0]   = 0x00;
        Spi_TxData_0[1]   = 0xFF;
    }
    else
    {
        xxx = 0;
        Spi_TxData_0[0]   = 0x04;
        Spi_TxData_0[1]   = 0xFF;
        Spi_TxData_0[2]   = 0x00;
        Spi_TxData_0[3]   = 0x00;
        Spi_TxData_0[4]   = 0x7F;
        Spi_TxData_0[5]   = 0x02;

        Spi_TxData_0[252] = 0xD6;
        Spi_TxData_0[253] = 0xEC;
        Spi_TxData_0[254] = 0x8B;
        Spi_TxData_0[255] = 0x01;
    }

    Spi_TxData_0_Count++;
#else
    // query devices
    if(Spi0_step == 0)
    {
        Spi_TxData_0[0]   = 0x04;
        Spi_TxData_0[1]   = 0xFF;
        Spi_TxData_0[2]   = 0x00;
        Spi_TxData_0[3]   = 0x00;
        Spi_TxData_0[4]   = 0x7F;
        Spi_TxData_0[5]   = 0x02;

        Spi_TxData_0[252] = 0xD6;
        Spi_TxData_0[253] = 0xEC;
        Spi_TxData_0[254] = 0x8B;
        Spi_TxData_0[255] = 0x01;
    }
    else if(Spi0_step == 1)
    {
        // connect nodes
        Spi_TxData_0[0]   = 0x05;
        Spi_TxData_0[1]   = 0xFF;
        Spi_TxData_0[2]   = 0x00;
        Spi_TxData_0[3]   = 0x00;
        Spi_TxData_0[4]   = 0x78;
        Spi_TxData_0[5]   = 0x03;
        Spi_TxData_0[6]   = 0x00;
        Spi_TxData_0[7]   = 0x01;
        Spi_TxData_0[8]   = 0xf0;

        Spi_TxData_0[252] = 0xb6;
        Spi_TxData_0[253] = 0x0b;
        Spi_TxData_0[254] = 0x57;
        Spi_TxData_0[255] = 0xfc;
    }
    else if(Spi0_step == 2)
    {
        Spi_TxData_0[0]   = 0x00;
        Spi_TxData_0[1]   = 0x4b;

        //Spi_TxData_0[252] = 0xb6;
        //Spi_TxData_0[253] = 0x0b;
        //Spi_TxData_0[254] = 0x57;
        //Spi_TxData_0[255] = 0xfc;
    }

    Spi0_step++;
    if(Spi0_step > 2)
    {
        Spi0_step = 0;
    }    
#endif

    adi_wil_hal_SpiTransmit(0, 0, &Spi_TxData_0[0], &Spi_RxData_0[0], 256);
}

void Test_Spi_Hal_1(void)
{
    int i = 0;

    memset(&Spi_TxData_1[0], 0, 256);

#if 0
    static int xxx = 0;
    if(xxx == 0)
    {
        xxx = 1;
        Spi_TxData_1[0]   = 0x00;
        Spi_TxData_1[1]   = 0xFF;
    }
    else
    {
        xxx = 0;
        Spi_TxData_1[0]   = 0x04;
        Spi_TxData_1[1]   = 0xFF;
        Spi_TxData_1[2]   = 0x00;
        Spi_TxData_1[3]   = 0x00;
        Spi_TxData_1[4]   = 0x7F;
        Spi_TxData_1[5]   = 0x02;

        Spi_TxData_1[252] = 0xD6;
        Spi_TxData_1[253] = 0xEC;
        Spi_TxData_1[254] = 0x8B;
        Spi_TxData_1[255] = 0x01;
    }
    
    Spi_TxData_1_Count++;
#else
    // query devices
    if(Spi1_step == 0)
    {
        Spi_TxData_1[0]   = 0x04;
        Spi_TxData_1[1]   = 0xFF;
        Spi_TxData_1[2]   = 0x00;
        Spi_TxData_1[3]   = 0x00;
        Spi_TxData_1[4]   = 0x7F;
        Spi_TxData_1[5]   = 0x02;

        Spi_TxData_1[252] = 0xD6;
        Spi_TxData_1[253] = 0xEC;
        Spi_TxData_1[254] = 0x8B;
        Spi_TxData_1[255] = 0x01;
    }
    else if(Spi1_step == 1)
    {
        // connect nodes
        Spi_TxData_1[0]   = 0x05;
        Spi_TxData_1[1]   = 0xFF;
        Spi_TxData_1[2]   = 0x00;
        Spi_TxData_1[3]   = 0x00;
        Spi_TxData_1[4]   = 0x78;
        Spi_TxData_1[5]   = 0x03;
        Spi_TxData_1[6]   = 0x00;
        Spi_TxData_1[7]   = 0x01;
        Spi_TxData_1[8]   = 0xf1;

        Spi_TxData_1[252] = 0x78;
        Spi_TxData_1[253] = 0x53;
        Spi_TxData_1[254] = 0x95;
        Spi_TxData_1[255] = 0x4d;
    }
    else if(Spi1_step == 2)
    {
        Spi_TxData_1[0]   = 0x00;
        Spi_TxData_1[1]   = 0x4b;

        //Spi_TxData_1[252] = 0x78;
        //Spi_TxData_1[253] = 0x53;
        //Spi_TxData_1[254] = 0x95;
        //Spi_TxData_1[255] = 0x4d;
    }

    Spi1_step++;
    if(Spi1_step > 2)
    {
        Spi1_step = 0;
    }
#endif

    adi_wil_hal_SpiTransmit(1, 0, &Spi_TxData_1[0], &Spi_RxData_1[0], 256);
}
#endif

/******************************************************************************************/
/* Start of adi_wil_example_Main                                               */
/******************************************************************************************/
uint16_t NWBufferSize = 0;
int adi_wil_example_Main(void)
{
    uint8_t i, j;
    bool bAllNodesJoined = false;
    bool bLoadMNGConfig = false;

#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 1;
    while(1)
    {
        if((CmicComm_GetSpiState() == 1) && 
            (ADK_DEMO.AUTHORITY == 0/*MAIN*/))
        {
            break;
        }
    }

#if 1 // V2.1.0 OTAP
    bool bOtapFwUpgrade = false;
    bOtapFwUpgrade = (bool)ADK_DEMO.OTAPFW_UPGRADE;
#endif

    memset(&ADK_DEMO, 0x0, sizeof(DISPLAYSTR));
    for(uint8_t i_node = 0; i_node < ADK_MAX_node; i_node++)
    {
        ADK_DEMO.NODE[i_node].NO_OF_USERACL = 0xFF;
    }
    
    ADK_DEMO.AUTHORITY = 0/*MAIN*/;
    ADK_DEMO.BOOT_STEP = 2;
#if 1 // V2.1.0 OTAP
    ADK_DEMO.OTAP_UPDATE_FORCE = bOtapFwUpgrade;
#endif
#endif

#if 1 // @SURE - ADDED
    ADK_DEMO.ACL_UPDATE_FORCE = 0; // forced update configuration file to container 
#endif
#if 1 // V2.1.0 OTAP
    if(ADK_DEMO.OTAP_UPDATE_FORCE)
    {
        ADK_DEMO.ACL_UPDATE_FORCE = (bool)bOtapFwUpgrade;
    }
#endif
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 3;
#endif

#if (CMIC_CONF_ONLY_SPI_TEST) // for SPI test
    adi_wil_hal_SpiInit(0, &Spi_TxCompleteCbk_0);
    adi_wil_hal_SpiInit(1, &Spi_TxCompleteCbk_1);
    return 0;
#endif

    /* remark : Ticker early init for boot time measurement */
    adk_debug_TickerBTInit();
    ADK_DEMO.BOOT = 90;
    adk_debug_BootTimeLog(Overall_, LogStart, 999, Demo_Total_boot_time__________________);

    #ifdef DBG_ACL_MAP_TEST
    /* @remark : userAcl_map initialize */
    for(i=0; i<userAcl.iCount; i++)
    {
        userAcl_map[i] = true;
    }
    #endif

    /* @remark : realAcl initialize */
    memset(&realAcl, 0, sizeof(adi_wil_acl_t));
    /* @remark : Container update indicator (false = update needed, true = update no need) */
    ADK_DEMO.ACL_UPDATE_NO_NEED = false;
#if 1 // V2.1.0 OTAP
    ADK_DEMO.OTAP_STAT = Demo_OTAP_No_Operation________________;
#endif
    
    /* STEP 1  : WBMS System Initialization **********************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 100, Demo_ExecuteInitialize________________);
    adi_wil_example_ExecuteInitialize();
    ADK_DEMO.BOOT = 100;
    adk_debug_BootTimeLog(Interval, LogEnd__, 100, Demo_ExecuteInitialize________________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 4;
#endif

    /* STEP 2  : Start calling processTask periodically **********************************/
    adk_debug_BootTimeLog(Interval, LogStart, 101, Demo_PeriodicallyCallProcessTask______);
    adi_wil_example_PeriodicallyCallProcessTask();
    ADK_DEMO.BOOT = 101;
    adk_debug_BootTimeLog(Interval, LogEnd__, 101, Demo_PeriodicallyCallProcessTask______);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 5;
#endif

    /* STEP 3  : Query device ************************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 102, Demo_ExecuteQueryDevice_______________);
    /* Determine whether the two managers on the two SPI ports are in dual manager mode */
    memset(portConfig, 0, sizeof(portConfig));
    while(gQueryDeviceRetry != true){       /*  @remark : Query device retry */
        adi_wil_example_ExecuteQueryDevice(portConfig);
    }    
    ADK_DEMO.BOOT = 102;
    adk_debug_BootTimeLog(Interval, LogEnd__, 102, Demo_ExecuteQueryDevice_______________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 10;
#endif
    
    /* CONDITION 1 : Check Dual Manager configuration ************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 110, Demo_isDualConfig_____________________);
    bool bDualMgrConfiguration = adi_wil_example_isDualConfig(&portConfig[0], &portConfig[1], portVar);
    ADK_DEMO.BOOT = 110;
    adk_debug_BootTimeLog(Interval, LogEnd__, 110, Demo_isDualConfig_____________________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 20;
#endif
    
    if (!bDualMgrConfiguration)
    {
        /* Dual Manager mode config download for empty device */
        /* STEP 4  : Connect *************************************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 120, Demo_ExecuteConnect_0_________________);
        adi_wil_err_t rc;
        rc = (adi_wil_example_ExecuteConnect(&packInstance,
                                             wbmsSysSensorData,
                                             (BMS_DATA_PACKET_COUNT + PMS_DATA_PACKET_COUNT + EMS_DATA_PACKET_COUNT)));
        ADK_DEMO.BOOT = 120;
        adk_debug_BootTimeLog(Interval, LogEnd__, 120, Demo_ExecuteConnect_0_________________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 21;
#endif

        if ((rc == ADI_WIL_ERR_SUCCESS) || (rc == ADI_WIL_ERR_CONFIGURATION_MISMATCH) || (rc == ADI_WIL_ERR_INVALID_STATE))
        {
            /* STEP 5  : Reset Device (ALL MANAGERS) *************************************/
            adk_debug_BootTimeLog(Interval, LogStart, 121, Demo_ExecuteResetDevice_single_mngr_0_);
            returnOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_MANAGERS));
            ADK_DEMO.BOOT = 121;
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 22;
#endif

            iMgrConnectCount = 0;
            while(iMgrConnectCount < ADI_WIL_NUM_NW_MANAGERS) {}; /* i.e. wait for two ADI_WIL_EVENT_COMM_MGR_CONNECTED events */
            adk_debug_BootTimeLog(Interval, LogEnd__, 121, Demo_ExecuteResetDevice_single_mngr_0_);

            /* STEP 6  : Load files (CONFIGURATION, ALL MANAGERS) ************************/
            adk_debug_BootTimeLog(Interval, LogStart, 122, Demo_ExecuteLoadFile_singlecon_allmngr);
            returnOnWilError(adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_CONFIGURATION, ADI_WIL_DEV_ALL_MANAGERS, SET_MODE));
            bLoadMNGConfig = true;
            ADK_DEMO.BOOT = 122;
            adk_debug_BootTimeLog(Interval, LogEnd__, 122, Demo_ExecuteLoadFile_singlecon_allmngr);
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 23;
#endif

            /* STEP 7  : Reset Device (ALL MANAGERS) *************************************/
            adk_debug_BootTimeLog(Interval, LogStart, 123, Demo_ExecuteResetDevice_single_mngr_1_);
            returnOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_MANAGERS));
            ADK_DEMO.BOOT = 123;
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 24;
#endif

            iMgrConnectCount = 0;
            while(iMgrConnectCount < ADI_WIL_NUM_NW_MANAGERS) {}; /* i.e. wait for two ADI_WIL_EVENT_COMM_MGR_CONNECTED events */
            adk_debug_BootTimeLog(Interval, LogEnd__, 123, Demo_ExecuteResetDevice_single_mngr_1_);

            /* STEP 8  : Disconnect ******************************************************/
            adk_debug_BootTimeLog(Interval, LogStart, 123, Demo_ExecuteDisconnect_0______________);
            returnOnWilError(adi_wil_example_ExecuteDisconnect(&packInstance));
            ADK_DEMO.BOOT = 124;
            adk_debug_BootTimeLog(Interval, LogEnd__, 123, Demo_ExecuteDisconnect_0______________);
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 25;
#endif
        }
        else
        {
            /* Fail */
            fatalError(rc);
        }
        
        /* STEP  9 : Check Dual Manager configuration ************************************/
        bDualMgrConfiguration = adi_wil_example_isDualConfig(&portConfig[0], &portConfig[1], portVar);
        
    }
    
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 30;
#endif

    /* STEP 10 : Connect *****************************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 130, Demo_ExecuteConnect_1_________________);
    returnOnWilError(adi_wil_example_ExecuteConnect(&packInstance,
                                        wbmsSysSensorData,
                                        (BMS_DATA_PACKET_COUNT + PMS_DATA_PACKET_COUNT + EMS_DATA_PACKET_COUNT)));
    ADK_DEMO.BOOT = 130;
    adk_debug_BootTimeLog(Interval, LogEnd__, 130, Demo_ExecuteConnect_1_________________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 32;
#endif

    /* CONDITION 2 : Check STANDBY mode **************************************************/
    /* STEP 11 : Set Mode (STANDBY) ******************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 140, Demo_ExecuteSetMode___________________);
    returnOnWilError(adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY));
    ADK_DEMO.BOOT = 140;
    adk_debug_BootTimeLog(Interval, LogEnd__, 140, Demo_ExecuteSetMode___________________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 35;
#endif

    /* STEP 12 : Get Acl *****************************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 150, Demo_ExecuteGetACL_0__________________);
    fatalOnWilError(adi_wil_example_ExecuteGetACL(&packInstance));
    ADK_DEMO.BOOT = 150;
    adk_debug_BootTimeLog(Interval, LogEnd__, 150, Demo_ExecuteGetACL_0__________________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 37;
#endif

    /* STEP 13 : Compare Acl *************************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 155, Demo_ADK_CompareACL___________________);
    ADK_DEMO.ACL_UPDATE_NO_NEED = adi_wil_example_ADK_CompareACL();
    ADK_DEMO.BOOT = 155;
    adk_debug_BootTimeLog(Interval, LogEnd__, 155, Demo_ADK_CompareACL___________________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 39;
#endif

    /* CONDITION 3 : Check ACL update ****************************************************/
    if(ADK_DEMO.ACL_UPDATE_NO_NEED == false || ADK_DEMO.ACL_UPDATE_FORCE == true)
    {
        adk_debug_BootTimeLog(Interval, LogStart, 200, Demo_ACL_UPDATE_FORCE_________________);
        ADK_DEMO.BOOT = 200;
        adk_debug_BootTimeLog(Interval, LogEnd__, 200, Demo_ACL_UPDATE_FORCE_________________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 40;
#endif

        if (ACL_EMPTY == false){
        adk_debug_BootTimeLog(Interval, LogStart, 209, Demo_ExecuteResetDevice_______________);
        fatalOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES));
        ADK_DEMO.BOOT = 209;
        adk_debug_BootTimeLog(Interval, LogEnd__, 209, Demo_ExecuteResetDevice_______________);
        }

        adk_debug_BootTimeLog(Interval, LogStart, 210, Demo_ExecuteSetACL____________________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 42;
#endif

        do {
            /* STEP 14 : SetAcl **********************************************************/
            if(realAcl.iCount == 0)
            {
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 43;
#endif
                fatalOnWilError(adi_wil_example_ExecuteSetACL(userAcl.Data, userAcl.iCount));
                ADK_DEMO.BOOT = 210;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 44;
#endif
            }
            else
            {
                /* @remark : SetAcl from realAcl,  */
                returnOnWilError(adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY));
                ADK_DEMO.BOOT = 218;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 45;
#endif
                /* @remark : should call ResetDevice */
                fatalOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES));
                ADK_DEMO.BOOT = 209;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 46;
#endif
                fatalOnWilError(adi_wil_example_ExecuteSetACL(realAcl.Data, realAcl.iCount));
                ADK_DEMO.BOOT = 210;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 47;
#endif
            }
            adk_debug_BootTimeLog(Interval, LogEnd__, 210, Demo_ExecuteSetACL____________________);

            adk_debug_BootTimeLog(Interval, LogStart, 211, Demo_ExecuteGetACL_1__________________);
            fatalOnWilError(adi_wil_example_ExecuteGetACL(&packInstance));
            ADK_DEMO.BOOT = 211;
            adk_debug_BootTimeLog(Interval, LogEnd__, 211, Demo_ExecuteGetACL_1__________________);
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 48;
#endif

            /* STEP 15 : Set Mode (COMMISSIONING) ****************************************/
            /* STEP 16 : Get Network Status **********************************************/
            adk_debug_BootTimeLog(Interval, LogStart, 212, Demo_ExecuteGetNetworkStatus_0________);
            bAllNodesJoined = adi_wil_example_ExecuteGetNetworkStatus(&packInstance, &networkStatus, SET_MODE);
            ADK_DEMO.BOOT = 212;
            adk_debug_BootTimeLog(Interval, LogEnd__, 212, Demo_ExecuteGetNetworkStatus_0________);
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 49;
#endif

            /* CONDITION 4 : Check Node response *****************************************/
            adk_debug_BootTimeLog(Interval, LogStart, 215, Demo_bAllNodesJoined__________________);
            if(!bAllNodesJoined){
                ADK_DEMO.BOOT = 215;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 50;
#endif
                uint8_t l = 0;
                memset(&realAcl, 0, sizeof(adi_wil_acl_t));
                #ifdef DBG_ACL_MAP_TEST
                /* realAcl_map Initialize */
                for(i=0; i<userAcl.iCount; i++)
                {
                    realAcl_map[i] = false;
                }
                #endif
                for(uint8_t k=0; k<networkStatus.iCount; k++) {
                    if(networkStatus.iConnectState & (1<<k))
                    {
                        /* STEP 17 : realAcl generation from userAcl *********************/
                        memcpy(realAcl.Data + (l * ADI_WIL_MAC_ADDR_SIZE), userAcl.Data + (k * ADI_WIL_MAC_ADDR_SIZE), ADI_WIL_MAC_ADDR_SIZE);
                        #ifdef DBG_ACL_MAP_TEST
                        realAcl_map[k] = true;
                        #endif
                        ADK_DEMO.BOOT = 216;
#if 1 // @SURE - ADDED
                        ADK_DEMO.BOOT_STEP = 51;
#endif
                        realAcl.iCount++;
                        l++;
                    }
                }
            }
        }while(!bAllNodesJoined);
        adk_debug_BootTimeLog(Interval, LogEnd__, 215, Demo_bAllNodesJoined__________________);

        /* CONDITION 5 : Check First trial for realAcl ***********************************/
        adk_debug_BootTimeLog(Interval, LogStart, 218, Demo_realAcl_generation_______________);
        if(realAcl.iCount == 0){          
            /* STEP 18 : realAcl generation from userAcl *********************************/
            memcpy(&realAcl, &userAcl, sizeof(adi_wil_acl_t));
            #ifdef DBG_ACL_MAP_TEST
            for(i=0; i<userAcl.iCount; i++)
            {
                realAcl_map[i] = true;
            }
            #endif
            ADK_DEMO.BOOT = 218;
            adk_debug_BootTimeLog(Interval, LogEnd__, 218, Demo_realAcl_generation_______________);
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 52;
#endif
        }

#if 1 // @SURE - ADDED
        adi_example_match_acl();
#endif

        /* STEP 19 : Set Mode (STANDBY) **************************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 220, Demo_ExecuteSetMode_STANDBY___________);
        returnOnWilError(adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY));
        ADK_DEMO.BOOT = 220;
        adk_debug_BootTimeLog(Interval, LogEnd__, 220, Demo_ExecuteSetMode_STANDBY___________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 53;
#endif

#if 1 // V2.1.0 OTAP
        /* CONDITION 6 : OTAP Force update ***************************************************/
        if(ADK_DEMO.OTAP_UPDATE_FORCE == true)
        {
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 54;
#endif
#if 1 // @SURE - ADDED
            ADK_DEMO.OTAP_STEP = 1;
#endif
            adk_debug_BootTimeLog(Interval, LogStart, 501, Demo_OTAP_Update_Triggered____________);
            ADK_DEMO.OTAP_STAT = Demo_OTAP_Update_Triggered____________;
            ADK_DEMO.BOOT = 501;
            adk_debug_BootTimeLog(Interval, LogEnd__, 501, Demo_OTAP_Update_Triggered____________);
#if 1 // @SURE - ADDED
            ADK_DEMO.OTAP_STEP = 2;
#endif

            /*********************************************************************************/
            /************************ OTAP PHASE 1 : download FPA ****************************/
            /*********************************************************************************/

            adk_debug_BootTimeLog(Interval, LogStart, 502, Demo_OTAP_1_GetDeviceVersion_Mngr_Prev);
            ADK_DEMO.OTAP_STAT = Demo_OTAP_1_GetDeviceVersion_Mngr_Prev;
            adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_0, NO_SET_MODE);
            adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_P0, 0);
            adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_1, NO_SET_MODE);
            adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_P0, 1);
            ADK_DEMO.BOOT = 502;
            adk_debug_BootTimeLog(Interval, LogEnd__, 502, Demo_OTAP_1_GetDeviceVersion_Mngr_Prev);
#if 1 // @SURE - ADDED
            ADK_DEMO.OTAP_STEP = 4;
            ADK_DEMO.OTAP_PHASE = 1;
#endif

            adk_debug_BootTimeLog(Interval, LogStart, 503, Demo_OTAP_1_GetDeviceVersion_Node_Prev);
            ADK_DEMO.OTAP_STAT = Demo_OTAP_1_GetDeviceVersion_Node_Prev;
            for(uint8_t k=0; k<networkStatus.iCount; k++) {
                adi_wil_example_GetDeviceVersion(&packInstance, 1ULL << k, NO_SET_MODE);
                adk_debug_log_GetDeviceVersion(OTAP_Node, OTAP_P0, k);
            }
            ADK_DEMO.BOOT = 503;
            adk_debug_BootTimeLog(Interval, LogEnd__, 503, Demo_OTAP_1_GetDeviceVersion_Node_Prev);
#if 1 // @SURE - ADDED
            ADK_DEMO.OTAP_STEP = 6;
#endif

            if(!adi_wil_example_CheckDeviceVersion(OTAP_Mngr, VER_2_1_0, 0))
            {
                adk_debug_BootTimeLog(Interval, LogStart, 504, Demo_OTAP_1_LoadFile_FPA_AllNodes_____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_LoadFile_FPA_AllNodes_____;
                adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_NODES, NO_SET_MODE);
                adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_NODES);
                ADK_DEMO.BOOT = 504;
                adk_debug_BootTimeLog(Interval, LogEnd__, 504, Demo_OTAP_1_LoadFile_FPA_AllNodes_____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 8;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 519, Demo_OTAP_1_ResetDevice_AllNodes______);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_ResetDevice_AllNodes______;
                adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES);
                ADK_DEMO.BOOT = 519;
                adk_debug_BootTimeLog(Interval, LogEnd__, 519, Demo_OTAP_1_ResetDevice_AllNodes______);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 10;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 521, Demo_OTAP_1_Wait_for_node_disconnect__);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_Wait_for_node_disconnect__;
                adi_wil_example_waitForEvent(ADI_WIL_EVENT_COMM_NODE_DISCONNECTED, ClientData.Acl.iCount);
                ADK_DEMO.BOOT = 521;
                adk_debug_BootTimeLog(Interval, LogEnd__, 521, Demo_OTAP_1_Wait_for_node_disconnect__);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 12;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 522, Demo_OTAP_1_LoadFile_FPA_AllMngrs_____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_LoadFile_FPA_AllMngrs_____;
                adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_MANAGERS, NO_SET_MODE);
                adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_MANAGERS);
                ADK_DEMO.BOOT = 522;
                adk_debug_BootTimeLog(Interval, LogEnd__, 522, Demo_OTAP_1_LoadFile_FPA_AllMngrs_____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 14;
#endif
                
                adk_debug_BootTimeLog(Interval, LogStart, 530, Demo_OTAP_1_ResetDevice_AllMngrs______);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_ResetDevice_AllMngrs______;
                adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_MANAGERS);
                ADK_DEMO.BOOT = 530;
                adk_debug_BootTimeLog(Interval, LogEnd__, 530, Demo_OTAP_1_ResetDevice_AllMngrs______);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 16;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 533, Demo_OTAP_1_Wait_for_mngr_connect_____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_Wait_for_mngr_connect_____;
                adi_wil_example_waitForEvent(ADI_WIL_EVENT_COMM_MGR_CONNECTED, ADI_WIL_NUM_NW_MANAGERS);
                ADK_DEMO.BOOT = 533;
                adk_debug_BootTimeLog(Interval, LogEnd__, 533, Demo_OTAP_1_Wait_for_mngr_connect_____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 18;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 536, Demo_OTAP_1_TaskStop__________________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_TaskStop__________________;
                adi_wil_hal_TaskStop();
                ADK_DEMO.BOOT = 536;
                adk_debug_BootTimeLog(Interval, LogEnd__, 536, Demo_OTAP_1_TaskStop__________________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 20;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 538, Demo_OTAP_1_Wait_for_Mngr_booting_____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_1_Wait_for_Mngr_booting_____;
                for(uint32_t otap_idle = 0; otap_idle < 100000000; otap_idle++)
                {
                    /* @remark : Wait for Dual managers booting */
                }
                ADK_DEMO.BOOT = 538;
                adk_debug_BootTimeLog(Interval, LogEnd__, 538, Demo_OTAP_1_Wait_for_Mngr_booting_____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 22;
#endif

                /*********************************************************************************/
                /********************** OTAP PHASE 2 : download OPFW 2.0.0 ***********************/
                /*********************************************************************************/

                adk_debug_BootTimeLog(Interval, LogStart, 540, Demo_OTAP_2_Initialization____________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_Initialization____________;
                adi_wil_example_ExecuteInitialize();
                ADK_DEMO.BOOT = 540;
                adk_debug_BootTimeLog(Interval, LogEnd__, 540, Demo_OTAP_2_Initialization____________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 24;
                ADK_DEMO.OTAP_PHASE = 2;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 541, Demo_OTAP_2_TaskStart_________________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_TaskStart_________________;
                adi_wil_example_PeriodicallyCallProcessTask();
                ADK_DEMO.BOOT = 541;
                adk_debug_BootTimeLog(Interval, LogEnd__, 541, Demo_OTAP_2_TaskStart_________________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 26;
#endif
                
                adk_debug_BootTimeLog(Interval, LogStart, 542, Demo_OTAP_2_Confirm_Manager_FPA_______);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_Confirm_Manager_FPA_______;
                adi_wil_example_confirmManagerFPA();
                ADK_DEMO.BOOT = 542;
                adk_debug_BootTimeLog(Interval, LogEnd__, 542, Demo_OTAP_2_Confirm_Manager_FPA_______);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 28;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 551, Demo_OTAP_2_Connect___________________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_Connect___________________;
                adi_wil_example_ExecuteConnect(&packInstance, wbmsSysSensorData, (BMS_DATA_PACKET_COUNT + PMS_DATA_PACKET_COUNT + EMS_DATA_PACKET_COUNT));
                ADK_DEMO.BOOT = 551;
                adk_debug_BootTimeLog(Interval, LogEnd__, 551, Demo_OTAP_2_Connect___________________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 30;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 552, Demo_OTAP_2_GetNetworkStatus__________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_GetNetworkStatus__________;
                while (adi_wil_example_countUnconnectedNodes() != 0);
                ADK_DEMO.BOOT = 552;
                adk_debug_BootTimeLog(Interval, LogEnd__, 552, Demo_OTAP_2_GetNetworkStatus__________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 32;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 560, Demo_OTAP_2_LoadFile_OPFW_AllNodes____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_LoadFile_OPFW_AllNodes____;
                adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_NODES, NO_SET_MODE);
                adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_NODES);
                ADK_DEMO.BOOT = 560;
                adk_debug_BootTimeLog(Interval, LogEnd__, 560, Demo_OTAP_2_LoadFile_OPFW_AllNodes____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 34;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 570, Demo_OTAP_2_LoadFile_OPFW_AllMngrs____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_LoadFile_OPFW_AllMngrs____;
                adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_MANAGERS, NO_SET_MODE);
                adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_MANAGERS);
                ADK_DEMO.BOOT = 570;
                adk_debug_BootTimeLog(Interval, LogEnd__, 570, Demo_OTAP_2_LoadFile_OPFW_AllMngrs____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 36;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 580, Demo_OTAP_2_ResetDevice_AllNodes______);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_ResetDevice_AllNodes______;
                adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES);
                ADK_DEMO.BOOT = 580;
                adk_debug_BootTimeLog(Interval, LogEnd__, 580, Demo_OTAP_2_ResetDevice_AllNodes______);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 40;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 590, Demo_OTAP_2_SetMode_STANDBY___________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_SetMode_STANDBY___________;
                adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
                ADK_DEMO.BOOT = 590;
                adk_debug_BootTimeLog(Interval, LogEnd__, 590, Demo_OTAP_2_SetMode_STANDBY___________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 42;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 592, Demo_OTAP_2_Wait_for_mngr_connect_____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_Wait_for_mngr_connect_____;
                adi_wil_example_waitForEvent(ADI_WIL_EVENT_COMM_MGR_CONNECTED, ADI_WIL_NUM_NW_MANAGERS);
                ADK_DEMO.BOOT = 592;
                adk_debug_BootTimeLog(Interval, LogEnd__, 592, Demo_OTAP_2_Wait_for_mngr_connect_____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 44;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 593, Demo_OTAP_2_GetMode_STANDBY___________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_GetMode_STANDBY___________;
                adi_wil_mode_t eCurrentMode;
                adi_wil_example_ExecuteGetMode(&packInstance,&eCurrentMode);
                if (eCurrentMode != ADI_WIL_MODE_STANDBY)
                {
                    fatalOnWilError(ADI_WIL_ERR_INVALID_MODE);
                }
                ADK_DEMO.BOOT = 593;
                adk_debug_BootTimeLog(Interval, LogEnd__, 593, Demo_OTAP_2_GetMode_STANDBY___________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 46;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 594, Demo_OTAP_2_Wait_for_Nodes_to_join____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_Wait_for_Nodes_to_join____;
                adi_wil_example_waitForNodesToJoin();
                ADK_DEMO.BOOT = 594;
                adk_debug_BootTimeLog(Interval, LogEnd__, 594, Demo_OTAP_2_Wait_for_Nodes_to_join____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 48;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 598, Demo_OTAP_2_GetDeviceVersion_Mngr_Next);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_GetDeviceVersion_Mngr_Next;
                adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_0, SET_MODE);
                adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_P2, 0);
                adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_1, NO_SET_MODE);
                adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_P2, 1);
                ADK_DEMO.BOOT = 598;
                adk_debug_BootTimeLog(Interval, LogEnd__, 598, Demo_OTAP_2_GetDeviceVersion_Mngr_Next);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 50;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 599, Demo_OTAP_2_GetDeviceVersion_Node_Next);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_2_GetDeviceVersion_Node_Next;
                for(uint8_t k=0; k<networkStatus.iCount; k++) {
                    adi_wil_example_GetDeviceVersion(&packInstance, 1ULL << k, NO_SET_MODE);
                    adk_debug_log_GetDeviceVersion(OTAP_Node, OTAP_P2, k);
                }
                ADK_DEMO.BOOT = 599;
                adk_debug_BootTimeLog(Interval, LogEnd__, 599, Demo_OTAP_2_GetDeviceVersion_Node_Next);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 52;
#endif

                /*********************************************************************************/
                /********************** OTAP PHASE 3 : download OPFW 2.1.0 ***********************/
                /*********************************************************************************/
                adk_debug_BootTimeLog(Interval, LogStart, 600, Demo_OTAP_3_SetMode_STANDBY_0_________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_SetMode_STANDBY_0_________;
                adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
                ADK_DEMO.BOOT = 600;
                adk_debug_BootTimeLog(Interval, LogEnd__, 600, Demo_OTAP_3_SetMode_STANDBY_0_________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 54;
                ADK_DEMO.OTAP_PHASE = 3;
#endif
                
                adk_debug_BootTimeLog(Interval, LogStart, 601, Demo_OTAP_3_SetMode_OTAP______________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_SetMode_OTAP______________;
                adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_OTAP);
                ADK_DEMO.BOOT = 601;
                adk_debug_BootTimeLog(Interval, LogEnd__, 601, Demo_OTAP_3_SetMode_OTAP______________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 56;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 602, Demo_OTAP_3_Wait_for_mngr_connect_0___);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_Wait_for_mngr_connect_0___;
                adi_wil_example_waitForEvent(ADI_WIL_EVENT_COMM_MGR_CONNECTED, ADI_WIL_NUM_NW_MANAGERS);
                ADK_DEMO.BOOT = 602;
                adk_debug_BootTimeLog(Interval, LogEnd__, 602, Demo_OTAP_3_Wait_for_mngr_connect_0___);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 58;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 603, Demo_OTAP_3_GetNetworkStatus__________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_GetNetworkStatus__________;
                while (adi_wil_example_countUnconnectedNodes() != 0);
                ADK_DEMO.BOOT = 603;
                adk_debug_BootTimeLog(Interval, LogEnd__, 603, Demo_OTAP_3_GetNetworkStatus__________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 60;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 604, Demo_OTAP_3_LoadFile_OPFW_AllNodes____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_LoadFile_OPFW_AllNodes____;
                adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_NODES, NO_SET_MODE);
                adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_NODES);
                ADK_DEMO.BOOT = 604;
                adk_debug_BootTimeLog(Interval, LogEnd__, 604, Demo_OTAP_3_LoadFile_OPFW_AllNodes____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 62;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 605, Demo_OTAP_3_LoadFile_OPFW_AllMngrs____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_LoadFile_OPFW_AllMngrs____;
                adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_MANAGERS, NO_SET_MODE);
                adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_FIRMWARE, ADI_WIL_DEV_ALL_MANAGERS);
                ADK_DEMO.BOOT = 605;
                adk_debug_BootTimeLog(Interval, LogEnd__, 605, Demo_OTAP_3_LoadFile_OPFW_AllMngrs____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 64;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 606, Demo_OTAP_3_ResetDevice_AllNodes______);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_ResetDevice_AllNodes______;
                adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES);
                ADK_DEMO.BOOT = 606;
                adk_debug_BootTimeLog(Interval, LogEnd__, 606, Demo_OTAP_3_ResetDevice_AllNodes______);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 66;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 607, Demo_OTAP_3_SetMode_STANDBY_1_________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_SetMode_STANDBY_1_________;
                adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
                ADK_DEMO.BOOT = 607;
                adk_debug_BootTimeLog(Interval, LogEnd__, 607, Demo_OTAP_3_SetMode_STANDBY_1_________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 70;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 608, Demo_OTAP_3_Wait_for_mngr_connect_1___);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_Wait_for_mngr_connect_1___;
                adi_wil_example_waitForEvent(ADI_WIL_EVENT_COMM_MGR_CONNECTED, ADI_WIL_NUM_NW_MANAGERS);
                ADK_DEMO.BOOT = 608;
                adk_debug_BootTimeLog(Interval, LogEnd__, 608, Demo_OTAP_3_Wait_for_mngr_connect_1___);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 76;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 609, Demo_OTAP_3_Wait_for_Nodes_to_join____);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_Wait_for_Nodes_to_join____;
                adi_wil_example_waitForNodesToJoin();
                ADK_DEMO.BOOT = 609;
                adk_debug_BootTimeLog(Interval, LogEnd__, 609, Demo_OTAP_3_Wait_for_Nodes_to_join____);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 82;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 610, Demo_OTAP_3_SetMode_STANDBY_2_________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_SetMode_STANDBY_2_________;
                adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
                ADK_DEMO.BOOT = 610;
                adk_debug_BootTimeLog(Interval, LogEnd__, 610, Demo_OTAP_3_SetMode_STANDBY_2_________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 86;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 611, Demo_OTAP_3_GetDeviceVersion_Mngr_Next);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_GetDeviceVersion_Mngr_Next;
                adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_0, NO_SET_MODE);
                adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_P3, 0);
                adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_1, NO_SET_MODE);
                adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_P3, 1);
                ADK_DEMO.BOOT = 611;
                adk_debug_BootTimeLog(Interval, LogEnd__, 611, Demo_OTAP_3_GetDeviceVersion_Mngr_Next);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 92;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 612, Demo_OTAP_3_GetDeviceVersion_Node_Next);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_3_GetDeviceVersion_Node_Next;
                for(uint8_t k=0; k<networkStatus.iCount; k++) {
                    adi_wil_example_GetDeviceVersion(&packInstance, 1ULL << k, NO_SET_MODE);
                    adk_debug_log_GetDeviceVersion(OTAP_Node, OTAP_P3, k);
                }
                ADK_DEMO.BOOT = 612;
                adk_debug_BootTimeLog(Interval, LogEnd__, 612, Demo_OTAP_3_GetDeviceVersion_Node_Next);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 96;
#endif

                adk_debug_BootTimeLog(Interval, LogStart, 612, Demo_OTAP_Complete____________________);
                ADK_DEMO.OTAP_STAT = Demo_OTAP_Complete____________________;
                ADK_DEMO.BOOT = 630;
                adk_debug_BootTimeLog(Interval, LogEnd__, 612, Demo_OTAP_Complete____________________);
#if 1 // @SURE - ADDED
                ADK_DEMO.OTAP_STEP = 100;
#endif
            }
        }
#endif

        /* STEP 21 : Load files (CONFIGURATION, ALL NODES) *******************************/
        adk_debug_BootTimeLog(Interval, LogStart, 233, Demo_ExecuteLoadFile_config_allnode___);
        fatalOnWilError(adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_CONFIGURATION, ADI_WIL_DEV_ALL_NODES, NO_SET_MODE));
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 55;
#endif
        adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_CONFIGURATION, ADI_WIL_DEV_ALL_NODES);
        ADK_DEMO.BOOT = 233;
        adk_debug_BootTimeLog(Interval, LogEnd__, 233, Demo_ExecuteLoadFile_config_allnode___);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 56;
#endif

        /* STEP 22 : Load files (CONFIGURATION, ALL MANAGERS) ****************************/
        adk_debug_BootTimeLog(Interval, LogStart, 234, Demo_ExecuteLoadFile_config_allmngr___);
        fatalOnWilError(adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_CONFIGURATION, ADI_WIL_DEV_ALL_MANAGERS, NO_SET_MODE));
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 57;
#endif
        adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_CONFIGURATION, ADI_WIL_DEV_ALL_MANAGERS);
        ADK_DEMO.BOOT = 234;
        adk_debug_BootTimeLog(Interval, LogEnd__, 234, Demo_ExecuteLoadFile_config_allmngr___);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 58;
#endif

        /* STEP 23 : Load files (CONTAINER, ALL NODES) ***********************************/
        adk_debug_BootTimeLog(Interval, LogStart, 235, Demo_ExecuteLoadFile_cntain_allnode___);
        fatalOnWilError(adi_wil_example_ExecuteLoadFile(&packInstance, ADI_WIL_FILE_TYPE_BMS_CONTAINER, ADI_WIL_DEV_ALL_NODES, NO_SET_MODE));
        ADK_DEMO.BOOT = 235;
        adk_debug_BootTimeLog(Interval, LogEnd__, 235, Demo_ExecuteLoadFile_cntain_allnode___);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 59;
#endif

        adk_debug_BootTimeLog(Interval, LogStart, 236, Demo_ExecuteLoadFile_cntain_node_retry);
        adi_wil_example_LoadFileRetry(ADI_WIL_FILE_TYPE_BMS_CONTAINER, ADI_WIL_DEV_ALL_NODES);
        ADK_DEMO.BOOT = 236;
        adk_debug_BootTimeLog(Interval, LogEnd__, 236, Demo_ExecuteLoadFile_cntain_node_retry);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 60;
#endif

        /* STEP 24 : Reset Device (ALL NODES) ********************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 250, Demo_ExecuteResetDevice_allnode_______);
        fatalOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES));
        ADK_DEMO.BOOT = 250;
        adk_debug_BootTimeLog(Interval, LogEnd__, 250, Demo_ExecuteResetDevice_allnode_______);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 61;
#endif

        /* STEP 25 : Reset Device (ALL MANAGERS) *****************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 251, Demo_ExecuteResetDevice_allmngr_______);
        fatalOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_MANAGERS));
        ADK_DEMO.BOOT = 251;
        adk_debug_BootTimeLog(Interval, LogEnd__, 251, Demo_ExecuteResetDevice_allmngr_______);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 62;
#endif

        /* STEP 26 : Disconnect **********************************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 260, Demo_ExecuteDisconnect_1______________);
        returnOnWilError(adi_wil_example_ExecuteDisconnect(&packInstance));
        ADK_DEMO.BOOT = 260;
        adk_debug_BootTimeLog(Interval, LogEnd__, 260, Demo_ExecuteDisconnect_1______________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 64;
#endif

        /* STEP 27 : Connect *************************************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 261, Demo_ExecuteConnect_2_________________);
        returnOnWilError(adi_wil_example_ExecuteConnect(&packInstance, wbmsSysSensorData, (BMS_DATA_PACKET_COUNT + PMS_DATA_PACKET_COUNT + EMS_DATA_PACKET_COUNT)));
        ADK_DEMO.BOOT = 261;
        adk_debug_BootTimeLog(Interval, LogEnd__, 261, Demo_ExecuteConnect_2_________________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 66;
#endif

        /* STEP 28 : Set Mode (COMMISSIONING) ********************************************/
        /* STEP 29 : Get Network Status **************************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 270, Demo_ExecuteGetNetworkStatus_1________);
        adi_wil_example_ExecuteGetNetworkStatus(&packInstance, &networkStatus, SET_MODE);
        ADK_DEMO.BOOT = 270;
        adk_debug_BootTimeLog(Interval, LogEnd__, 270, Demo_ExecuteGetNetworkStatus_1________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 68;
#endif

        /* STEP 30 : Set Mode (STANDBY) **************************************************/
        /* STEP 31 : Get File CRC (Container) ********************************************/
        adk_debug_BootTimeLog(Interval, LogStart, 272, Demo_GetFileCRC_Container_____________);
        adi_wil_example_GetFileCRC(&packInstance, ADI_WIL_DEV_ALL_NODES, ADI_WIL_FILE_TYPE_BMS_CONTAINER, SET_MODE);
        ADK_DEMO.BOOT = 272;
        adk_debug_BootTimeLog(Interval, LogEnd__, 272, Demo_GetFileCRC_Container_____________);
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 72;
#endif

    }
    else{
        /* STEP 32 : realAcl generation from userAcl *************************************/
        if(realAcl.iCount == 0){          
            memcpy(&realAcl, &userAcl, sizeof(adi_wil_acl_t));
            #ifdef DBG_ACL_MAP_TEST
            for(i=0; i<userAcl.iCount; i++)
            {
                realAcl_map[i] = true;
            }
            #endif
            ADK_DEMO.BOOT = 290;
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 61;
#endif
        }
        do{
            /* STEP 33 : Set Mode (COMMISSIONING) ********************************************/
            /* STEP 34 : Get Network Status **************************************************/
            adk_debug_BootTimeLog(Interval, LogStart, 300, Demo_GetNetworkStatus_________________);
            bAllNodesJoined = adi_wil_example_ExecuteGetNetworkStatus(&packInstance, &networkStatus, SET_MODE);
            ADK_DEMO.BOOT = 300;
            adk_debug_BootTimeLog(Interval, LogEnd__, 300, Demo_GetNetworkStatus_________________);
#if 1 // @SURE - ADDED
            ADK_DEMO.BOOT_STEP = 63;
#endif

            if(!bAllNodesJoined){
                ADK_DEMO.BOOT = 301;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 65;
#endif
                uint8_t l = 0;
                memset(&realAcl, 0, sizeof(adi_wil_acl_t));
                #ifdef DBG_ACL_MAP_TEST
                /* realAcl_map Initialize */
                for(i=0; i<userAcl.iCount; i++)
                {
                    realAcl_map[i] = false;
                }
                #endif
                for(uint8_t k=0; k<networkStatus.iCount; k++) {
                    if(networkStatus.iConnectState & (1ULL<<k))
                    {
                        memcpy(realAcl.Data + (l * ADI_WIL_MAC_ADDR_SIZE), userAcl.Data + (k * ADI_WIL_MAC_ADDR_SIZE), ADI_WIL_MAC_ADDR_SIZE);
                        #ifdef DBG_ACL_MAP_TEST
                        realAcl_map[k] = true;
                        #endif
                        ADK_DEMO.BOOT = 320;
#if 1 // @SURE - ADDED
                        ADK_DEMO.BOOT_STEP = 67;
#endif
                        realAcl.iCount++;
                        l++;
                    }
                }
                returnOnWilError(adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY));
                ADK_DEMO.BOOT = 322;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 69;
#endif
                fatalOnWilError(adi_wil_example_ExecuteResetDevice(&packInstance, ADI_WIL_DEV_ALL_NODES));
                ADK_DEMO.BOOT = 325;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 71;
#endif
                fatalOnWilError(adi_wil_example_ExecuteSetACL(realAcl.Data, realAcl.iCount));
                ADK_DEMO.BOOT = 330;
                fatalOnWilError(adi_wil_example_ExecuteGetACL(&packInstance));
                ADK_DEMO.BOOT = 331;
#if 1 // @SURE - ADDED
                ADK_DEMO.BOOT_STEP = 73;
#endif
           }
        }while(!bAllNodesJoined);

#if 1 // @SURE - ADDED
        adi_example_match_acl();
#endif

        /* STEP 35 : Set Mode (STANDBY) **************************************************/
        returnOnWilError(adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY));
        ADK_DEMO.BOOT = 350;
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 75;
#endif
    }
    
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 76;
#endif

    adk_debug_BootTimeLog(Interval, LogStart, 360, Demo_GetDeviceVersion_Mngr_Now________);
    adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_0, NO_SET_MODE);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 78;
#endif
    adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_NOW, 0);
    adi_wil_example_GetDeviceVersion(&packInstance, ADI_WIL_DEV_MANAGER_1, NO_SET_MODE);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 80;
#endif
    adk_debug_log_GetDeviceVersion(OTAP_Mngr, OTAP_NOW, 1);
    ADK_DEMO.BOOT = 360;
    adk_debug_BootTimeLog(Interval, LogEnd__, 360, Demo_GetDeviceVersion_Mngr_Now________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 82;
#endif

    adk_debug_BootTimeLog(Interval, LogStart, 361, Demo_GetDeviceVersion_Node_Now________);
    for(uint8_t k=0; k<networkStatus.iCount; k++) {
        adi_wil_example_GetDeviceVersion(&packInstance, 1ULL << k, NO_SET_MODE);
        adk_debug_log_GetDeviceVersion(OTAP_Node, OTAP_NOW, k);
    }
    ADK_DEMO.BOOT = 361;
    adk_debug_BootTimeLog(Interval, LogEnd__, 361, Demo_GetDeviceVersion_Node_Now________);   
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 83;
#endif

#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 85;
#endif

    /* STEP 36 : Set Mode (ACTIVE) *******************************************************/
    /* STEP 37 : Select Script (BASE) ****************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 400, Demo_ExecuteSelectScript______________);
    adi_wil_example_ExecuteSelectScript(&packInstance, ADI_WIL_DEV_ALL_NODES, ADI_WIL_SENSOR_ID_BMS, ADI_BMS_BASE_ID, SET_MODE); // BASE
    ADK_DEMO.BOOT = 400;
    adk_debug_BootTimeLog(Interval, LogEnd__, 400, Demo_ExecuteSelectScript______________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 89;
#endif

    /* STEP 37 : Enable Network Data Capture *********************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 420, Demo_EnableNetworkDataCapture_________);
    NWBufferSize = networkStatus.iCount*ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL;
    adi_wil_EnableNetworkDataCapture(&packInstance, networkDataBuffer, (networkStatus.iCount*ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL), true);
    ADK_DEMO.BOOT = 420;
    adk_debug_BootTimeLog(Interval, LogEnd__, 420, Demo_EnableNetworkDataCapture_________);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 90;
#endif
    gTotalNodes= networkStatus.iCount;     /*  @remark : Variable to store total no. of Nodes in network */

    /* STEP 38 : Init CB_CELL for demo ***************************************************/
    for(i=0; i<12; i++){
#if     (ADK_ADBMS683x == 0) /* ADBMS6830 */
        for(j=0; j<16; j++){
            ADK_DEMO.CB_CELL[i][j] = true;
        }
#elif   (ADK_ADBMS683x == 3) /* ADBMS6833 */
        for(j=0; j<18; j++){
            ADK_DEMO.CB_CELL[i][j] = true;
        }
#else   /* Not supported */
#endif
    }

    /* STEP 40 : Run task for Read BMS ***************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 450, Demo_PeriodicallyCallProcessTaskCB____);
    adi_wil_example_PeriodicallyCallProcessTaskCB();
    ADK_DEMO.BOOT = 450;
    adk_debug_BootTimeLog(Interval, LogEnd__, 450, Demo_PeriodicallyCallProcessTaskCB____);
#if 1 // @SURE - ADDED
    ADK_DEMO.BOOT_STEP = 95;
#endif

    /* STEP 41 : Start scheduler *********************************************************/
    adk_debug_BootTimeLog(Interval, LogStart, 999, Demo_SchedulerInit____________________);
    if(true == adi_wil_example_SchedulerInit())
    {
        ADK_DEMO.BOOT = 999;
        adk_debug_BootTimeLog(Interval, LogEnd__, 999, Demo_SchedulerInit____________________);
        adk_debug_BootTimeLog(Overall_, LogEnd__, 999, Demo_Total_boot_time__________________);
        ADK_DEMO.BOOT_TIME = BOOT_TIME[0].DURATION;
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 100;
#endif
        adi_wil_example_scheduleTasks();
    }
    else
    {
#if 1 // @SURE - ADDED
        ADK_DEMO.BOOT_STEP = 96;
#endif
        /* Scheduler Initialization Failed */
        while(1);
    }

    return 0;
}

/******************************************************************************************/
/* End of adi_wil_example_Main                                                 */
/******************************************************************************************/

/******************************************************************************************/
/* BMS Data retrieval Task                                                                */
/******************************************************************************************/
void adi_task_bmsDataRetrieval(void)
{
    if(adi_gNotifyBmsData == true) //&& (adi_gNotifyNetworkMeta == true))
    {
        /* @remark : Custom function for reading BMS data */
        adi_wil_example_ADK_ExecuteProcessBMSBuffer();
        adi_gNotifyBmsData = false;
        //adi_gNotifyNetworkMeta = false;
    }
}

/******************************************************************************************/
/* Script Select example                                                                  */
/******************************************************************************************/
/* @remark : This function will be called with 50ms period */

uint8_t G_SCR_STATE = 0;
uint8_t G_CB_INITIAL = 0;
uint8_t CB_EVEN = 0;
uint8_t CB_ODD = 1;
uint8_t CB_DEFAULT = 2;
uint8_t selectscript_node_count = 0;
#if 1 // @SURE - ADDED
uint32_t state_machine_timestamp = 0;
#endif

void adi_example_select_script_statemachine(void){     

#if 1 // @SURE - ADDED
    //if(ADK_DEMO.AUTHORITY != 0/* MAIN */) return;
    //if((adi_wil_hal_TickerGetTimestamp() - state_machine_timestamp) < 10) // 10ms
    //{
    //    return;
    //}

    state_machine_timestamp = adi_wil_hal_TickerGetTimestamp();
    if(ADK_DEMO.DEMO_MODE != ADK_DEMO_MODE)
    {
        ADK_DEMO.DEMO_MODE = ADK_DEMO_MODE;
    }
#endif

    if(ADK_DEMO.DEMO_MODE == NORMAL_BMS_SENSING){
        if(BASE_PACKET_RECEIVED == false){
            /*************************** Normal BMS ***************************************/
            adi_wil_example_ExecuteSelectScript(&packInstance, ADI_WIL_DEV_ALL_NODES, ADI_WIL_SENSOR_ID_BMS, ADI_BMS_BASE_ID, NO_SET_MODE); // BASE
        }
        else{
            if(ADK_DEMO.PREV_MODE == CELL_BALANCING_EVEN || ADK_DEMO.PREV_MODE == CELL_BALANCING_ODD){
                adi_wil_example_ExecuteModifyScript(&packInstance, CB_DEFAULT);    //Default DCC
                for (selectscript_node_count = 0; selectscript_node_count < realAcl.iCount; selectscript_node_count++){
                    ADK_DEMO.NODE[selectscript_node_count].CB_STAT = 0;
                }
            }
            G_CB_INITIAL = 0;
        }
        ADK_DEMO.PREV_MODE = NORMAL_BMS_SENSING;
    }
    else if(ADK_DEMO.DEMO_MODE == CELL_BALANCING_EVEN){
        /*************************** Cell Balance *************************************/
        /* @warning : Cell balance scheduling period is depends on application scenario */
        if(BASE_PACKET_RECEIVED == false){
            /*************************** Normal BMS ***********************************/
            adi_wil_example_ExecuteSelectScript(&packInstance, ADI_WIL_DEV_ALL_NODES, ADI_WIL_SENSOR_ID_BMS, ADI_BMS_BASE_ID, NO_SET_MODE); // BASE
        }
        else{
            if(ADK_DEMO.PREV_MODE == CELL_BALANCING_ODD){
                adi_wil_example_ExecuteModifyScript(&packInstance, CB_DEFAULT);    //Default DCC
                for (selectscript_node_count = 0; selectscript_node_count < realAcl.iCount; selectscript_node_count++){
                    ADK_DEMO.NODE[selectscript_node_count].CB_STAT = 0;
                }
                G_CB_INITIAL = 0;
            }          
            if(G_CB_INITIAL == 0){
                adi_wil_example_ExecuteModifyScript(&packInstance, CB_EVEN);    //Even cells balancing                    
                G_CB_INITIAL = 1;
            }
        }
        ADK_DEMO.PREV_MODE = CELL_BALANCING_EVEN;
    }
    else if(ADK_DEMO.DEMO_MODE == CELL_BALANCING_ODD){
        /*************************** Cell Balance *************************************/
        /* @warning : Cell balance scheduling period is depends on application scenario */
        if(BASE_PACKET_RECEIVED == false){
            /*************************** Normal BMS ***********************************/
            adi_wil_example_ExecuteSelectScript(&packInstance, ADI_WIL_DEV_ALL_NODES, ADI_WIL_SENSOR_ID_BMS, ADI_BMS_BASE_ID, NO_SET_MODE); // BASE
        }
        else{
            if(ADK_DEMO.PREV_MODE == CELL_BALANCING_EVEN){
                adi_wil_example_ExecuteModifyScript(&packInstance, CB_DEFAULT);    //Default DCC
                for (selectscript_node_count = 0; selectscript_node_count < realAcl.iCount; selectscript_node_count++){
                    ADK_DEMO.NODE[selectscript_node_count].CB_STAT = 0;
                }
                G_CB_INITIAL = 0;
            }                   
            if(G_CB_INITIAL == 0){
                adi_wil_example_ExecuteModifyScript(&packInstance, CB_ODD);     //Odd cells balancing
                G_CB_INITIAL = 1;
            }        
        }        
        ADK_DEMO.PREV_MODE = CELL_BALANCING_ODD;
    }
    else if(ADK_DEMO.DEMO_MODE == KEY_ON_EVENT){
        if(KEY_ON == false)
        {
            KEY_ON = true;
            KEY_OFF = false;
            bFirstBMSdata=false;
            adi_example_key_on_event();
            ADK_DEMO.PREV_MODE = KEY_ON_EVENT;
        }
    }
    else if(ADK_DEMO.DEMO_MODE == KEY_OFF_EVENT){
        if(KEY_OFF == false)
        {
            adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
            KEY_OFF = true;
            KEY_ON = false;
            /* Set to Standby mode */
            noreturnOnWilError(adi_wil_SetMode(&packInstance, ADI_WIL_MODE_STANDBY));
            
            /* Wait for non-blocking API to complete */
            WaitForWilAPI(&packInstance);
            
            if(gNotifRc == ADI_WIL_ERR_PARTIAL_SUCCESS) {
                noreturnOnWilError(adi_wil_example_RetrySetMode(&packInstance, ADI_WIL_MODE_STANDBY));
            }
            ADK_DEMO.BOOT = 750;            

            /* Set to Sleep mode */
            noreturnOnWilError(adi_wil_SetMode(&packInstance, ADI_WIL_MODE_SLEEP));

            /* Wait for non-blocking API to complete */
            WaitForWilAPI(&packInstance);
            ADK_DEMO.BOOT = 751;
            
            /* Disconnect the pack from the system. This is a blocking call so no API
            callback is generated. */
            errorCode = adi_wil_Disconnect(&packInstance);

            if (errorCode != ADI_WIL_ERR_SUCCESS)
            {
                adk_debug_Report(DBG_wil_Disconnect, errorCode);
            }
            else
            {
                //adi_wil_ex_info("Disconnect from pack successful!");
            }
            ADK_DEMO.BOOT = 752;
            if ((errorCode = adi_wil_Terminate()) != ADI_WIL_ERR_SUCCESS)
            {
                adk_debug_Report(DBG_wil_Terminate, errorCode);
            }
            ADK_DEMO.BOOT = 753;
            ADK_DEMO.PREV_MODE = KEY_OFF_EVENT;
        }
    }
}

void adi_example_key_on_event(void){
    adi_wil_err_t rc;
    adi_wil_network_status_t networkStatus;
    ADK_DEMO.BOOT = 700;
    adk_debug_TickerBTInit();
    ADK_DEMO.BOOT = 701;
    adk_debug_BootTimeLog(Overall_, LogStart, 730, Demo_key_on_event_____________________);

    adk_debug_BootTimeLog(Interval, LogStart, 703, Demo_TaskStart________________________);
    adi_wil_example_ExecuteInitialize();
    ADK_DEMO.BOOT = 702;
    adi_wil_example_PeriodicallyCallProcessTask();
    ADK_DEMO.BOOT = 703;
    adk_debug_BootTimeLog(Interval, LogEnd__, 703, Demo_TaskStart________________________);

    adk_debug_BootTimeLog(Interval, LogStart, 710, Demo_ExcuteConnect____________________);
    rc = (adi_wil_example_ExecuteConnect(&packInstance,
                                        wbmsSysSensorData,
                                        (BMS_DATA_PACKET_COUNT + PMS_DATA_PACKET_COUNT + EMS_DATA_PACKET_COUNT)));
    ADK_DEMO.BOOT = 710;

    /* Set to Standby mode */
    noreturnOnWilError(adi_wil_SetMode(&packInstance, ADI_WIL_MODE_STANDBY));
    
    /* Wait for non-blocking API to complete */
    WaitForWilAPI(&packInstance);
    ADK_DEMO.BOOT = 711;
    adk_debug_BootTimeLog(Interval, LogEnd__, 710, Demo_ExcuteConnect____________________);

    if(realAcl.iCount == 0){          
        memcpy(&realAcl, &userAcl, sizeof(adi_wil_acl_t));
    }
    
    adk_debug_BootTimeLog(Interval, LogStart, 712, Demo_GetNetworkStatusACTmode__________);
    adi_wil_example_ExecuteGetNetworkStatus(&packInstance, &networkStatus, NO_SET_MODE);
    ADK_DEMO.BOOT = 712;
    adk_debug_BootTimeLog(Interval, LogEnd__, 712, Demo_GetNetworkStatusACTmode__________);

    adk_debug_BootTimeLog(Interval, LogStart, 720, Demo_TaskStartCB______________________);
    adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_ACTIVE);
    ADK_DEMO.BOOT = 713;
    adi_wil_EnableNetworkDataCapture(&packInstance, networkDataBuffer, (networkStatus.iCount*ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL), true);
    ADK_DEMO.BOOT = 714;
    adi_wil_example_PeriodicallyCallProcessTaskCB();
    ADK_DEMO.BOOT = 720;
    adk_debug_BootTimeLog(Interval, LogEnd__, 720, Demo_TaskStartCB______________________);

    if(true == adi_wil_example_SchedulerInit())
    {
        ADK_DEMO.BOOT = 999;
        adi_wil_example_scheduleTasks();
    }
    else
    {
        /* Scheduler Initialization Failed */
        while(1);
    }
}

void adi_example_null_function(void){
    
}
#if 1 // @SURE - ADDED
void adi_example_select_sensing(void)
{
    if(ADK_DEMO_MODE == NORMAL_BMS_SENSING) return;

    ADK_DEMO_MODE = NORMAL_BMS_SENSING;
}

/* parityFlag - none(0)/odd(1)/even(2) */
void adi_example_select_balancing(uint8_t parityFlag)
{
    switch(parityFlag)
    {
        // stop
        case 0:
            ADK_DEMO_MODE = NORMAL_BMS_SENSING;
        break;

        // odd:start
        case 1:
            ADK_DEMO_MODE = CELL_BALANCING_ODD;
        break;

        // oven:start
        case 2:
            ADK_DEMO_MODE = CELL_BALANCING_EVEN;
        break;
    }

}

void adi_example_select_owdetection(void)
{
    if(ADK_DEMO_MODE == OPEN_WIRE_DETECTION) return;

    ADK_DEMO_MODE = OPEN_WIRE_DETECTION;
}

bool adi_example_boot_end(void)
{
    return (ADK_DEMO.BOOT_STEP <= 90) ? false : true;
}

uint8_t adi_example_boot_step(void)
{
    return ADK_DEMO.BOOT_STEP;
}

#if 1 // V2.1.0 OTAP
uint8_t adi_example_otap_step(void)
{
    return ADK_DEMO.OTAP_STEP;
}

uint8_t adi_example_otap_phase(void)
{
    return ADK_DEMO.OTAP_PHASE;
}
#endif

void adi_example_forced_acl_update(bool forcedUpdate)
{
    ADK_DEMO.ACL_UPDATE_FORCE = forcedUpdate;
}

void adi_example_match_acl(void)
{
    uint8_t *pUAcl = (void *)0, *pRAcl = (void *)0;
    uint8_t r = 0, u = 0;
    uint8_t noNode = 0;

    for(u = 0; u < ADK_MAX_node; u++)
    {
        ADK_DEMO.NODE[u].DISCONN_STAT = true;
    }
    
    if(realAcl.iCount)
    {
        for(r = 0; r < realAcl.iCount; r++)
        {
            pRAcl = (uint8_t *)(realAcl.Data + (r * ADI_WIL_MAC_ADDR_SIZE));
            if((pRAcl[0] != 0x64) || (pRAcl[1] != 0xF9) || (pRAcl[2] != 0xC0)) continue;
            
            for(u = 0; u < userAcl.iCount; u++)
            {
                pUAcl = (uint8_t *)(userAcl.Data + (u * ADI_WIL_MAC_ADDR_SIZE));
                if((pUAcl[0] != 0x64) || (pUAcl[1] != 0xF9) || (pUAcl[2] != 0xC0)) continue;

                if(memcmp(pRAcl, pUAcl, ADI_WIL_MAC_ADDR_SIZE) == 0)
                {
                    ADK_DEMO.NODE[r].NO_OF_USERACL = u;
                }
            }
        }
    }

    for(r = 0; r < realAcl.iCount; r++)
    {
        noNode = ADK_DEMO.NODE[r].NO_OF_USERACL;
        if(noNode != 0xFF)
        {
            ADK_DEMO.NODE[r].DISCONN_STAT = false;
        }
    }
}

void adi_example_set_acl(uint8_t nodeCount, uint8_t *macAddress)
{
    uint8_t nCount = 0;
    uint8_t addressData[ADK_MAX_node * 8];
    
    nodeCount = 0;

    memset(addressData, 0x0, sizeof(addressData));
    for(nCount = 0; nCount < ADK_MAX_node; nCount++)
    {
        if(macAddress[nCount*9] == 1)
        {
            memcpy(&addressData[nodeCount*8], &macAddress[1 + (nCount*9)], 8);
            nodeCount++;
        }
    }

    if(nodeCount == 0)
    {
        // set default mac address
        adi_wil_acl_t userDefaultAcl = 
        {
            .iCount = 1,
            .Data = { // Node MAC address, MSB 5byte, LSB 3byte
                0x64, 0xF9, 0xC0, 0x00, 0x00, 0x03, 0xB7, 0xE5, // Node 0 #1
                { 0 }   /* pad out the rest of the structure with zeroes */
            }
        };
        
        memset(&userAcl, 0x0, sizeof(adi_wil_acl_t));
        userAcl.iCount = userDefaultAcl.iCount;
        //memset(userAcl.Data, 0x0, sizeof(userAcl.Data));
        memcpy(userAcl.Data, userDefaultAcl.Data, 8);
    }
    else
    {
        memset(&userAcl, 0x0, sizeof(adi_wil_acl_t));
        userAcl.iCount = nodeCount;
        //memset(userAcl.Data, 0x0, sizeof(userAcl.Data));
        memcpy(userAcl.Data, addressData, nodeCount * 8);
    }
}

void adi_example_set_standby(void)
{
    // ADRF8850 & ADRF8800
    ADK_DEMO_MODE = KEY_OFF_EVENT;
    KEY_OFF = false;
}

void adi_example_set_wakeup(void)
{
    // ADRF8850 & ADRF8800
    ADK_DEMO_MODE = KEY_ON_EVENT;
    KEY_ON = false;
}
#endif
