/*******************************************************************************
 * @file     adi_platform_app_wil_functions.c
 *
 * @brief    Platform Application WIL support functions
 *
 * @details  Include wrapping WIL functionality.
 *
 * Copyright (c) 2020-2021 Analog Devices, Inc. All Rights Reserved.
 * This software is proprietary and confidential to Analog Devices, Inc. and its licensors.
 *******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

#include "adi_wil.h"
#include "adi_wil_api.h"
#include "adi_wil_osal.h"
#include "adi_bms_container.h"
#include "adi_wil_example_cfg_profiles.h"
#include "adi_wil_example_utilities.h"
#include "adi_wil_example_config.h"
#include "adi_wil_example_functions.h"
#include "adi_wil_example_printf.h"
#include "adi_wil_example_version.h"
#include "adi_wil_example_w2can.h"
#include "adi_bms_defs.h"
#include "adi_wil_hal_task.h"
#include "adi_bms_types.h"
#include "adi_wil_example_acl.h"
#include "adi_wil_types.h"
#include "adi_wil_example_owd.h"
#include "adi_wil_hal_task_cb.h"
#include "adi_wil_example_cell_balance.h"
#include "adi_wil_example_debug_functions.h"
#include "wb_rsp_query_device.h"
#include "adi_wil_app_interface.h"

#if 1 // V2.1.0 OTAP
#include "otap_node_fpa.h"
#include "otap_mngr_fpa.h"
#include "otap_node_opfw_200.h"
#include "otap_mngr_opfw_200.h"
#include "otap_node_opfw_210.h"
#include "otap_mngr_opfw_210.h"
#endif

#include "adi_wil_example_PSFromLatency.h"

/* interval in microseconds between calls to adi_wil_ProcessTask() */
#define PROCESS_TASK_INTERVAL_USEC (2500)
#define PROCESS_TASK_CB_INTERVAL_USEC (50000) /* 50 ms */

/*******************************************************************************/
/* Embedded WIL Function Declarations                                          */
/*******************************************************************************/
extern void adi_wil_example_hal_spi_configure_speed(uint8_t api_port, uint32_t speed);
extern void WaitForWilAPI(adi_wil_pack_t * const pPack);
extern void adi_task_bmsDataRetrieval(void);
extern uint32_t adk_debug_TickerBTGetTimestamp(void);
extern uint32_t adi_wil_hal_TickerGetTimestamp(void);

extern void Adbms683x_Monitor_Base_Pkt0(adi_wil_sensor_data_t* BMSBufferPtr);
extern void Adbms683x_Monitor_Base_Pkt1(adi_wil_sensor_data_t* BMSBufferPtr);
extern void Adbms683x_Monitor_Base_Pkt2(adi_wil_sensor_data_t* BMSBufferPtr);
extern void Adbms683x_Monitor_Cell_OWD(adi_wil_device_t eNode);
extern void adk_debug_BootTimeLog(bool final, bool start, uint16_t step, ADK_LOG_FUNCTION api);
void adk_debug_log_GetDeviceVersion(ADK_OTAP_ARG_0 eDeviceID, ADK_OTAP_ARG_1 update, uint8_t idx);

extern uint8_t  iOWDPcktsRcvd[ADI_WIL_MAX_NODES];

void adk_debug_Report(ADK_FAIL_API_NAME api, adi_wil_err_t rc );
/*******************************************************************************/
/* Global Variable Declarations                                                */
/*******************************************************************************/
extern bool adi_gNotifyBmsData;
extern bool adi_gNotifyBms;
extern bool adi_gNotifyPms;
extern bool adi_gNotifyEms;
extern bool adi_gNotifyNetworkMeta;
extern adi_wil_network_status_t networkStatus;
bool adi_gFaultDetected;

extern volatile adi_wil_err_t adi_gProcessTaskErrorCode;
adi_wil_network_data_t   userNetworkBuffer[ADI_WIL_MAX_NODES * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL];
adi_wil_err_t gNotifRc;

extern uint32_t adi_gW2canNodeCount;
extern const uint8_t bms_container_file;
extern const uint8_t pms_container_file;

extern adi_wil_pack_t packInstance;

unsigned int temp_BMS=0;

uint8_t EventCallback_pkt_count = 0;
bool CB_EVEN_DCC_RECEIVED = false;
bool CB_ODD_DCC_RECEIVED = false;
bool CB_DEFAULT_DCC_RECEIVED = false;
bool BASE_PACKET_RECEIVED = false;
bool ACL_EMPTY = false;
bool KEY_ON = false;
bool KEY_OFF = false;
bool bFirstBMSdata = false;

extern bool gQueryDeviceRetry;     /*  @remark : request by sure-soft */

uint32_t NetworkStatusTmr = 0;      /* Support Network Status Timer */

static adi_wil_port_t              portArray[PORT_COUNT] = {
    [0]= {
        .iSPIDevice = PORT0_SPI_DEVICE,
        .iChipSelect = PORT0_CHIP_SELECT,
        // .Internals = { 0 }, /* for zero warning */
    },
    [1] = {
        .iSPIDevice = PORT1_SPI_DEVICE,
        .iChipSelect = PORT1_CHIP_SELECT,
        // .Internals = { 0 }, /* for zero warning */
    }
};


/* the wil *does* write to the internals element of the port_t so this needs to be static/global/long-lived */
adi_wil_port_t PortManager0 = {
    .iSPIDevice = 0,  /* we expect manager 0 to be available via SPI0 */
    .iChipSelect = 0,
    // .Internals = { 0 },
};

adi_wil_port_t PortManager1 = {
    .iSPIDevice = 1, /* we expect manager 1 to be available via SPI1 */
    .iChipSelect = 0,
    // .Internals = { 0 },
};

/* Flag, set to true to indicate queryDevice callback has been called */
bool volatile queryDeviceCallbackCalled = false;
/* Storage for the rc passed into queryDevice callback; allows application to read result of queryDevice call. */
adi_wil_err_t volatile queryDeviceRc = ADI_WIL_ERR_FAIL;
/* Pointer to storage for configuration information passed into queryDevice callback. */
adi_wil_configuration_t * pQueryDeviceConfig = (void*)0;

extern adi_wil_device_removed_t LF_NG_LIST[12];

/******************************************************************************
 * Static variable declarations
 *****************************************************************************/
static adi_wil_configuration_t      *pConfiguration;
static adi_wil_acl_t                systemAcl;
static adi_wil_contextual_data_t    returnedContextualData;
static adi_wil_gpio_value_t         returnedGpioValue;
static uint8_t                      returnedSoHValue;
adi_wil_api_t  logAPIInProgress;

volatile uint8_t iMgrConnectCount = 0, iMgrDisconnectCount = 0;

static volatile uint32_t      iBMSNotificationCount = 0u;
static volatile uint32_t      iPMSNotificationCount = 0u;
static volatile uint32_t      iEMSNotificationCount = 0u;
static volatile uint32_t      iQueueOverflowNotificationCount = 0u;
static volatile uint32_t      iNodeConnectedCount = 0u;
static volatile uint32_t      iNodeDisconnectedCount = 0u;
static volatile uint32_t      iMgrToMgrErrCount = 0u;
static volatile uint32_t      iSecurityEvtCount = 0u;
static volatile bool          bConnectApiCalled = false;

adi_wil_sensor_data_t           userBMSBuffer[BMS_DATA_PACKET_COUNT];
static adi_wil_sensor_data_t    userPMSBuffer[PMS_DATA_PACKET_COUNT];
static adi_wil_sensor_data_t    userEMSBuffer[EMS_DATA_PACKET_COUNT];
adi_wil_health_report0_t        userHR0Buffer[ADI_WIL_MAX_NODES];
adi_wil_health_report1_t        userHR1Buffer[ADI_WIL_MAX_NODES];
adi_wil_health_report2_t        userHR2Buffer[ADI_WIL_MAX_NODES];
adi_wil_health_report10_t       userHR10Buffer[NUM_OF_MANAGERS];
adi_wil_health_report11_t       userHR11Buffer[NUM_OF_MANAGERS];
adi_wil_health_report12_t       userHR12Buffer[NUM_OF_MANAGERS];
adi_wil_health_report14_t       userHR14Buffer[NUM_OF_MANAGERS];
adi_wil_health_report14_t       userHR15Buffer[NUM_OF_MANAGERS];
adi_wil_health_report14_t       userHR16Buffer[NUM_OF_MANAGERS];
adi_wil_health_report14_t       userHR17Buffer[NUM_OF_MANAGERS];
adi_wil_health_report14_t       userHR18Buffer[NUM_OF_MANAGERS];
adi_wil_health_report80_t       userHR80Buffer[ADI_WIL_MAX_NODES];
adi_wil_device_t                faultSources;
adi_wil_fault_report_t          faultReport;
adi_wil_file_crc_list_t         crclist;

uint16_t  nTotalPcktsRcvd = 0u;     /*  @remark : Variable to store total no. of bms packets received */

/******************************************************************************
 * Custom structure
 *****************************************************************************/
DISPLAYSTR ADK_DEMO;
extern BOOTTIMESTR BOOT_TIME;
extern uint16_t G_BOOT_TIME_CNT;

/******************************************************************************
 * Static function declaration
 *****************************************************************************/

/******************************************************************************/
/* Local Funtion Declarations                                                 */
/******************************************************************************/
void adi_wil_example_ADK_readBms(void);
static void adi_wil_example_ADK_PDR_calc(void);
// static void adi_wil_example_ADK_BGRSSI_calc(void);
adi_wil_err_t adi_wil_example_RetrySetMode(adi_wil_pack_t * const pPack, adi_wil_mode_t mode);
static void adi_task_serviceProcessTask(void);
bool adi_wil_example_PeriodicallyCallProcessTask(void);
bool adi_wil_example_PeriodicallyCallProcessTaskCB(void);
static void adi_task_serviceProcessTaskCB(void);

/*******************************************************************************/
/* Local Variable Declarations                                                 */
/*******************************************************************************/

/******************************************************************************
 * Functions exercising the WIL APIs
 *****************************************************************************/

/******************************************************************************
 * Example function using adi_wil_Initiialize.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteInitialize(void)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    /* Initialize the WIL */
    if ((errorCode = adi_wil_Initialize()) != ADI_WIL_ERR_SUCCESS)
    {
        adk_debug_Report(DBG_wil_Initialize, errorCode);
    }
    else
    {
        /* Success */
    }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_Terminate.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteTerminate(void)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    if ((errorCode = adi_wil_Terminate()) != ADI_WIL_ERR_SUCCESS)
    {
        adk_debug_Report(DBG_wil_Terminate, errorCode);
    }
    else
    {
        //adi_wil_ex_info("WIL termination successful!");
    }

    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_QueryDevice.
 * This example shows the API being called on both SPI ports and using the
 * results from the call to determine whether the 2 managers on the 2 ports
 * are in dual manager mode.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteQueryDevice(adi_wil_configuration_t* pPortConfig)
{
    /* Dummy pack instance */
    adi_wil_pack_t *pPackLock;
    (void)memset(&pPackLock, 0xFF, sizeof(void*));
#if 1 // @SURE - ADDED
    /* infineon <-> adrf8850 communication status */
    uint8_t queryDevError = 0x0;
#endif

    for(int i = 0; i < PORT_COUNT; i++)
    {
        pConfiguration = &pPortConfig[i];

#if 1 // @SURE - ADDED
        /* infineon <-> adrf8850 communication status */
        adi_wil_QueryDevice(&portArray[i]);
#else
        returnOnWilError(adi_wil_QueryDevice(&portArray[i]));
#endif

        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPackLock);

        if (gNotifRc != ADI_WIL_ERR_SUCCESS)
        {
#if 1 // @SURE - ADDED
            /* infineon <-> adrf8850 communication status */
            queryDevError = (uint8_t)(1 << i);
            ADK_DEMO.MNGR_STAT[i] = 1;
#else
            // adk_debug_Report(DBG_wil_QueryDevice, gNotifRc); /* Comment due to retry */
            return gNotifRc;
#endif
        }
        else
        {
#if 1 // @SURE - ADDED
            /* infineon <-> adrf8850 communication status */
#else
            gQueryDeviceRetry = true;
#endif
            /* Success */
        }
    }
#if 1 // @SURE - ADDED
    /* infineon <-> adrf8850 communication status */
    if(!queryDevError) 
    {
        gQueryDeviceRetry = true;
        /* Success */
    }
#endif    
    return ADI_WIL_ERR_SUCCESS;
}

/******************************************************************************
 * API callback function definition for QueryDevice.
 *****************************************************************************/
void adi_wil_HandlePortCallback (adi_wil_port_t const * const pPort,
                                 adi_wil_api_t eAPI,
                                 adi_wil_err_t rc,
                                 void const * const pData)
{
    queryDeviceCallbackCalled = true;
    queryDeviceRc = rc;

#if 1 // V2.1.0 OTAP
    if(ADK_DEMO.OTAP_STAT == Demo_OTAP_2_Confirm_Manager_FPA_______)
    {

        if (rc == ADI_WIL_ERR_SUCCESS)
        {
            adi_wil_configuration_t const * const pConfig = (adi_wil_configuration_t const *)pData;
            /* If somehow destination pointer is still null, don't do the memcpy */
            if (pQueryDeviceConfig != (void *)0)
            {
                memcpy(pQueryDeviceConfig, pConfig, sizeof(adi_wil_configuration_t));
            }
        }

    }
    else
    {
        if ((rc == ADI_WIL_ERR_SUCCESS) && (pData != (void*)0) && (pConfiguration != (void*)0))
        {
            memcpy(pConfiguration, pData, sizeof(adi_wil_configuration_t));
        }
    }
#else
    if ((rc == ADI_WIL_ERR_SUCCESS) && (pData != (void*)0) && (pConfiguration != (void*)0))
    {
        memcpy(pConfiguration, pData, sizeof(adi_wil_configuration_t));
    }
#endif

    gNotifRc = rc;
}

static adi_wil_port_t PortA, PortB;
adi_wil_sensor_data_t SensorDataArray[BMS_DATA_PACKET_COUNT];
adi_wil_pack_internals_t Internals;
adi_wil_safety_internals_t SafetyInternals;

/******************************************************************************
 * Example function using adi_wil_Connect.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteConnect(adi_wil_pack_t * const pPack,
                                             adi_wil_sensor_data_t *SensorData, uint8_t sysSensorPktCnt)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    // static adi_wil_port_t *pMgr1, *pMgr2;
    uint8_t mgrConnectionCount = 0;
    iMgrConnectCount = 0; 

    PortA.iSPIDevice = 0;
    PortA.iChipSelect = 0;
    PortB.iSPIDevice = 1;
    PortB.iChipSelect = 0;

    pPack->pInternals = &Internals;
    pPack->pSafetyInternals = &SafetyInternals;
    pPack->pDataBuffer = SensorData;
    pPack->pManager0Port = &PortA;
    pPack->pManager1Port = &PortB;
    pPack->iDataBufferCount = sysSensorPktCnt;
    pPack->pClientData = &ClientData;

    mgrConnectionCount = 2;
    // pMgr1 = &PortA;
    // pMgr2 = &PortB;

    /* Save the API function pointer */
    logAPIInProgress = ADI_WIL_API_CONNECT;

    /* Connect to the system */
    errorCode = adi_wil_Connect(pPack);

    if (errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_Connect, errorCode);

        return errorCode;
    } else {
                
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);
        
        errorCode = gNotifRc;        
    }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_Disconnect.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteDisconnect(adi_wil_pack_t * const pPack)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    //adi_wil_ex_info("Intiating disconnect from pack...");

    /* Disconnect the pack from the system. This is a blocking call so no API
       callback is generated. */
    errorCode = adi_wil_Disconnect(pPack);

    if (errorCode != ADI_WIL_ERR_SUCCESS)
    {
        adk_debug_Report(DBG_wil_Disconnect, errorCode);
    }
    else
    {
        //adi_wil_ex_info("Disconnect from pack successful!");
    }

    return errorCode;
}

/******************************************************************************
 * Helper function to adi_wil_SetMode.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_RetrySetMode(adi_wil_pack_t * const pPack, adi_wil_mode_t mode){
    uint8_t setModeRetries = 0;
    while((setModeRetries < ADI_WIL_SET_MODE_MAX_RETRIES) && (gNotifRc == ADI_WIL_ERR_PARTIAL_SUCCESS)){
        returnOnWilError(adi_wil_SetMode(pPack, mode));
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);
    }
    return gNotifRc;
}

/******************************************************************************
 * Example function using adi_wil_SetMode.
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteSetMode(adi_wil_pack_t * const pPack, adi_wil_mode_t mode) {

    adi_wil_mode_t currentMode;

    /*****************************Get Network Mode*****************************/
    //adi_wil_ex_info("Retrieving network mode...");
    returnOnWilError(adi_wil_example_ExecuteGetMode(pPack, &currentMode));

    if(currentMode ==  mode) {
        //adi_wil_ex_info("Network Mode already in desired state = %s", adi_wil_SystemModeToString(currentMode));
        return ADI_WIL_ERR_SUCCESS;
    }
    else {
        if( currentMode != ADI_WIL_MODE_STANDBY) {
            logAPIInProgress = ADI_WIL_API_SET_MODE;

            /* Set to Standby mode */
            //adi_wil_ex_info("Transitioning to Standby Mode");
            returnOnWilError(adi_wil_SetMode(pPack, ADI_WIL_MODE_STANDBY));
            
            /* Wait for non-blocking API to complete */
            WaitForWilAPI(pPack);
            
            if(gNotifRc == ADI_WIL_ERR_PARTIAL_SUCCESS) {
                returnOnWilError(adi_wil_example_RetrySetMode(pPack, ADI_WIL_MODE_STANDBY));
            }

            //adi_wil_ex_info("Transitioning to Standby Mode successful!");
            returnOnWilError(adi_wil_example_ExecuteGetMode(pPack, &currentMode));
        }
        if((currentMode == ADI_WIL_MODE_STANDBY) && (mode != ADI_WIL_MODE_STANDBY)) {
            logAPIInProgress = ADI_WIL_API_SET_MODE;

            /* Set to Desired mode */
            //adi_wil_ex_info("Setting Network Mode to %s", adi_wil_SystemModeToString(mode));
            returnOnWilError(adi_wil_SetMode(pPack, mode));
            
            /* Wait for non-blocking API to complete */
            WaitForWilAPI(pPack);

            if(gNotifRc == ADI_WIL_ERR_PARTIAL_SUCCESS) {
                returnOnWilError(adi_wil_example_RetrySetMode(pPack, mode));
            }

            //adi_wil_ex_info("Network Mode set to %s",adi_wil_SystemModeToString(mode));
        }
    }
    return ADI_WIL_ERR_SUCCESS;
}

/******************************************************************************
 * Example function using adi_wil_GetMode
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteGetMode(adi_wil_pack_t * const pPack,
                                             adi_wil_mode_t *pWilGetMode)
{
    returnOnWilError(adi_wil_GetMode(pPack, pWilGetMode));

    return ADI_WIL_ERR_SUCCESS;
}

/******************************************************************************
 * Example function using adi_wil_SetACL
 *****************************************************************************/
/**
 * @remark : inherit from TC375 project
 */
adi_wil_err_t adi_wil_example_ExecuteSetACL(uint8_t const * const pData, uint8_t iCount)
{
    returnOnWilError(adi_wil_SetACL(&packInstance, pData, iCount));

    /* Wait for non-blocking API to complete */
    WaitForWilAPI(&packInstance);

    /* If for some reason the set ACL did not succeed, display the failure code */
    returnOnWilError(gNotifRc);

    //adi_wil_ex_info("%s", "Set ACL successful!");
    return ADI_WIL_ERR_SUCCESS;
}

/******************************************************************************
 * Example function using adi_wil_GetACL
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteGetACL(adi_wil_pack_t * const pPack)
{
    /* Set the Network Mode to STANDBY.                                     */
    /* Note GetACL can be called from STANDBY, Monitoring and ACTIVE mode   */
    // returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY)); /* @remark : Already STANDBY mode at this moment */

    logAPIInProgress = ADI_WIL_API_GET_ACL;
    returnOnWilError(adi_wil_GetACL(pPack));
    
    /* Wait for non-blocking API to complete */
    WaitForWilAPI(pPack);
   
    //adi_wil_ex_info("ACL retrieval successful!");
    return ADI_WIL_ERR_SUCCESS;
}


/**
 * @remark : Not used this time
 */
#if 0

/******************************************************************************
 * Example function using adi_wil_SetContextualData
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteSetContextualData(adi_wil_pack_t * const pPack, 
                                                      adi_wil_device_t eDeviceId,
                                                      adi_wil_contextual_id_t eContextualId,
                                                      adi_wil_contextual_data_t * pContextualData)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    /* Set the Network Mode to STANDBY */
    returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));

    logAPIInProgress = ADI_WIL_API_SET_CONTEXTUAL_DATA;
    //adi_wil_ex_info("Setting contextual data for device = %s", adi_wil_DeviceToString(eDeviceId));
    errorCode = adi_wil_SetContextualData(pPack,
                                          eDeviceId,
                                          eContextualId,
                                          pContextualData);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_SetContextualData, errorCode);
    }
    else {
        
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);
        
        errorCode = gNotifRc;
        if (gNotifRc != ADI_WIL_ERR_SUCCESS) {
                adk_debug_Report(DBG_wil_SetContextualData_wait, errorCode);
            }
        }
    return errorCode;
}
/******************************************************************************
 * Example function using adi_wil_GetContextualData
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteGetContextualData(adi_wil_pack_t * const pPack, 
                                                      adi_wil_device_t eDeviceId,
                                                      adi_wil_contextual_id_t eContextualId)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    /* Set the Network Mode to STANDBY */
    returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));

    logAPIInProgress = ADI_WIL_API_GET_CONTEXTUAL_DATA;
    //adi_wil_ex_info("Getting contextual data for device = %s", adi_wil_DeviceToString(eDeviceId));
    errorCode = adi_wil_GetContextualData(pPack,
                                       eDeviceId,
                                       eContextualId);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_GetContextualData, errorCode);
    }
    else {
        
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        errorCode = gNotifRc;
        if (gNotifRc == ADI_WIL_ERR_SUCCESS) {
            //adi_wil_ex_info("Printing contextual data for Device %s", adi_wil_DeviceToString(eDeviceId));
            for(int j=0; j<returnedContextualData.iLength; j++) {
                //adi_wil_ex_info("Contextual data returned of index %d = %d",j, returnedContextualData.Data[j]);
                }
            }
        else {
            adk_debug_Report(DBG_wil_GetContextualData_wait, errorCode);
        }
    }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_SetGPIO
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteSetGpio(adi_wil_pack_t * const pPack, 
                                            adi_wil_device_t eDeviceId,
                                            adi_wil_gpio_id_t eGPIOId,
                                            adi_wil_gpio_value_t eGPIOValue)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    /* Set the Network Mode to STANDBY, SetGPIO functionality works in active and monitoring mode as well*/
    returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));

    logAPIInProgress = ADI_WIL_API_SET_GPIO;
    //adi_wil_ex_info("Setting %s of device %s to value %s",adi_wil_GpioIdTypeToString(eGPIOId), adi_wil_DeviceToString(eDeviceId), adi_wil_GpioValueTypeToString(eGPIOValue));
    errorCode = adi_wil_SetGPIO(pPack,
                                eDeviceId,
                                eGPIOId,
                                eGPIOValue);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_SetGPIO, errorCode);
    }
    else {
        
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        errorCode = gNotifRc;
        if (gNotifRc != ADI_WIL_ERR_SUCCESS) {
                adk_debug_Report(DBG_wil_SetGPIO_wait, errorCode);
            }
        }
    return errorCode;
}
/******************************************************************************
 * Example function using adi_wil_GetGPIO
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteGetGpio(adi_wil_pack_t * const pPack, 
                                            adi_wil_device_t eDeviceId,
                                            adi_wil_gpio_id_t eGPIOId)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    /* Set the Network Mode to STANDBY, GetGPIO functionality works in active and monitoring mode as well*/
    returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));

    logAPIInProgress = ADI_WIL_API_GET_GPIO;
    //adi_wil_ex_info("Getting %s value for device %s",adi_wil_GpioIdTypeToString(eGPIOId),adi_wil_DeviceToString(eDeviceId));
    errorCode = adi_wil_GetGPIO(pPack,
                                eDeviceId,
                                eGPIOId);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_GetGPIO, errorCode);
    }
    else {
        
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        errorCode = gNotifRc;
        if (gNotifRc == ADI_WIL_ERR_SUCCESS) {
            //adi_wil_ex_info("%s value of device %s = %s", adi_wil_GpioIdTypeToString(eGPIOId), adi_wil_DeviceToString(eDeviceId), adi_wil_GpioValueTypeToString(returnedGpioValue));
            }
        else {
             adk_debug_Report(DBG_wil_GetGPIO_wait, errorCode);
        }
    }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_SetStateOfHealth
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteSetStateOfHealth(adi_wil_pack_t * const pPack,
                                        adi_wil_device_t eDeviceId,
                                        uint8_t iPercentage)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    /* Set the Network Mode to STANDBY*/
    returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));

    logAPIInProgress = ADI_WIL_API_SET_STATE_OF_HEALTH;
    //adi_wil_ex_info("Setting State of Health value of device %s to value %d", adi_wil_DeviceToString(eDeviceId), iPercentage);
    errorCode = adi_wil_SetStateOfHealth(pPack,
                                         eDeviceId,
                                         iPercentage);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_SetStateOfHealth, errorCode);
    }
    else {
        
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        errorCode = gNotifRc;
        if (gNotifRc != ADI_WIL_ERR_SUCCESS) {
                adk_debug_Report(DBG_wil_SetStateOfHealth_wait, errorCode);
            }
        }
    return errorCode;
}
/******************************************************************************
 * Example function using adi_wil_GetStateOfHealth
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteGetStateOfHealth(adi_wil_pack_t * const pPack,
                                        adi_wil_device_t eDeviceId)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    /* Set the Network Mode to STANDBY*/
    returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));

    logAPIInProgress = ADI_WIL_API_GET_STATE_OF_HEALTH;
    //adi_wil_ex_info("Getting State of Health value for device %s",adi_wil_DeviceToString(eDeviceId));
    errorCode = adi_wil_GetStateOfHealth(pPack,
                                         eDeviceId);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_GetStateOfHealth, errorCode);
    }
    else {
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        errorCode = gNotifRc;
        if (gNotifRc == ADI_WIL_ERR_SUCCESS) {
            //adi_wil_ex_info("State of Health of device %s = %d", adi_wil_DeviceToString(eDeviceId), returnedSoHValue);
            }
        else {
             adk_debug_Report(DBG_wil_GetStateOfHealth_wait, errorCode);
        }
    }
    return errorCode;
}
#endif

/******************************************************************************
 * Example function using adi_wil_SelectScript
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteSelectScript(adi_wil_pack_t * const pPack,
                                                   adi_wil_device_t eDeviceId,
                                                   adi_wil_sensor_id_t eSensorId,
                                                   uint8_t iScriptId,
                                                   bool no_set_mode)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    if(no_set_mode == false){
        /* Set the Network Mode to ACTIVE */
        returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_ACTIVE));
    }

    logAPIInProgress = ADI_WIL_API_SELECT_SCRIPT;
    
    errorCode = adi_wil_SelectScript(pPack,
                                     eDeviceId,
                                     eSensorId,
                                     iScriptId);
    if(errorCode != ADI_WIL_ERR_SUCCESS) {
        adk_debug_Report(DBG_wil_SelectScript, errorCode);
    }
    else {
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        errorCode = gNotifRc;
        if (gNotifRc == ADI_WIL_ERR_SUCCESS) {
                /* Success */
            }
        else {
                adk_debug_Report(DBG_wil_SelectScript_wait, errorCode);
            }
        }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_GetNetworkStatus.
 * Return whether all nodes on the network has joined.
 *****************************************************************************/
bool ADK_NodeState[64] = {false,};
bool adi_wil_example_ExecuteGetNetworkStatus(adi_wil_pack_t * const pPack,
                                             adi_wil_network_status_t *pNetworkStatus, bool no_set_mode)
{
    bool bAllNodesJoined = false;
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    uint32_t NetworkStatusTmr_thr = 0;
    uint32_t idle_count = 0;

    if(no_set_mode == false){
        /* Set the Network Mode to COMMISSIONING */
        returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_COMMISSIONING));
    }
    NetworkStatusTmr_thr = NetworkStatusTmr;

    //adi_wil_ex_info("Waiting for nodes in the ACL list to join the network...");
    while (!bAllNodesJoined)
    {
        /* keep trying to execute command if there's another operation in progress */
        
        do{
            idle_count++;
            errorCode = adi_wil_GetNetworkStatus(pPack, pNetworkStatus);
        }
        while(errorCode == ADI_WIL_ERR_API_IN_PROGRESS);

        if(errorCode != ADI_WIL_ERR_SUCCESS)
        {
            //adi_wil_ex_error("%s returned with error: %s", __func__, adi_wil_ErrorToString(errorCode));
            return bAllNodesJoined;
        }
        if(pNetworkStatus->iCount == 0)
        {
            //adi_wil_ex_info("No nodes in the ACL list!");
             return bAllNodesJoined;
        }
        else
        {
            bAllNodesJoined = true;
            for(uint32_t i = 0; i < pNetworkStatus->iCount; i++)
            {
                ADK_NodeState[i] = pNetworkStatus->iConnectState & (1ULL<<i);
                if(!(ADK_NodeState[i]))
                {
                    bAllNodesJoined = false;
                }
            }
            if(!bAllNodesJoined)
            {
                // Some nodes are connected, not all
                // Compare to threshold
                if((NetworkStatusTmr - NetworkStatusTmr_thr) > NETWORK_STATUS_THRESHOLD)
                {
                    break;
                }
            }
        }
    }

    return bAllNodesJoined;
}

adi_wil_err_t adi_wil_example_otap_GetNetworkStatus(adi_wil_network_status_t * const pStatus)
{
    /* adi_wil_GetNetworkStatus() is a blocking call */
    adi_wil_err_t rc = adi_wil_GetNetworkStatus(&packInstance, pStatus);

    return rc;
}
uint8_t adi_wil_example_countUnconnectedNodes(void)
{
    adi_wil_network_status_t NetworkStatus;
    fatalOnWilError(adi_wil_example_otap_GetNetworkStatus(&NetworkStatus));

    uint8_t iUnconnectedNodeCount = 0;
    for(uint8_t iCount = 0; iCount < NetworkStatus.iCount; iCount++)
    {
        if (!((NetworkStatus.iConnectState) >> iCount)&0x1) {  iUnconnectedNodeCount++;  }
    }

    return iUnconnectedNodeCount;
}

/* Waits for all nodes to join the network before returning */
void adi_wil_example_waitForNodesToJoin(void)
{
    uint8_t unconnected_nodes = adi_wil_example_countUnconnectedNodes();

    if (unconnected_nodes == 0)
    {
        // info("All nodes have joined, no need to wait.");
    }
    else
    {
        adi_wil_mode_t eCurrentMode;
        adi_wil_example_ExecuteGetMode(&packInstance, &eCurrentMode);
        adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
        adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_COMMISSIONING);

        // info("Waiting for %u nodes to join the network....", unconnected_nodes);

        while (adi_wil_example_countUnconnectedNodes() != 0);

        /* Restore system mode we were in before going to commissioning */
        adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
        adi_wil_example_ExecuteSetMode(&packInstance, eCurrentMode);
    }
}

/******************************************************************************
 * Example function using adi_wil_example_processMac
 *****************************************************************************/
bool adi_wil_example_processMac(const volatile uint8_t *buf,
                 size_t iBufRemaining,
                 size_t *used,
                 uint8_t *dst)
{
    const size_t buf_sz = iBufRemaining;
    bool bHexIncr = true; /* Most significant nibble first */
    uint8_t iHexVal = 0;
    int bufIndex = 0;
    int iDstUsed = 0;

    while (bufIndex < buf_sz && iDstUsed < ADI_WIL_MAC_ADDR_SIZE) { /* a number */
        const uint8_t c = buf[bufIndex++];

        if (c >= 48 && c <= 57) { /* number */
            iHexVal |= (c - 48) << ((bHexIncr) ? 4 : 0);
        } else if (c >= 65 && c <= 70) { /* upper case hex */
            /* not 97 because we're adding 10 as it's hex [10..15] */
            iHexVal |= (c - 55) << ((bHexIncr) ? 4 : 0);
        } else if (c >= 97 && c <= 102) { /* lower case hex */
            /* not 97 because we're adding 10 as it's hex [10..15] */
            iHexVal |= (c - 87) << ((bHexIncr) ? 4 : 0);
        } else if (c == ',' && iDstUsed) {
            //adi_wil_ex_error("Malformed mac entry. ',' encountered early");
            break;
        } else if (c == ' ') { /* skip spaces */
            continue;
        } else {
            //adi_wil_ex_error("Unexpected character in mac: %c", c);
            break;
        }

        if (!bHexIncr) {
            dst[iDstUsed++] = iHexVal;
            iHexVal = 0;
        }
        bHexIncr = !bHexIncr;
    }

    *used = bufIndex;

    return iDstUsed == ADI_WIL_MAC_ADDR_SIZE;
}

/******************************************************************************
 * Example function using adi_wil_example_ExecuteLoadFile
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteLoadFile(adi_wil_pack_t * const pPack, adi_wil_file_type_t eFileType, adi_wil_device_t eDevice, bool no_set_mode)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;
    static uint8_t *pOtapImage;
    uint32_t iOtapImageLen;
    ClientData.LoadFileStatus.iOffset = 0;    
    uint32_t iImageLength = 0;
#if 1 // V2.1.0 OTAP
    uint8_t opfw_cnt = 0;
    float OTAP_Node_Prev[ADK_MAX_node] = {0,};
    float OTAP_Mng_Prev[2] = {0,};
#endif

    ADK_DEMO.LF_NG_CNT = 0; /* device removed counter clear */
    memset(&LF_NG_LIST, 0, sizeof(LF_NG_LIST)); /* device removed list clear */

    if(no_set_mode == false){
        /* Set the Network Mode to STANDBY */
        returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));
    }

    if(eFileType == ADI_WIL_FILE_TYPE_BMS_CONTAINER)
    {
        if ((eDevice == ADI_WIL_DEV_MANAGER_0) || (eDevice == ADI_WIL_DEV_MANAGER_1) || (eDevice == ADI_WIL_DEV_ALL_MANAGERS ))
        {
            if(eDevice == ADI_WIL_DEV_MANAGER_0) {
                /* @remark  : Not used this time */
            }
            if(eDevice == ADI_WIL_DEV_MANAGER_1) {
                /* @remark  : Not used this time */
            }
        }
        if((eDevice <= ADI_WIL_DEV_NODE_61) || ( eDevice == ADI_WIL_DEV_ALL_NODES ))
        {
            adi_bms_GetContainerPtr(&pOtapImage, &iOtapImageLen);
        }
    }
    else if(eFileType == ADI_WIL_FILE_TYPE_CONFIGURATION)
    {
        pOtapImage = (uint8_t *)&configuration_file_configuration;
        iOtapImageLen =  configuration_file_configuration_length;
    }
    else if(eFileType == ADI_WIL_FILE_TYPE_FIRMWARE)
    {
        if ((eDevice == ADI_WIL_DEV_MANAGER_0) || (eDevice == ADI_WIL_DEV_MANAGER_1) || (eDevice == ADI_WIL_DEV_ALL_MANAGERS ))
        {
            if(eDevice == ADI_WIL_DEV_MANAGER_0) {
                /* @remark  : Not used this time */
            }
            if(eDevice == ADI_WIL_DEV_MANAGER_1) {
                /* @remark  : Not used this time */
            }

#if 1 // V2.1.0 OTAP
            if((ADK_DEMO.OTAP_STAT >= Demo_OTAP_1_GetDeviceVersion_Mngr_Prev) && (ADK_DEMO.OTAP_STAT <= Demo_OTAP_1_Wait_for_Mngr_booting_____))
            {
                adi_bms_GetMngrFPAPtr(&pOtapImage, &iOtapImageLen);
            }
            else if((ADK_DEMO.OTAP_STAT >= Demo_OTAP_2_Initialization____________) && (ADK_DEMO.OTAP_STAT <= Demo_OTAP_2_GetDeviceVersion_Node_Next))
            {
                adi_bms_GetMngrOPFW200Ptr(&pOtapImage, &iOtapImageLen);
            }
            else if((ADK_DEMO.OTAP_STAT >= Demo_OTAP_3_SetMode_STANDBY_0_________) && (ADK_DEMO.OTAP_STAT <= Demo_OTAP_3_GetDeviceVersion_Node_Next))
            {
                adi_bms_GetMngrOPFW210Ptr(&pOtapImage, &iOtapImageLen);
            }
#endif
        }
        if((eDevice <= ADI_WIL_DEV_NODE_61) || ( eDevice == ADI_WIL_DEV_ALL_NODES ))
        {
#if 1 // V2.1.0 OTAP
            if((ADK_DEMO.OTAP_STAT >= Demo_OTAP_1_GetDeviceVersion_Mngr_Prev) && (ADK_DEMO.OTAP_STAT <= Demo_OTAP_1_Wait_for_Mngr_booting_____))
            {
                adi_bms_GetNodeFPAPtr(&pOtapImage, &iOtapImageLen);
            }
            else if((ADK_DEMO.OTAP_STAT >= Demo_OTAP_2_Initialization____________) && (ADK_DEMO.OTAP_STAT <= Demo_OTAP_2_GetDeviceVersion_Node_Next))
            {
                adi_bms_GetNodeOPFW200Ptr(&pOtapImage, &iOtapImageLen);
            }
            else if((ADK_DEMO.OTAP_STAT >= Demo_OTAP_3_SetMode_STANDBY_0_________) && (ADK_DEMO.OTAP_STAT <= Demo_OTAP_3_GetDeviceVersion_Node_Next))
            {
                adi_bms_GetNodeOPFW210Ptr(&pOtapImage, &iOtapImageLen);
            }
#else
            /* @remark  : Not used this time */
#endif
        }

    }

    /* File transfer loop */
    iImageLength = iOtapImageLen;
    do
    {
        if(iOtapImageLen > ADI_WIL_LOADFILE_DATA_SIZE)
        {
            iOtapImageLen = iImageLength - ClientData.LoadFileStatus.iOffset;
        }

        /* WIL API Call */
        logAPIInProgress = ADI_WIL_API_LOAD_FILE;
        do {
            do {
                errorCode = adi_gProcessTaskErrorCode;
            } while(errorCode != ADI_WIL_ERR_SUCCESS);
            errorCode = adi_wil_LoadFile(pPack, eDevice, eFileType, &pOtapImage[ClientData.LoadFileStatus.iOffset]);
        } while(errorCode == ADI_WIL_ERR_API_IN_PROGRESS);

        if (errorCode != ADI_WIL_ERR_SUCCESS)
        {
            /* Handle error */
            adk_debug_Report(DBG_wil_LoadFile, errorCode);
            if(errorCode == ADI_WIL_ERR_INVALID_PARAMETER)
                return errorCode;
            else
                break;
        }
        else
        {
            /* Wait for non-blocking API to complete */
            WaitForWilAPI(pPack);

            if(gNotifRc == ADI_WIL_ERR_FAIL || gNotifRc == ADI_WIL_ERR_TIMEOUT)
            {
                /* An error has occurred. The loading process has aborted. */
                /* No further API callbacks will occur. Re-start the OTAP. */
                ClientData.LoadFileStatus.iOffset = 0;
                iOtapImageLen = iImageLength;
                gNotifRc = ADI_WIL_ERR_IN_PROGRESS;
            }
            else if (gNotifRc == ADI_WIL_ERR_PARTIAL_SUCCESS){
                return ADI_WIL_ERR_SUCCESS;
            }
            else if ((gNotifRc != ADI_WIL_ERR_SUCCESS) && (gNotifRc != ADI_WIL_ERR_IN_PROGRESS)) {
                adk_debug_Report(DBG_wil_LoadFile_wait, errorCode);
                return gNotifRc;
            }
        }

#if 1 // V2.1.0 OTAP
        /* @remark : calculate progress for OTAP */
        if((eFileType == ADI_WIL_FILE_TYPE_FIRMWARE) && (ADK_DEMO.OTAP_STAT > Demo_OTAP_Update_Triggered____________) && (ADK_DEMO.OTAP_STAT < Demo_OTAP_Complete____________________)){
            if(eDevice == ADI_WIL_DEV_ALL_NODES){
                for(opfw_cnt = 0; opfw_cnt < realAcl.iCount; opfw_cnt++){
                    if(OTAP_Node_Prev[opfw_cnt] < (((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f))
                    {
                        ADK_DEMO.OTAP_NODE[opfw_cnt].OTAP____PROGRESS = ((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f;
                        OTAP_Node_Prev[opfw_cnt] = ((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f;
                    }
                }
            }
            else if(eDevice <= ADI_WIL_DEV_NODE_61){
                /* retry case */

            }

            if(eDevice == ADI_WIL_DEV_ALL_MANAGERS){
                if(OTAP_Mng_Prev[0] < (((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f))
                {
                    ADK_DEMO.OTAP_MNGR[0].OTAP____PROGRESS = ((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f;
                    OTAP_Mng_Prev[0] = ADK_DEMO.OTAP_MNGR[0].OTAP____PROGRESS;
                }
                if(OTAP_Mng_Prev[1] < (((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f))
                {
                    ADK_DEMO.OTAP_MNGR[1].OTAP____PROGRESS = ((float)(iImageLength - iOtapImageLen) / (float)iImageLength) * 100.0f;
                    OTAP_Mng_Prev[1] = ADK_DEMO.OTAP_MNGR[1].OTAP____PROGRESS;
                }
            }
            else if(eDevice <= ADI_WIL_DEV_NODE_61){
                /* retry case */

            }
        }
#endif
    } while (ADI_WIL_ERR_IN_PROGRESS == gNotifRc);

#if 1 // V2.1.0 OTAP
    /* @remark : calculate progress for OTAP */
    if((errorCode == ADI_WIL_ERR_SUCCESS) && (eFileType == ADI_WIL_FILE_TYPE_FIRMWARE) && (ADK_DEMO.OTAP_STAT > Demo_OTAP_Update_Triggered____________) && (ADK_DEMO.OTAP_STAT < Demo_OTAP_Complete____________________)){
        if(eDevice == ADI_WIL_DEV_ALL_NODES){
            for(opfw_cnt = 0; opfw_cnt < realAcl.iCount; opfw_cnt++){                    
                ADK_DEMO.OTAP_NODE[opfw_cnt].OTAP____PROGRESS = 100.0f;
            }
        }
        if(eDevice == ADI_WIL_DEV_ALL_MANAGERS){             
            ADK_DEMO.OTAP_MNGR[0].OTAP____PROGRESS = 100.0f;
            ADK_DEMO.OTAP_MNGR[1].OTAP____PROGRESS = 100.0f;
        }
    }
#endif

    return errorCode;
}

void adi_wil_example_LoadFileRetry(adi_wil_file_type_t eFileType, adi_wil_device_t eDevice)
{
    adi_wil_device_t iTargetDevices;
    bool retry_bAllNodesJoined = false;
    uint8_t LF_NG_CNT = 0;

    if(ADK_DEMO.LF_NG_CNT > 0)
    {   
        /* Commissioning again */
        do{
            retry_bAllNodesJoined = adi_wil_example_ExecuteGetNetworkStatus(&packInstance, &networkStatus, SET_MODE);
            if(!retry_bAllNodesJoined){
                adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
                adi_wil_example_ExecuteResetDevice(&packInstance, eDevice);
            }
        }while(!retry_bAllNodesJoined);
        adi_wil_example_ExecuteSetMode(&packInstance, ADI_WIL_MODE_STANDBY);
        
        /* retry logic */
        do{
            iTargetDevices = 0;
            for(LF_NG_CNT = 0; LF_NG_CNT < ADK_DEMO.LF_NG_CNT; LF_NG_CNT++)
            {
                iTargetDevices |= LF_NG_LIST[LF_NG_CNT].eDeviceId;
            }
            fatalOnWilError(adi_wil_example_ExecuteLoadFile(&packInstance, eFileType, iTargetDevices, NO_SET_MODE));
        }while(ADK_DEMO.LF_NG_CNT != 0);
    }
}

/* Waits for event eEventCode to occur iCount times before returning */
void adi_wil_example_waitForEvent(adi_wil_event_id_t eEventCode, uint32_t iCount)
{
    // info("Waiting for %u %s event(s)", iCount, adi_wil_EventToString(eEventCode));

    /* Set the event to wait for and reset event counter */
    ClientData.eEventWaitingFor = eEventCode;
    ClientData.iEventWaitingForCount = 0;

    for(uint32_t i = 0; i < iCount; i++)
    {
        uint32_t startTime = adi_wil_hal_TickerGetTimestamp();
        uint32_t promptTime = WAIT_FOR_EVENT_PROMPT_INITIAL_MSEC;
        /* use a volatile pointer, this prevents compiler from optimizing away the wait loop */
        uint32_t volatile * pEventCount = &ClientData.iEventWaitingForCount;
        while (*pEventCount == i)
        {
            uint32_t currentTime = adi_wil_hal_TickerGetTimestamp();
            if ((currentTime - startTime) >= promptTime)
            {
                // info("Example has been waiting for %u seconds. This may indicate an external problem e.g. a node or a manager has lost power.", (promptTime / 1000));
                // info("If this wait is not expected, please check your system. You may then need to restart the example.");
                promptTime += WAIT_FOR_EVENT_PROMPT_REPEAT_MSEC;
            }
        }

        // info("  Count %u", i);
    }
}

/******************************************************************************
 * adi_wil_example_PrintACL
 *****************************************************************************/
void adi_wil_example_PrintACL(adi_wil_pack_t * const pPack)
{
    for (int i=0; i < systemAcl.iCount; i++) {
        //adi_wil_ex_info("MAC entry %d : %02X%02X%02X",
//             i,
//             systemAcl.Data[(i*ADI_WIL_MAC_ADDR_SIZE)+5],
//             systemAcl.Data[(i*ADI_WIL_MAC_ADDR_SIZE)+6],
//             systemAcl.Data[(i*ADI_WIL_MAC_ADDR_SIZE)+7]);
    }
}

/******************************************************************************
 * Example function using adi_wil_example_ProcessTask
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ProcessTask(adi_wil_pack_t * const pPack)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    /* Wait till event is processed */
    errorCode = adi_wil_ProcessTask(pPack);

    if (errorCode != ADI_WIL_ERR_SUCCESS)
    {
        if(!bConnectApiCalled)
        {
            /**
             * If adi_wil_ProcessTask is called with an uninitialized pack object 
             * (as it may happen if adi_wil_ProcessTask is in a separate thread or 
             * adi_wil_QueryDevice is being executed), the API may return ADI_WIL_ERR_INVALID_PARAMETER
             * which is expected and it should be ignored by the host application. 
             * The pack is initialzed after calling teh Conenct API
             * adi_wil_ProcessTask now also returns ADI_WIL_ERR_API_IN_PROGRESS
             * since it now acquires a lock before proceeding with pack processing.
             * The processTask now just reuses the global lock, which QueryDevice 
             * uses when it?�쎌??running, hence the return code ADI_WIL_ERR_API_IN_PROGRESS
             * which is also expected.
             */
            if (!((errorCode == ADI_WIL_ERR_API_IN_PROGRESS) ||
                  (errorCode == ADI_WIL_ERR_INVALID_PARAMETER)))
            {
                adk_debug_Report(DBG_wil_ProcessTask_0, errorCode);
            }
        }
        else
        {
            adk_debug_Report(DBG_wil_ProcessTask_1, errorCode);
        }
    }
    return errorCode;
}

/******************************************************************************
 * print_welcome message
 *****************************************************************************/
void adi_wil_example_print_welcome(void)
{    
    adi_wil_version_t version;
    adi_wil_GetWILSoftwareVersion(&version);
}

/******************************************************************************
 * Example function using adi_wil_GetDeviceVersion
 *****************************************************************************/
adi_wil_err_t adi_wil_example_GetDeviceVersion(adi_wil_pack_t * const pPack, adi_wil_device_t eDevice, bool no_set_mode)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    if(no_set_mode == false){
        /* Set the Network Mode to STANDBY */
        returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));
    }

    /* Save the API function pointer */
    logAPIInProgress = ADI_WIL_API_GET_DEVICE_VERSION;

    /* Call the adi_wil_GetDeviceVersion API */
    errorCode = adi_wil_GetDeviceVersion(pPack, eDevice);
    if (errorCode != ADI_WIL_ERR_SUCCESS)
    {
        /* Handle error */
        adk_debug_Report(DBG_wil_GetDeviceVersion, errorCode);
    }
    else
    {
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);
    }

    /* Check for rc from the API callback and print out the main processor device information and silicon version */
    if (gNotifRc == ADI_WIL_ERR_SUCCESS){
        // adi_wil_ex_info("Device S/W Version Information: %d.%d.%d.%d",
        // deviceVersion.MainProcSWVersion.iVersionMajor,
        // deviceVersion.MainProcSWVersion.iVersionMinor,
        // deviceVersion.MainProcSWVersion.iVersionPatch,
        // deviceVersion.MainProcSWVersion.iVersionBuild);
        // adi_wil_ex_info("Device Silicon Version Information: %d.%d", deviceVersion.iMainProcSiVersion, deviceVersion.iCoProcSiVersion);
    }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_GetFileCRC
 *****************************************************************************/
adi_wil_err_t adi_wil_example_GetFileCRC(adi_wil_pack_t * const pPack,
                                         adi_wil_device_t eDevice,
                                         adi_wil_file_type_t eFileType, 
                                         bool no_set_mode)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    if(no_set_mode == false){
        /* Set the Network Mode to STANDBY */
        returnOnWilError(adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY));
    }

    /* Save the API function pointer */
    logAPIInProgress = ADI_WIL_API_GET_FILE_CRC;

    /* Call the adi_wil_GetFileCRC API */
    errorCode = adi_wil_GetFileCRC(pPack, eDevice, eFileType);
    if (errorCode != ADI_WIL_ERR_SUCCESS)
    {
        /* Handle error */
        adk_debug_Report(DBG_wil_GetFileCRC, errorCode);
    }
    else
    {
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);
    }

    /* Check for rc from the API callback and print out the container details */
     errorCode = gNotifRc;
    if (gNotifRc == ADI_WIL_ERR_SUCCESS){
        // adi_wil_ex_info("Container details on device %s corresponding to sensorID type %s as follows:-",adi_wil_DeviceToString(eDevice), adi_wil_SensorIdTypeToString(eSensorId));   /* @remark : Not used this time */
        //adi_wil_ex_info("Container ID : %d", containerDetails.iContainerId);
        //adi_wil_ex_info("Container Version : %d", containerDetails.iVersion);
        //adi_wil_ex_info("Container Hash : 0x%08X", containerDetails.iHash);
    }
    else {
        adk_debug_Report(DBG_wil_GetFileCRC_wait, errorCode);
    }
    return errorCode;
}

/******************************************************************************
 * Example function using adi_wil_EraseFile
 *****************************************************************************/
adi_wil_err_t adi_wil_example_EraseFile(adi_wil_pack_t * const pPack,
                                        adi_wil_device_t eDeviceId,
                                        adi_wil_file_type_t eFileType)
{
    adi_wil_err_t errorCode = ADI_WIL_ERR_SUCCESS;

    /* Set the Network Mode to STANDBY */
    adi_wil_example_ExecuteSetMode(pPack, ADI_WIL_MODE_STANDBY);

    /* Save the API function pointer */
    logAPIInProgress = ADI_WIL_API_ERASE_FILE;

    /* Call the adi_wil_EraseFile API */
    errorCode = adi_wil_EraseFile(pPack, eDeviceId, eFileType);
    if (errorCode != ADI_WIL_ERR_SUCCESS)
    {
        /* Handle error */
        adk_debug_Report(DBG_wil_EraseFile, errorCode);
    }
    else
    {
        /* Wait for non-blocking API to complete */
        WaitForWilAPI(pPack);

        /* Check for rc from the API callback and print out error if it was not a success*/
        errorCode = gNotifRc;
        if (gNotifRc == ADI_WIL_ERR_SUCCESS) {
            // adi_wil_ex_info("%s file erased from %s", adi_wil_FileTypeToString(eFileType), adi_wil_DeviceToString(eDeviceId));   /* @remark : Not used this time */
        }
        else {
            adk_debug_Report(DBG_wil_EraseFile_wait, errorCode);
        }
    }
    return errorCode;
}

/******************************************************************************
 * Example function that returns true if manager pair is configured in dual
 * manager configuration.
 *****************************************************************************/
bool adi_wil_example_isDualConfig(adi_wil_configuration_t * C1, adi_wil_configuration_t * C2, adi_wil_port_t* pPort)
{
    bool rc = false;
    uint8_t BlankMac[ADI_WIL_MAC_ADDR_SIZE] = {0};
    if (C1->bDualConfiguration && C2->bDualConfiguration && /* Compare bDualConfiguration */
        (!memcmp(C1->PeerMAC, C2->MAC, ADI_WIL_MAC_ADDR_SIZE)) && (!memcmp(C2->PeerMAC, C1->MAC, ADI_WIL_MAC_ADDR_SIZE)) && /* Compare MAC and PeerMAC */
        (C1->iConfigurationHash == C2->iConfigurationHash))
    {
        //adi_wil_ex_info("Manager connected to SPI device %d and Manager connected to SPI device %d are configured in Dual manager mode!",pPort[0].iSPIDevice,pPort[1].iSPIDevice);
        rc = true;
    }
    if (!memcmp(C1->PeerMAC, BlankMac, ADI_WIL_MAC_ADDR_SIZE))
    {
        //adi_wil_ex_info("Manager connected to SPI device %d is in single manager mode.",pPort[0].iSPIDevice); 
    }
    if (!memcmp(C2->PeerMAC, BlankMac, ADI_WIL_MAC_ADDR_SIZE))
    {
        //adi_wil_ex_info("Manager connected to SPI device %d is in single manager mode.",pPort[1].iSPIDevice);
    }
    return rc;
}


uint8_t iPacketLostData = 0;

/**
 * @remark : custome function for ADK
 */

void adi_wil_example_ADK_ExecuteProcessBMSBuffer(void)
{

#if BMS_PACKETS_PRINTING_ON
    //adi_wil_ex_info("BMS Received from Node %d\t\tBMS Packet count: %d", userBMSBuffer->eDeviceId, iBMSNotificationCount);
#endif

    adi_wil_example_ADK_readBms();            /* @remark : Read BMS data */
}

/* @remark : Custom global variables */
#define CELL_UNIT   150.0f
#define CELL_OFFSET   1.5f
#define NODE_NUM    realAcl.iCount 

#if     (ADK_ADBMS683x == 0) /* ADBMS6830 */
int16_t temp_buffer[20] = {0,};
#elif   (ADK_ADBMS683x == 3) /* ADBMS6833 */
int16_t temp_buffer[22] = {0,};
#else   /* Not supported */
#endif

#ifdef DBG_TEMP_TEST
uint32_t TEMP_ZERO[4] = {0,};
float TEMP_V2_MAX = -100;
float TEMP_V2_MIN = 100;
float TEMP_V3_MAX = -100;
float TEMP_V3_MIN = 100;
#endif 

#ifdef DBG_PACKET_ID_TEST
static uint8_t index = 0;
uint32_t TEMP_PACKET_ID[50] = {0,};
uint32_t TEMP_DEVICE_ID[50] = {0,};
#endif

#define TEST_BUFFER_MAX     20
uint32_t TEMP_BUFFER_ZERO[TEST_BUFFER_MAX] = {0,};
uint8_t recv_confirm[ADK_MAX_node] = {0,};

#if 1 // @SURE - ADDED
#define OVER_VOLTAGE(v)          ((v >= 0x50BC) ? 0x1 : 0x0) /* 0x50BC=20668, 20668+CELL_OFFSET=4.6V */
#endif

#if 0 // @SURE - ADDED
adi_bms_base_pkt_0_t gBMS_Packet_0_Ptr;
adi_bms_base_pkt_1_t gBMS_Packet_1_Ptr;
adi_bms_base_pkt_2_t gBMS_Packet_2_Ptr;
#endif

void adi_wil_example_ADK_readBms(void)
{
    uint8_t pkt_count = 0;
    uint8_t BMS_packetId = 0;
    uint8_t BMS_eNode = 100;
#if 0 // @SURE - ADDED
    adi_bms_base_pkt_0_t *BMS_Packet_0_Ptr = &gBMS_Packet_0_Ptr;
    adi_bms_base_pkt_1_t *BMS_Packet_1_Ptr = &gBMS_Packet_1_Ptr;
    adi_bms_base_pkt_2_t *BMS_Packet_2_Ptr = &gBMS_Packet_2_Ptr;
#else
    adi_bms_base_pkt_0_t* BMS_Packet_0_Ptr;
    adi_bms_base_pkt_1_t* BMS_Packet_1_Ptr;
    adi_bms_base_pkt_2_t* BMS_Packet_2_Ptr;
#endif
    uint8_t temp_recv_confirm[ADK_MAX_node] = {0,};

    for(pkt_count = 0; pkt_count < nTotalPcktsRcvd; pkt_count++){

        BMS_eNode = ADK_ConvertDeviceId(userBMSBuffer[pkt_count].eDeviceId);
        BMS_packetId = userBMSBuffer[pkt_count].Data[0];
                
        if(BMS_packetId == ADI_BMS_BASE_PKT_0_ID ){
            temp_recv_confirm[BMS_eNode] |= 0x01;
#if 0 // @SURE - ADDED
            memcpy(BMS_Packet_0_Ptr, (adi_bms_base_pkt_0_t*) &userBMSBuffer[pkt_count].Data, sizeof(adi_bms_base_pkt_0_t));
#else
            BMS_Packet_0_Ptr = (adi_bms_base_pkt_0_t*) &userBMSBuffer[pkt_count].iLength;
#endif
            
            #if   (ADK_ADBMS683x == 0) /* ADBMS6830 */
            /* @remark : Read raw data (float) */
            temp_buffer[0]  = (signed short int)((BMS_Packet_0_Ptr->Rdfca.iFc1v[1]  << 8) + BMS_Packet_0_Ptr->Rdfca.iFc1v[0]);
            temp_buffer[1]  = (signed short int)((BMS_Packet_0_Ptr->Rdfca.iFc2v[1]  << 8) + BMS_Packet_0_Ptr->Rdfca.iFc2v[0]);
            temp_buffer[2]  = (signed short int)((BMS_Packet_0_Ptr->Rdfca.iFc3v[1]  << 8) + BMS_Packet_0_Ptr->Rdfca.iFc3v[0]);
            temp_buffer[3]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcb.iFc4v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcb.iFc4v[0]);
            temp_buffer[4]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcb.iFc5v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcb.iFc5v[0]);
            temp_buffer[5]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcb.iFc6v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcb.iFc6v[0]);
            temp_buffer[6]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcc.iFc7v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcc.iFc7v[0]);
            temp_buffer[7]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcc.iFc8v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcc.iFc8v[0]);
            temp_buffer[8]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcc.iFc9v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcc.iFc9v[0]);
            temp_buffer[9]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcd.iFc10v[1] << 8) + BMS_Packet_0_Ptr->Rdfcd.iFc10v[0]);
            temp_buffer[10] = (signed short int)((BMS_Packet_0_Ptr->Rdfcd.iFc11v[1] << 8) + BMS_Packet_0_Ptr->Rdfcd.iFc11v[0]);
            temp_buffer[11] = (signed short int)((BMS_Packet_0_Ptr->Rdfcd.iFc12v[1] << 8) + BMS_Packet_0_Ptr->Rdfcd.iFc12v[0]);
            temp_buffer[12] = (signed short int)((BMS_Packet_0_Ptr->Rdfce.iFc13v[1] << 8) + BMS_Packet_0_Ptr->Rdfce.iFc13v[0]);
            temp_buffer[13] = (signed short int)((BMS_Packet_0_Ptr->Rdfce.iFc14v[1] << 8) + BMS_Packet_0_Ptr->Rdfce.iFc14v[0]);
            temp_buffer[14] = (signed short int)((BMS_Packet_0_Ptr->Rdfce.iFc15v[1] << 8) + BMS_Packet_0_Ptr->Rdfce.iFc15v[0]);
            temp_buffer[15] = (signed short int)((BMS_Packet_0_Ptr->Rdfcf.iFc16v[1] << 8) + BMS_Packet_0_Ptr->Rdfcf.iFc16v[0]);
            temp_buffer[16] = (signed short int)((BMS_Packet_0_Ptr->Rdauxa.iG1v[1]  << 8) + BMS_Packet_0_Ptr->Rdauxa.iG1v[0]);
            temp_buffer[17] = (signed short int)((BMS_Packet_0_Ptr->Rdauxa.iG2v[1]  << 8) + BMS_Packet_0_Ptr->Rdauxa.iG2v[0]);
            temp_buffer[18] = (signed short int)((BMS_Packet_0_Ptr->Rdauxa.iG3v[1]  << 8) + BMS_Packet_0_Ptr->Rdauxa.iG3v[0]);
            temp_buffer[19] = (signed short int)((BMS_Packet_0_Ptr->Rdauxb.iG4v[1]  << 8) + BMS_Packet_0_Ptr->Rdauxb.iG4v[0]);
            #elif(ADK_ADBMS683x == 3) /* ADBMS6833 */
            /* @remark : Read raw data (float) */
            temp_buffer[0]  = (signed short int)((BMS_Packet_0_Ptr->Rdfca.iFc2v[1]   << 8) + BMS_Packet_0_Ptr->Rdfca.iFc2v[0]);
            temp_buffer[1]  = (signed short int)((BMS_Packet_0_Ptr->Rdfca.iFc3v[1]   << 8) + BMS_Packet_0_Ptr->Rdfca.iFc3v[0]);
            temp_buffer[2]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcb.iFc4v[1]   << 8) + BMS_Packet_0_Ptr->Rdfcb.iFc4v[0]);
            temp_buffer[3]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcb.iFc5v[1]   << 8) + BMS_Packet_0_Ptr->Rdfcb.iFc5v[0]);
            temp_buffer[4]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcb.iFc6v[1]   << 8) + BMS_Packet_0_Ptr->Rdfcb.iFc6v[0]);
            temp_buffer[5]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcc.iFc7v[1]   << 8) + BMS_Packet_0_Ptr->Rdfcc.iFc7v[0]);
            temp_buffer[6]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcc.iFc8v[1]   << 8) + BMS_Packet_0_Ptr->Rdfcc.iFc8v[0]);
            temp_buffer[7]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcc.iFc9v[1]   << 8) + BMS_Packet_0_Ptr->Rdfcc.iFc9v[0]);
            temp_buffer[8]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcd.iFc11v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcd.iFc11v[0]);
            temp_buffer[9]  = (signed short int)((BMS_Packet_0_Ptr->Rdfcd.iFc12v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcd.iFc12v[0]);
            temp_buffer[10] = (signed short int)((BMS_Packet_0_Ptr->Rdfce.iFc13v[1]  << 8) + BMS_Packet_0_Ptr->Rdfce.iFc13v[0]);
            temp_buffer[11] = (signed short int)((BMS_Packet_0_Ptr->Rdfce.iFc14v[1]  << 8) + BMS_Packet_0_Ptr->Rdfce.iFc14v[0]);
            temp_buffer[12] = (signed short int)((BMS_Packet_0_Ptr->Rdfce.iFc15v[1]  << 8) + BMS_Packet_0_Ptr->Rdfce.iFc15v[0]);
            temp_buffer[13] = (signed short int)((BMS_Packet_0_Ptr->Rdfcf.iFc16v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcf.iFc16v[0]);
            temp_buffer[14] = (signed short int)((BMS_Packet_0_Ptr->Rdfcf.iFc17v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcf.iFc17v[0]);
            temp_buffer[15] = (signed short int)((BMS_Packet_0_Ptr->Rdfcf.iFc18v[1]  << 8) + BMS_Packet_0_Ptr->Rdfcf.iFc18v[0]);
            temp_buffer[16] = (signed short int)((BMS_Packet_0_Ptr->Rdauxa.iG1v[1]   << 8) + BMS_Packet_0_Ptr->Rdauxa.iG1v[0]);
            temp_buffer[17] = (signed short int)((BMS_Packet_0_Ptr->Rdauxa.iG2v[1]   << 8) + BMS_Packet_0_Ptr->Rdauxa.iG2v[0]);
            temp_buffer[18] = (signed short int)((BMS_Packet_0_Ptr->Rdauxa.iGa11v[1] << 8) + BMS_Packet_0_Ptr->Rdauxa.iGa11v[0]);
            temp_buffer[19] = (signed short int)((BMS_Packet_0_Ptr->Rdauxe.iG3v[1]   << 8) + BMS_Packet_0_Ptr->Rdauxe.iG3v[0]);
            #else   /* Not supported */
            #endif

            for(int i = 0; i < TEST_BUFFER_MAX; i++){
                if(temp_buffer[i] == 0)
                {
                    TEMP_BUFFER_ZERO[i]++;
                }
            }            

            /* @remark : Cell voltage convert (float) */
            ADK_DEMO.NODE[BMS_eNode].CELL_V[0]  = (float)(temp_buffer[0]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[1]  = (float)(temp_buffer[1]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[2]  = (float)(temp_buffer[2]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[3]  = (float)(temp_buffer[3]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[4]  = (float)(temp_buffer[4]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[5]  = (float)(temp_buffer[5]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[6]  = (float)(temp_buffer[6]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[7]  = (float)(temp_buffer[7]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[8]  = (float)(temp_buffer[8]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[9]  = (float)(temp_buffer[9]  * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[10] = (float)(temp_buffer[10] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[11] = (float)(temp_buffer[11] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[12] = (float)(temp_buffer[12] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[13] = (float)(temp_buffer[13] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[14] = (float)(temp_buffer[14] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].CELL_V[15] = (float)(temp_buffer[15] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;

            /* @remark : Cell voltage convert (int16) */
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[0]  = temp_buffer[0]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[1]  = temp_buffer[1]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[2]  = temp_buffer[2]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[3]  = temp_buffer[3]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[4]  = temp_buffer[4]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[5]  = temp_buffer[5]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[6]  = temp_buffer[6]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[7]  = temp_buffer[7]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[8]  = temp_buffer[8]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[9]  = temp_buffer[9]   + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[10] = temp_buffer[10]  + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[11] = temp_buffer[11]  + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[12] = temp_buffer[12]  + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[13] = temp_buffer[13]  + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[14] = temp_buffer[14]  + 10000;
            ADK_DEMO.NODE[BMS_eNode].CELL_Vi[15] = temp_buffer[15]  + 10000;

            /* @remark : AUX voltage convert (float) */
            ADK_DEMO.NODE[BMS_eNode].TEMP_V[0]  = (float)(temp_buffer[16] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].TEMP_V[1]  = (float)(temp_buffer[17] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].TEMP_V[2]  = (float)(temp_buffer[18] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;
            ADK_DEMO.NODE[BMS_eNode].TEMP_V[3]  = (float)(temp_buffer[19] * CELL_UNIT / 1000000.0f) + CELL_OFFSET;

            /* @remark : AUX voltage convert (int16) */
            ADK_DEMO.NODE[BMS_eNode].TEMP_Vi[0]  = temp_buffer[16] + 10000;  
            ADK_DEMO.NODE[BMS_eNode].TEMP_Vi[1]  = temp_buffer[17] + 10000;  
            ADK_DEMO.NODE[BMS_eNode].TEMP_Vi[2]  = temp_buffer[18] + 10000;  
            ADK_DEMO.NODE[BMS_eNode].TEMP_Vi[3]  = temp_buffer[19] + 10000;  

            #ifdef DBG_TEMP_TEST
            int i = 0;
            for(;i < 3; i++)
            {
                if(temp_buffer[16+i] == 0)
                {
                    TEMP_ZERO[i]++;
                }
            }

            if(TEMP_V2_MAX < ADK_DEMO.NODE[BMS_eNode].TEMP_V[2])
            {
                TEMP_V2_MAX = ADK_DEMO.NODE[BMS_eNode].TEMP_V[2];
            }
            if(TEMP_V2_MIN > ADK_DEMO.NODE[BMS_eNode].TEMP_V[2])
            {
                TEMP_V2_MIN = ADK_DEMO.NODE[BMS_eNode].TEMP_V[2];
            }
            #endif

            #ifdef DBG_TEMP_TEST
            if(temp_buffer[19] == 0)
            {
                TEMP_ZERO[3]++;
            }
            
            if(TEMP_V3_MAX < ADK_DEMO.NODE[BMS_eNode].TEMP_V[3])
            {
                TEMP_V3_MAX = ADK_DEMO.NODE[BMS_eNode].TEMP_V[3];
            }
            if(TEMP_V3_MIN > ADK_DEMO.NODE[BMS_eNode].TEMP_V[3])
            {
                TEMP_V3_MIN = ADK_DEMO.NODE[BMS_eNode].TEMP_V[3];
            }
            #endif

            Adbms683x_Monitor_Base_Pkt0(&userBMSBuffer[pkt_count]);     
        }
        else if (BMS_packetId == ADI_BMS_BASE_PKT_1_ID){
            temp_recv_confirm[BMS_eNode] |= 0x02;
#if 0 // @SURE - ADDED
            memcpy(BMS_Packet_1_Ptr, (adi_bms_base_pkt_1_t*) &userBMSBuffer[pkt_count].Data, sizeof(adi_bms_base_pkt_1_t));
#else
            BMS_Packet_1_Ptr = (adi_bms_base_pkt_1_t*) &userBMSBuffer[pkt_count].iLength;
#endif

            #if  (ADK_ADBMS683x == 0) /* ADBMS6830 */
            ADK_DEMO.NODE[BMS_eNode].CB_STAT = (BMS_Packet_1_Ptr->Rdcfgb.iCfgbr5 << 8) + BMS_Packet_1_Ptr->Rdcfgb.iCfgbr4 ;
            #elif(ADK_ADBMS683x == 3) /* ADBMS6833 */
            ADK_DEMO.NODE[BMS_eNode].CB_STAT = ((BMS_Packet_1_Ptr->Rdcfga.iCfgar2 & BMS_CELLS_1_TO_2_MASK) << 16) + (BMS_Packet_1_Ptr->Rdcfgb.iCfgbr5 << 8) + BMS_Packet_1_Ptr->Rdcfgb.iCfgbr4;
            #else   /* Not supported */
            #endif
            Adbms683x_Monitor_Base_Pkt1(&userBMSBuffer[pkt_count]);       
        }
        else if (BMS_packetId == ADI_BMS_BASE_PKT_2_ID){
            temp_recv_confirm[BMS_eNode] |= 0x04;
#if 0 // @SURE - ADDED
            memcpy(BMS_Packet_2_Ptr, (adi_bms_base_pkt_2_t*) &userBMSBuffer[pkt_count].Data, sizeof(adi_bms_base_pkt_2_t));
#else
            BMS_Packet_2_Ptr = (adi_bms_base_pkt_2_t*) &userBMSBuffer[pkt_count].iLength;
#endif

            #if  (ADK_ADBMS683x == 0) /* ADBMS6830 */
            ADK_DEMO.NODE[BMS_eNode].OWD_CS_STAT = (BMS_Packet_2_Ptr->Rdstatc.iCsflt[1] << 8) + BMS_Packet_2_Ptr->Rdstatc.iCsflt[0];
            #elif(ADK_ADBMS683x == 3) /* ADBMS6833 */
            ADK_DEMO.NODE[BMS_eNode].OWD_CS_STAT = ((BMS_Packet_2_Ptr->Rdstatc.iStcr2 & 0xC0) << 10) + (BMS_Packet_2_Ptr->Rdstatc.iStcr1 << 8) + BMS_Packet_2_Ptr->Rdstatc.iStcr0;
            #else   /* Not supported */
            #endif
        }
        else{
            /* DO NOTHING */
			#ifdef DBG_PACKET_ID_TEST
            if(index < 50){
                TEMP_PACKET_ID[index] = BMS_packetId;
                TEMP_DEVICE_ID[index++] = BMS_eNode;
            }
			#endif
        }

#if 1 // @SURE - ADDED
        #if(ADK_ADBMS683x == 0) /* ADBMS6830 */
        if(iOWDPcktsRcvd[BMS_eNode] == SM_ADBMS6830_ALL_PCKTS_FOR_OWD_RCVD)
        {
            Adbms683x_Monitor_Cell_OWD(BMS_eNode);
            iOWDPcktsRcvd[BMS_eNode] = 0U;
        }
        #elif(ADK_ADBMS683x == 3) /* ADBMS6833 */
        if(iOWDPcktsRcvd[BMS_eNode] == SM_ADBMS6833_ALL_PCKTS_FOR_OWD_RCVD)
        {
            Adbms683x_Monitor_Cell_OWD(BMS_eNode);
            iOWDPcktsRcvd[BMS_eNode] = 0U;
        }
        #else   /* Not supported */
        #endif
#else
        #if(ADK_ADBMS683x == 0) /* ADBMS6830 */
        if(iOWDPcktsRcvd[BMS_eNode] == SM_ADBMS6830_ALL_PCKTS_FOR_OWD_RCVD)
        {
        #elif(ADK_ADBMS683x == 3) /* ADBMS6833 */
        if(iOWDPcktsRcvd[BMS_eNode] == SM_ADBMS6833_ALL_PCKTS_FOR_OWD_RCVD)
        {
        #else   /* Not supported */
        #endif
            Adbms683x_Monitor_Cell_OWD(BMS_eNode);
            iOWDPcktsRcvd[BMS_eNode] = 0U;
        }
#endif
    }
    for(pkt_count = 0; pkt_count < NODE_NUM; pkt_count++)
    {
        if(iBMSNotificationCount<5)    ADK_DEMO.NODE[pkt_count].BMS_PKT_MAP[1]=0xFF;
        ADK_DEMO.NODE[pkt_count].BMS_PKT_MAP[0] = temp_recv_confirm[pkt_count];
        if(ADK_DEMO.NODE[pkt_count].BMS_PKT_MAP[0]<ADK_DEMO.NODE[pkt_count].BMS_PKT_MAP[1]) ADK_DEMO.NODE[pkt_count].BMS_PKT_MAP[1] = ADK_DEMO.NODE[pkt_count].BMS_PKT_MAP[0];
    }

#if 1 // @SURE - ADDED
    adi_wil_example_set_node_recv_packet();
    adi_wil_example_set_over_voltage();
#endif
}


/**
 * @remark: This is example, exceptional case must be handled for PDR accuracy
 */
#define moving_AVG 0

uint32_t pkt_seq_buffer[ADK_MAX_node][PDR_pktbuf_depth];
uint8_t pkt_valid_index[ADK_MAX_node];
uint32_t pkt_valid_seq[ADK_MAX_node];

bool FLG_pdr_initial = false;
uint8_t FLG_pdr_seq_initial[ADK_MAX_node];

uint8_t FLG_seq_num_rollback_period[ADK_MAX_node];

uint64_t accm_PDR_OK[ADK_MAX_node];
uint64_t accm_PDR_TOTAL[ADK_MAX_node];



static void adi_wil_example_ADK_PDR_calc(void)
{
    uint8_t i_node = 0;
    uint8_t i_pkt = 0;
    uint32_t temp_buffer;

    uint16_t i,j,k;   

    uint8_t  temp_drvd_pkt[ADK_MAX_node]={0,};

    uint16_t temp_PDR_OK[ADK_MAX_node]={0,};
    uint16_t temp_PDR_TOTAL[ADK_MAX_node]={0,};
    uint8_t  pdr_DUP_buffer[ADK_MAX_node]={0,};
#if 1 // @SURE - ADDED
    uint16_t pkt_latency_buffer[ADK_MAX_node]={0,};
#endif

    /* Step 1 : Init global PDR data */
    if(FLG_pdr_initial == false)
    {
        memset(&accm_PDR_OK[0],                 0, sizeof(uint64_t) * ADK_MAX_node);
        memset(&accm_PDR_TOTAL[0],             0, sizeof(uint64_t) * ADK_MAX_node);

        memset(&pkt_seq_buffer[0],              0, sizeof(uint32_t) * PDR_pktbuf_depth * ADK_MAX_node);
        memset(&pkt_valid_index[0],             0, sizeof(uint8_t) * ADK_MAX_node);
        memset(&pkt_valid_seq[0],               0, sizeof(uint32_t) * ADK_MAX_node);
        memset(&FLG_pdr_seq_initial[0],         0, sizeof(uint8_t) * ADK_MAX_node);
        memset(&FLG_seq_num_rollback_period[0], 0, sizeof(uint8_t) * ADK_MAX_node);
        FLG_pdr_initial = true;
    }

    for(i_node=0 ; i_node<NODE_NUM ; i_node++)
    {
        // Step 2 : Store sequence number of all NW packet
            //Store sequence number into "pkt_seq_buffer"
            //Inclease valid index number of "pkt_seq_buffer" to "pkt_valid_index(15)"
            //Assume initial number of derivered packet for instant PDR during (buffer<15)
        for(i_pkt=0 ; i_pkt<(NODE_NUM*BMS_PACKETS_PER_INTERVAL) ; i_pkt++)
        {
            if(ADK_ConvertDeviceId(userNetworkBuffer[i_pkt].eSrcDeviceId) == i_node)
            {
#if 1 // @SURE - ADDED
                // Max - Worst latency
                if(pkt_latency_buffer[i_node]<userNetworkBuffer[i_pkt].iLatency)
                {
                    pkt_latency_buffer[i_node]=userNetworkBuffer[i_pkt].iLatency;
                }
#endif
                if(FLG_seq_num_rollback_period[i_node]) //if rollback status
                {
                    pkt_seq_buffer[i_node][pkt_valid_index[i_node]++] = userNetworkBuffer[i_pkt].iSequenceNumber + 0x10000;
                    temp_drvd_pkt[i_node]++;
                }
                else                                    //not rollback status
                {
                    pkt_seq_buffer[i_node][pkt_valid_index[i_node]++] = userNetworkBuffer[i_pkt].iSequenceNumber;
                    temp_drvd_pkt[i_node]++;
                }
                
            }
       }
       
#if 1 // @SURE - ADDED
       ADK_DEMO.NODE[i_node].LATENCY[0] = pkt_latency_buffer[i_node];
       if(ADK_DEMO.NODE[i_node].LATENCY[0] > ADK_DEMO.NODE[i_node].LATENCY[1]) ADK_DEMO.NODE[i_node].LATENCY[1] = ADK_DEMO.NODE[i_node].LATENCY[0];
#endif

        // Step 3 : SEQ_NUM into the rollback action
        if((FLG_seq_num_rollback_period[i_node]==0) && (pkt_seq_buffer[i_node][0]>0xFFFFF000))
        {
            for(i=0; i<pkt_valid_index[i_node]; i++)
            {
                pkt_seq_buffer[i_node][i] += 0x10000;
            }
            if (pkt_valid_seq[i_node])  pkt_valid_seq[i_node] += 0x10000;
            FLG_seq_num_rollback_period[i_node]=1;
        }

        // Step 4 : SEQ_NUM out from the rollback action
        if((FLG_seq_num_rollback_period[i_node]==1) && (pkt_seq_buffer[i_node][0]>0x10100))
        {
            for(i=0; i<pkt_valid_index[i_node]; i++)
            {
                pkt_seq_buffer[i_node][i] -= 0x10000;
            }
            if (pkt_valid_seq[i_node])  pkt_valid_seq[i_node] -= 0x10000;
            FLG_seq_num_rollback_period[i_node]=0;
        }
        
        // Step 5 : Calculate instant start time PDR
        if(FLG_pdr_seq_initial[i_node]==0)
        {
            //Current PDR calculation
            ADK_DEMO.NODE[i_node].PDR[0] = ((float)temp_drvd_pkt[i_node]) / ((float)BMS_PACKETS_PER_INTERVAL) * 100;
            if(ADK_DEMO.NODE[i_node].PDR[0]>100.0)  ADK_DEMO.NODE[i_node].PDR[0] = 100.0;
            //Minimum PDR init
            ADK_DEMO.NODE[i_node].PDR[1] = 100.0;
            //Maximum PDR init
            ADK_DEMO.NODE[i_node].PDR[2] = 0.0;
            //DUP init
            ADK_DEMO.NODE[i_node].DUPLICATE[1] = 0;
#if 1 // @SURE - ADDED
            ADK_DEMO.NODE[i_node].LATENCY[1] = ADK_DEMO.NODE[i_node].LATENCY[0];
#endif
        }

        // Step 6 : When buffer index exceeds pkt_valid_index_threshold,
        if(pkt_valid_index[i_node]>pkt_valid_index_threshold)   //pkt_valid_index_threshold = 15
        {
            // Step 6-1 : duplicated packet count and descending sort
            k=pkt_valid_index[i_node];
            for(i=0;i<(k-1);i++)
            {
                for(j=i+1;j<k;j++)
                {
                    if(pkt_seq_buffer[i_node][i]==pkt_seq_buffer[i_node][j])        //same value
                    {
                        // Step 6-1-a : Duplication detect
                        if(pkt_seq_buffer[i_node][i])                               //same value && none zero
                        {
                            pkt_seq_buffer[i_node][j]=0;                            //delete duplicated
                            pkt_valid_index[i_node]--;                              //declease index
                            pdr_DUP_buffer[i_node]++;
                        }
                    }
                    else if(pkt_seq_buffer[i_node][i]<pkt_seq_buffer[i_node][j])
                    {
                        // Step 6-1-b : Sorting
                        temp_buffer = pkt_seq_buffer[i_node][i];
                        pkt_seq_buffer[i_node][i] = pkt_seq_buffer[i_node][j];
                        pkt_seq_buffer[i_node][j] = temp_buffer;
                    }
                }
            }
            
            // Step 6-2 : Assign sequence start number
            if(FLG_pdr_seq_initial[i_node]==0)
            {
                pkt_valid_seq[i_node] = pkt_seq_buffer[i_node][pkt_valid_index[i_node]-1] - 1;
                FLG_pdr_seq_initial[i_node]=1;
            }
        
            // Step 6-3 : Loop until buffer < 15 , count OK/NG cases
            while(pkt_valid_index[i_node]>pkt_valid_index_threshold)
            {
                //Rollback moment
                if((pkt_valid_seq[i_node]==0xFFFF) && (FLG_seq_num_rollback_period[i_node]==1))
                {
                    pkt_valid_seq[i_node]++;
                }
                
                //OK case   [expected value] == [acquired smalest value]
                if((pkt_valid_seq[i_node] + 1) == pkt_seq_buffer[i_node][pkt_valid_index[i_node]-1])
                {
                    pkt_seq_buffer[i_node][pkt_valid_index[i_node]-1]=0;
                    pkt_valid_index[i_node]--;
                    temp_PDR_OK[i_node]++;
                    temp_PDR_TOTAL[i_node]++;

                    pkt_valid_seq[i_node]++;
                }

                //Upset case    [expected value] > [acquired smallest value]    <- "NEVER happen case"
                else if((pkt_valid_seq[i_node] + 1) > pkt_seq_buffer[i_node][pkt_valid_index[i_node]-1])
                {
                    pkt_seq_buffer[i_node][pkt_valid_index[i_node]-1]=0;
                    pkt_valid_index[i_node]--;
                    temp_PDR_TOTAL[i_node]++;
                }
                //NG(=packet lost) case
                else    
                {
                    pkt_valid_seq[i_node]++;
                    temp_PDR_TOTAL[i_node]++;
                }
            }
            
            
                accm_PDR_OK[i_node] += temp_PDR_OK[i_node];
                accm_PDR_TOTAL[i_node] += temp_PDR_TOTAL[i_node];

                if((accm_PDR_OK[i_node]&0x8000000000000000)&&((accm_PDR_TOTAL[i_node]&0x8000000000000000)))
                {
                    accm_PDR_OK[i_node]/=2;
                    accm_PDR_TOTAL[i_node]/=2;
                }
                
                // Step 6-4 : Current PDR = OK / (OK + NG) -> Display
                ADK_DEMO.NODE[i_node].PDR[0] = ((float)temp_PDR_OK[i_node]) / ((float)temp_PDR_TOTAL[i_node]) * 100.0;
                ADK_DEMO.NODE[i_node].PDR[3] = ((float)accm_PDR_OK[i_node]) / ((float)accm_PDR_TOTAL[i_node]) * 100.0;
                //Minimum PDR of current PDR calculation
                if(ADK_DEMO.NODE[i_node].PDR[0]<ADK_DEMO.NODE[i_node].PDR[1])   ADK_DEMO.NODE[i_node].PDR[1] = ADK_DEMO.NODE[i_node].PDR[0];
                //Maximum PDR of current PDR calculation
                if(ADK_DEMO.NODE[i_node].PDR[0]>ADK_DEMO.NODE[i_node].PDR[2])   ADK_DEMO.NODE[i_node].PDR[2] = ADK_DEMO.NODE[i_node].PDR[0];

                // Step 6-5 : Current DUP -> Display
                ADK_DEMO.NODE[i_node].DUPLICATE[0] = pdr_DUP_buffer[i_node];
                if(ADK_DEMO.NODE[i_node].DUPLICATE[0]>ADK_DEMO.NODE[i_node].DUPLICATE[1]) ADK_DEMO.NODE[i_node].DUPLICATE[1]=ADK_DEMO.NODE[i_node].DUPLICATE[0];
           

            //// Step 6-8 : Inclease index and initialize OK/NG/DUP buffers

        }   
    }
}

int32_t accm_rssi_rx_0 = 0;
int32_t accm_rssi_rx_1 = 0;
int32_t accm_pkt_num_0 = 0;
int32_t accm_pkt_num_1 = 0;
int64_t temp_rssi_rx[ADK_MAX_node][2] = {{0,}, {0,}};
int64_t temp_count[ADK_MAX_node][2] = {{0,}, {0,}};

static void adi_wil_example_ADK_RSSI_calc(void){

    bool FLG_rssi_initial = false;
    uint8_t temp_cnt = 0;
    // uint8_t temp_cnt1 = 0;
    uint8_t temp_mngr[ADK_MAX_node * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL];
    uint8_t temp_node[ADK_MAX_node * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL];
    int8_t  temp_rssi[ADK_MAX_node * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL];

    if(FLG_rssi_initial == false){
        /* Step 0 : Init temp */
        memset(&temp_mngr[temp_cnt], 0, sizeof(uint8_t) * ADK_MAX_node * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL);
        memset(&temp_rssi[temp_cnt], 0, sizeof(uint8_t) * ADK_MAX_node * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL);
        FLG_rssi_initial = true;
    }
    else{   /* This code goes after 1st entry */    }

    /* Step 1 : Read data from "userNetworkBuffer" */
    for(temp_cnt = 0; temp_cnt < NODE_NUM * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL; temp_cnt++){
        temp_mngr[temp_cnt] = ADK_ConvertDeviceId(userNetworkBuffer[temp_cnt].eSrcManagerId);
        temp_node[temp_cnt] = ADK_ConvertDeviceId(userNetworkBuffer[temp_cnt].eSrcDeviceId);
        temp_rssi[temp_cnt] = userNetworkBuffer[temp_cnt].iRSSI;
    }

    /* Step 2 : Data relocation */
    for(temp_cnt = 0; temp_cnt < NODE_NUM * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL; temp_cnt++){
        if(temp_mngr[temp_cnt] == 240){                 /* ADI_WIL_DEV_MANAGER_0 */
            //adi_wil_example_ADK_RSSI_save(temp_node[temp_cnt], ADI_WIL_DEV_MANAGER_0, temp_rssi[temp_cnt]);
            ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][0] = temp_rssi[temp_cnt];
            temp_rssi_rx[temp_node[temp_cnt]][0] += temp_rssi[temp_cnt];
            if(temp_count[temp_node[temp_cnt]][0] != 0)
            {
                if(ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][1] > temp_rssi[temp_cnt])
                {
                    ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][1] = temp_rssi[temp_cnt];
                }
                if(ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][2] < temp_rssi[temp_cnt])
                {
                    ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][2] = temp_rssi[temp_cnt];
                }
            }
            else if (temp_count[temp_node[temp_cnt]][0] == 0)
            {
                ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][2] = temp_rssi[temp_cnt];
            }
            temp_count[temp_node[temp_cnt]][0]++;
            ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[0][3] = (int8_t)(temp_rssi_rx[temp_node[temp_cnt]][0] / temp_count[temp_node[temp_cnt]][0]);
        }
        else if(temp_mngr[temp_cnt] == 241) {           /* ADI_WIL_DEV_MANAGER_1 */
            //adi_wil_example_ADK_RSSI_save(temp_node[temp_cnt], ADI_WIL_DEV_MANAGER_1, temp_rssi[temp_cnt]);
            ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][0] = temp_rssi[temp_cnt];
            temp_rssi_rx[temp_node[temp_cnt]][1] += temp_rssi[temp_cnt];
            if(temp_count[temp_node[temp_cnt]][1] != 0)
            {
                if(ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][1] > temp_rssi[temp_cnt])
                {
                    ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][1] = temp_rssi[temp_cnt];
                }
                if(ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][2] < temp_rssi[temp_cnt])
                {
                    ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][2] = temp_rssi[temp_cnt];
                }
            }
            else if (temp_count[temp_node[temp_cnt]][1] == 0)
            {
                ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][2] = temp_rssi[temp_cnt];
            }
            temp_count[temp_node[temp_cnt]][1]++;
            ADK_DEMO.NODE[temp_node[temp_cnt]].RSSI[1][3] = (int8_t)(temp_rssi_rx[temp_node[temp_cnt]][1] / temp_count[temp_node[temp_cnt]][1]);
        }
        else{/* DO NOTHING */}
    }
}


#if 0
static void adi_wil_example_ADK_BGRSSI_calc(void)
{

    return;

}

void adi_wil_example_ExecuteProcessBMSBuffer(void)
{
    uint8_t iNodeIdx = 0;

#if BMS_PACKETS_PRINTING_ON
    //adi_wil_ex_info("BMS Received from Node %d\t\tBMS Packet count: %d", userBMSBuffer->eDeviceId, iBMSNotificationCount);
#endif
    for(iNodeIdx = 0; iNodeIdx < adi_gW2canNodeCount; iNodeIdx++)
    {
        // adi_wil_example_setBmsCanSignals(iNodeIdx,userBMSBuffer);            /* @remark : Not used this time */
        // adi_wil_example_setNetworkCanSignals(iNodeIdx,userNetworkBuffer);    /* @remark : Not used this time */
    }
}


static void adi_wil_example_setBmsCanSignals(uint8_t iNodeIdx, adi_wil_sensor_data_t *pBmsData)
{
    uint32_t iBMS_Pkt_NodeIdx = iNodeIdx*ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL;

    /* Set all the BMS, Packet ID, Measurement Timestamp and Packet CRC CAN Signals for a single Node */
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_PKTID,(uint8_t*)&pBmsData[iBMS_Pkt_NodeIdx].Data[0]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_PKTTIMESTAMP,(uint8_t*)&pBmsData[iBMS_Pkt_NodeIdx].Data[1]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_PKTCRC,(uint8_t*)&pBmsData[iBMS_Pkt_NodeIdx].Data[4]);

    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C1V,&pBmsData[iBMS_Pkt_NodeIdx].Data[6]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C2V,&pBmsData[iBMS_Pkt_NodeIdx].Data[8]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C3V,&pBmsData[iBMS_Pkt_NodeIdx].Data[10]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_CVAR_PEC,&pBmsData[iBMS_Pkt_NodeIdx].Data[12]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C4V,&pBmsData[iBMS_Pkt_NodeIdx].Data[14]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C5V,&pBmsData[iBMS_Pkt_NodeIdx].Data[16]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C6V,&pBmsData[iBMS_Pkt_NodeIdx].Data[18]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_CVBR_PEC,&pBmsData[iBMS_Pkt_NodeIdx].Data[20]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C7V,&pBmsData[iBMS_Pkt_NodeIdx].Data[22]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C8V,&pBmsData[iBMS_Pkt_NodeIdx].Data[24]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C9V,&pBmsData[iBMS_Pkt_NodeIdx].Data[26]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_CVCR_PEC,&pBmsData[iBMS_Pkt_NodeIdx].Data[28]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C10V,&pBmsData[iBMS_Pkt_NodeIdx].Data[30]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C11V,&pBmsData[iBMS_Pkt_NodeIdx].Data[32]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_C12V,&pBmsData[iBMS_Pkt_NodeIdx].Data[34]);
    adi_wil_example_w2canSetSignal(iNodeIdx,ADI_BMS_PACKET_CVDR_PEC,&pBmsData[iBMS_Pkt_NodeIdx].Data[36]);
}

static void adi_wil_example_setNetworkCanSignals(uint8_t iNodeIdx, adi_wil_network_data_t *pNwData)
{
    uint8_t iPacketIdx = 2 * iNodeIdx;
    /* Set all the Network MetaData Signals for a single Node */
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD01_ASN,     (uint8_t *)&pNwData[iPacketIdx].iPacketGenerationTime);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD02_LATENCY, (uint8_t *)&pNwData[iPacketIdx].iLatency);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD02_SEQ_NO,  (uint8_t *)&pNwData[iPacketIdx].iSequenceNumber);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD02_CHANNEL, (uint8_t *)&pNwData[iPacketIdx].iChannel);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD02_RSSI,    (uint8_t *)&pNwData[iPacketIdx].iRSSI);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD03_TWOHOP,  (uint8_t *)&pNwData[iPacketIdx].iTwoHop);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD03_PORTID,  (uint8_t *)&pNwData[iPacketIdx].eSrcManagerId);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD03_SRCID,   (uint8_t *)&pNwData[iPacketIdx].eSrcDeviceId);

    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD05_ASN,     (uint8_t *)&pNwData[iPacketIdx + 1].iPacketGenerationTime);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD06_LATENCY, (uint8_t *)&pNwData[iPacketIdx + 1].iLatency);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD06_SEQ_NO,  (uint8_t *)&pNwData[iPacketIdx + 1].iSequenceNumber);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD06_CHANNEL, (uint8_t *)&pNwData[iPacketIdx + 1].iChannel);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD06_RSSI,    (uint8_t *)&pNwData[iPacketIdx + 1].iRSSI);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD07_TWOHOP,  (uint8_t *)&pNwData[iPacketIdx + 1].iTwoHop);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD07_PORTID,  (uint8_t *)&pNwData[iPacketIdx + 1].eSrcManagerId);
    adi_wil_example_w2canSetSignal(iNodeIdx, ADI_MD07_SRCID,   (uint8_t *)&pNwData[iPacketIdx + 1].eSrcDeviceId);
}

bool adi_wil_example_ExecuteProcessPMSBuffer(void)
{
    bool bPMSBufferProcessed = true;

#if PMS_PACKETS_PRINTING_ON
    //adi_wil_ex_info("PMS from manager %d\t\tPMS Packet count: %d", userPMSBuffer->eDeviceId, iPMSNotificationCount);
#endif

    adi_wil_example_setPmsCanSignals(userPMSBuffer);

    return bPMSBufferProcessed;
}

static void adi_wil_example_setPmsCanSignals(adi_wil_sensor_data_t *pPmsData)
{
    /* Set all the CAN Signals PMS Message PM1 (I1, I2 and VBat) */
    adi_wil_example_w2canSetPM1Signal(ADI_PMS_CURR_I1,&pPmsData->Data[ADI_PMS_I1_OFFSET]);
    adi_wil_example_w2canSetPM1Signal(ADI_PMS_CURR_I2,&pPmsData->Data[ADI_PMS_I2_OFFSET]);
    adi_wil_example_w2canSetPM1Signal(ADI_PMS_VBAT,&pPmsData->Data[ADI_PMS_VBAT_OFFSET]);
    adi_wil_example_w2canSetPM1Signal(ADI_PMS_I1_I2_VBAT_PEC,&pPmsData->Data[ADI_PMS_I1_I2_VBAT_PEC_OFFSET]);

    /* Set all the CAN Signals PMS Message AUX (Aux, hs1, hs2) */
    adi_wil_example_w2canSetPM1AuxSignal(ADI_PMS_AUX_PM1,&pPmsData->Data[ADI_PMS_AUX_OFFSET]);
    adi_wil_example_w2canSetPM1AuxSignal(ADI_PMS_HS1_PM1,&pPmsData->Data[ADI_PMS_HS1_OFFSET]);
    adi_wil_example_w2canSetPM1AuxSignal(ADI_PMS_HS2_PM1,&pPmsData->Data[ADI_PMS_HS2_OFFSET]);
    adi_wil_example_w2canSetPM1AuxSignal(ADI_PMS_AUX_HS1_HS2_PEC,&pPmsData->Data[ADI_PMS_AUX_HS1_HS2_PEC_OFFSET]);
}

bool adi_wil_example_ExecuteProcessEMSBuffer(void)
{
    bool bEMSBufferProcessed = true;

#if EMS_PACKETS_PRINTING_ON
    //adi_wil_ex_info("EMS Received from manager %d\t\tEMS Packet count: %d", userEMSBuffer->eDeviceId, iEMSNotificationCount);
#endif

    adi_wil_example_setEmsCanSignals(userEMSBuffer);

    return bEMSBufferProcessed;
}

static void adi_wil_example_setEmsCanSignals(adi_wil_sensor_data_t *pEmsData)
{
    /* Set all the CAN Signals EMS Message CELL GRP A */
    adi_wil_example_w2canSetEMS1Signal(ADI_EMS_PACKET_C1V,&pEmsData->Data[ADI_EMS_PACKET_C1V_OFFSET]);
    adi_wil_example_w2canSetEMS1Signal(ADI_EMS_PACKET_C2V,&pEmsData->Data[ADI_EMS_PACKET_C2V_OFFSET]);
    adi_wil_example_w2canSetEMS1Signal(ADI_EMS_PACKET_C3V,&pEmsData->Data[ADI_EMS_PACKET_C3V_OFFSET]);
    adi_wil_example_w2canSetEMS1Signal(ADI_EMS_PACKET_CVAR_PEC,&pEmsData->Data[ADI_EMS_PACKET_CVAR_PEC_OFFSET]);

    /* Set all the CAN Signals EMS Message CELL DIAG GRP A */
    adi_wil_example_w2canSetEMS1DiagSignal(ADI_EMS_PACKET_CD1V,&pEmsData->Data[ADI_EMS_PACKET_CD1V_OFFSET]);
    adi_wil_example_w2canSetEMS1DiagSignal(ADI_EMS_PACKET_CD2V,&pEmsData->Data[ADI_EMS_PACKET_CD2V_OFFSET]);
    adi_wil_example_w2canSetEMS1DiagSignal(ADI_EMS_PACKET_CD3V,&pEmsData->Data[ADI_EMS_PACKET_CD3V_OFFSET]);
    adi_wil_example_w2canSetEMS1DiagSignal(ADI_EMS_PACKET_CSA_PEC,&pEmsData->Data[ADI_EMS_PACKET_CSA_PEC_OFFSET]);
}
#endif

/******************************************************************************
 * API notification callback
 *****************************************************************************/
adi_wil_err_t adi_wil_example_ExecuteResetDevice(adi_wil_pack_t * const pPack, adi_wil_device_t eDeviceId)
{
    //adi_wil_ex_info("Resetting Device = %s", adi_wil_DeviceToString(eDeviceId));

    logAPIInProgress = ADI_WIL_API_RESET_DEVICE;
    returnOnWilError(adi_wil_ResetDevice(pPack, eDeviceId));
    
    /* Wait for non-blocking API to complete */
    WaitForWilAPI(pPack);

    //adi_wil_ex_info("Reset device %s successful!", adi_wil_DeviceToString(eDeviceId));

    return ADI_WIL_ERR_SUCCESS;
}

uint8_t test = 0;
adi_wil_connection_details_t tConnectionDetails;
client_data_t ClientData;
/******************************************************************************
 * API notification callback
 *****************************************************************************/
void adi_wil_HandleCallback (adi_wil_pack_t const * const pPack,
                             void const * const pClientData,
                             adi_wil_api_t eAPI,
                             adi_wil_err_t rc,
                             void const * const pData)
{
    /* For readability, cast the void pointer to app's client data type */
    client_data_t * appClientData = (client_data_t *)pClientData;
    
    /* Handle API generated data and flags here */
    if (pData != NULL)
    {
        /* Handle API generated data and flags here */
        if (eAPI == ADI_WIL_API_LOAD_FILE)
        {
            if (rc == ADI_WIL_ERR_IN_PROGRESS)
            {
                (void)memcpy(&appClientData->LoadFileStatus, pData, sizeof(adi_wil_loadfile_status_t));
            }
        }
        else if (eAPI == ADI_WIL_API_GET_DEVICE_VERSION)
        {
            (void)memcpy(&appClientData->DeviceVersion, pData, sizeof(adi_wil_dev_version_t));
        }
        else if (eAPI == ADI_WIL_API_GET_FILE_CRC)
        {
            crclist.eFileExists = 0;
        }
        else if (eAPI == ADI_WIL_API_GET_CONTEXTUAL_DATA)
        {
            (void)memcpy(&returnedContextualData, pData, sizeof(returnedContextualData));
        }
        else if (eAPI == ADI_WIL_API_GET_GPIO)
        {
            (void)memcpy(&returnedGpioValue, pData, sizeof(returnedGpioValue));
        }
        else if (eAPI == ADI_WIL_API_GET_STATE_OF_HEALTH)
        {
            (void)memcpy(&returnedSoHValue, pData, sizeof(returnedSoHValue));
        }
        else if (eAPI == ADI_WIL_API_GET_ACL)
        {
            (void)memcpy(&systemAcl, pData, sizeof(adi_wil_acl_t));
        }
        else if (eAPI == ADI_WIL_API_CONNECT)
        {
            (void)memcpy(&appClientData->ConnectionDetails, pData, sizeof(adi_wil_connection_details_t));
            bConnectApiCalled = true;
        }
    }
    gNotifRc = rc;
}

#define MAX_LF_RETRY    12
adi_wil_device_removed_t LF_NG_LIST[MAX_LF_RETRY];

#ifdef DBG_INIT_SCRIPT_TEST
uint8_t iInitBuffer0index = 0;
uint8_t iInitBuffer1index = 0;
uint8_t iLostPacketCnt = 0;                             /* case of 0 iLength (packet lost case) */
adi_bms_init_pkt_0_t initBuffer0[ADK_MAX_node];
adi_bms_init_pkt_1_t initBuffer1[ADK_MAX_node];
#endif

/******************************************************************************
 * Event notification callback
 *****************************************************************************/
void adi_wil_HandleEvent (adi_wil_pack_t const * const pPack,
                          void const * const pClientData,
                          adi_wil_event_id_t EventCode,
                          void const * const pData)
{
    uint16_t iCount;
    uint8_t HR_index=0;

    /* For readability, cast the void pointer to app's client data type */
    client_data_t * appClientData = (client_data_t *)pClientData;

    if (appClientData->eEventWaitingFor == EventCode)
    {
        appClientData->iEventWaitingForCount++;
    }
    else
    {
        /* code flow should never enter here */
    }

    switch (EventCode)
    {
        case ADI_WIL_EVENT_COMM_MGR_CONNECTED:
            iMgrConnectCount++;
#if 1 // @SURE - ADDED
            /* infineon <-> adrf8850 communication status */
            {
                adi_wil_device_t eDeviceId = *(adi_wil_device_t *)pData;
                adi_wil_example_set_mngr_status(eDeviceId, 0);
            }
#endif
            break;

        case ADI_WIL_EVENT_COMM_MGR_DISCONNECTED:
            iMgrDisconnectCount++;
#if 1 // @SURE - ADDED
            /* infineon <-> adrf8850 communication status */
            {
                adi_wil_device_t eDeviceId = *(adi_wil_device_t *)pData;
                adi_wil_example_set_mngr_status(eDeviceId, 1);
            }
#endif
            break;

        case ADI_WIL_EVENT_DATA_READY_PMS:
            /* Handle PMS data here in the event CB from pData */
            /* The application should signal here to let the PMS data processing routine know that there is new PMS data. */
            iPMSNotificationCount++;
            /* If somehow WIL passes more sensor data packets than example code can store, store as much data as fits. */
            iCount = ((adi_wil_sensor_data_buffer_t *)pData)->iCount;
            if (iCount > PMS_DATA_PACKET_COUNT)
            {
                iCount = PMS_DATA_PACKET_COUNT;
            }
            /* copy the PMS data out here in the event CB from pData */
            memcpy(userPMSBuffer, ((adi_wil_sensor_data_buffer_t *)pData)->pData, iCount*(sizeof(adi_wil_sensor_data_t)));
            adi_gNotifyPms = true;
            break;

        case ADI_WIL_EVENT_DATA_READY_BMS:
            iBMSNotificationCount++;
            /* copy the BMS data out here in the event CB from pData */
            memcpy(userBMSBuffer, ((adi_wil_sensor_data_buffer_t *)pData)->pData, (((adi_wil_sensor_data_buffer_t *)pData)->iCount)*(sizeof(adi_wil_sensor_data_t)));
            /* The application should signal here to let the BMS data processing thread know that there is new BMS data. */
            adi_gNotifyBms = true;
            adi_gNotifyBmsData = true;
            nTotalPcktsRcvd = ((adi_wil_sensor_data_buffer_t *)pData)->iCount;  /*  @remark Akash : Variable to store total no. of bms packets received */

            /* @remark  : check BASE packet header */
            for(EventCallback_pkt_count = 0; EventCallback_pkt_count < nTotalPcktsRcvd; EventCallback_pkt_count++){
                /* capture Init script data */
                #ifdef DBG_INIT_SCRIPT_TEST
                if(userBMSBuffer[EventCallback_pkt_count].iLength == 0)
                {
                    iLostPacketCnt++;
                }
                else if((userBMSBuffer[EventCallback_pkt_count].Data[0] == ADI_BMS_INIT_PKT_0_ID) && (iInitBuffer0index < ADK_MAX_node))
                {
                    memcpy(&initBuffer0[iInitBuffer0index++], &userBMSBuffer[EventCallback_pkt_count].Data, userBMSBuffer[EventCallback_pkt_count].iLength);
                }
                else if((userBMSBuffer[EventCallback_pkt_count].Data[0] == ADI_BMS_INIT_PKT_1_ID) && (iInitBuffer1index < ADK_MAX_node))
                {
                    memcpy(&initBuffer1[iInitBuffer1index++], &userBMSBuffer[EventCallback_pkt_count].Data, userBMSBuffer[EventCallback_pkt_count].iLength);
                }
                #endif
                if(userBMSBuffer[EventCallback_pkt_count].Data[0] == ADI_BMS_BASE_PKT_0_ID || userBMSBuffer[EventCallback_pkt_count].Data[0] == ADI_BMS_BASE_PKT_1_ID || userBMSBuffer[EventCallback_pkt_count].Data[0] == ADI_BMS_BASE_PKT_2_ID){
                       BASE_PACKET_RECEIVED = true;
                       if (!bFirstBMSdata)  adk_debug_BootTimeLog(Overall_, LogEnd__, 730, Demo_key_on_event_____________________);
                       bFirstBMSdata=true;
                       break;
                   }
                else{
                    BASE_PACKET_RECEIVED = false;
                }
            }
            break;

        case ADI_WIL_EVENT_DATA_READY_EMS:
            iEMSNotificationCount++;
            /* copy the EMS data out here in the event CB from pData */
            memcpy(userEMSBuffer, ((adi_wil_sensor_data_buffer_t *)pData)->pData, (((adi_wil_sensor_data_buffer_t *)pData)->iCount)*(sizeof(adi_wil_sensor_data_t)));
            /* The application should signal here to let the BMS data processing thread know that there is new BMS data. */
            adi_gNotifyEms = true;
            break;

        case ADI_WIL_EVENT_COMM_NODE_CONNECTED:
            /* A node joined the WBMS network. Connected node device ID (adi_wil_device_t) is returned  */
            /* Counter to track connected nodes in the network */
            iNodeConnectedCount++;
#if 1 // @SURE - ADDED
            adi_wil_example_set_node_connected(pPack);
            adi_wil_example_InitUpdateExpectedGenTime();
#endif
            break;

        case ADI_WIL_EVENT_COMM_NODE_DISCONNECTED:
            /* A node dropped from the WBMS network. Disconnected node device ID (adi_wil_device_t) is returned */
            /* Counter to track disconnected nodes in the network */
            iNodeDisconnectedCount++;
#if 1 // @SURE - ADDED
            adi_wil_example_set_node_connected(pPack);
#endif
            break;

        case ADI_WIL_EVENT_COMM_MGR_TO_MGR_ERROR:
            /* Communication between the two network managers failed (dual manager mode only), no data is returned */
            /* Counter to track MGR to MGR errors */
            iMgrToMgrErrCount++;
            break;
        
        case ADI_WIL_EVENT_MGR_QUEUE_OVERFLOW:
            /* Event used to identified SPI transmission queue issues in the managers */
            iQueueOverflowNotificationCount++;
            break;
        
        case ADI_WIL_EVENT_DATA_READY_HEALTH_REPORT:
            /* copy the HR data out here in the event CB from pData */
            if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_DEVICE)
            {
                /* HR Data Packet1 : contains signal rssi, reset counter
                twohop counter, join attempts etc */
                memcpy(&userHR0Buffer[ADK_ConvertDeviceId(((adi_wil_health_report_t *)pData)->eDeviceId)], 
                       &((adi_wil_health_report_t*)pData)->Data[0], 
                       sizeof(adi_wil_health_report0_t));
                // adi_w2can_NotifyHR_availability();   /* @remark: Not used this time */
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_AVERAGE_RSSI)
            {
                /* HR Data Packet2 : contains node average rssi */
                memcpy(&userHR1Buffer[ADK_ConvertDeviceId(((adi_wil_health_report_t *)pData)->eDeviceId)], 
                       &((adi_wil_health_report_t*)pData)->Data[0], 
                       sizeof(adi_wil_health_report1_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_BACKGROUND_RSSI)
            {
                /* HR Data Packet2 : contains background rssi */
                memcpy(&userHR2Buffer[ADK_ConvertDeviceId(((adi_wil_health_report_t *)pData)->eDeviceId)], 
                       &((adi_wil_health_report_t*)pData)->Data[0], 
                       sizeof(adi_wil_health_report2_t));
                // adi_wil_example_ADK_BGRSSI_calc();   /* @remark: Not used this time */
                // adi_w2can_NotifyHR_availability();   /* @remark: Not used this time */
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_MANAGER_APPLICATION)
            {
                /* HR Data Packet 0x10 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR10Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report10_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_MANAGER_BACKGROUND_RSSI)
            {
                /* HR Data Packet 0x11 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR11Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report11_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_MANAGER_DEVICE)
            {
                /* HR Data Packet 0x12 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR12Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report12_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_MANAGER_0_4_RSSI)
            {
                /* HR Data Packet 0x14 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR14Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report14_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_MANAGER_5_9_RSSI)
            {
                /* HR Data Packet 0x15 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR15Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report14_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_MANAGER_10_14_RSSI)
            {
                /* HR Data Packet 0x16 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR16Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report14_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_MANAGER_15_19_RSSI)
            {
                /* HR Data Packet 0x17 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR17Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report14_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_MANAGER_20_23_RSSI)
            {
                /* HR Data Packet 0x18 :  */
                if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_0)
                {
                    HR_index = 0;
                }
                else if(((adi_wil_health_report_t *)pData)->eDeviceId == ADI_WIL_DEV_MANAGER_1)
                {
                    HR_index = 1;
                }
                else
                {
                    break;
                }
                memcpy(&userHR18Buffer[HR_index],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report14_t));
            }
            else if (((adi_wil_health_report_t *)pData)->Data[0] == PACKET_ID_NODE_APPLICATION)
            {
                /* HR Data Packet 0x80 : contains data about node firmware */
                memcpy(&userHR80Buffer[ADK_ConvertDeviceId(((adi_wil_health_report_t *)pData)->eDeviceId)],
                       &((adi_wil_health_report_t*)pData)->Data[0],
                       sizeof(adi_wil_health_report80_t));
                // adi_w2can_NotifyHR_availability();   /* @remark: Not used this time */
            }
            else
            {
                // invalid Data Packet ID - ignore
            }
            break;

        case ADI_WIL_EVENT_DATA_READY_NETWORK_DATA:
            /* Copy out the network data if enabled */
            memcpy(userNetworkBuffer, ((adi_wil_network_data_buffer_t *)pData)->pData, (((adi_wil_network_data_buffer_t *)pData)->iCount)*(sizeof(adi_wil_network_data_t)));
            adi_gNotifyNetworkMeta = true;
            adi_wil_example_ADK_PDR_calc();
            adi_wil_example_ADK_RSSI_calc();
            adi_wil_example_StoreNWDataForPS(userNetworkBuffer);
            break;

        case ADI_WIL_EVENT_FAULT_SOURCES:
            /* A fault in monitor mode has occured and a system summary has been received. */
            /* Copy out the fault sources summary */
            memcpy(&faultSources, pData, sizeof(adi_wil_device_t));
            break;

        case ADI_WIL_EVENT_FAULT_REPORT:
            /* Environmental monitoring fault report has been received. */
            /* Copy out the fault report */
            memcpy(&faultReport, pData, sizeof(adi_wil_fault_report_t));
            adi_gFaultDetected = true;
            break;

        case ADI_WIL_EVENT_SEC_NODE_NOT_IN_ACL:
            /* Node that tried to join the WBMS is not in the ACL list, the MAC
               address of the unidentified node (uint8_t *) is returned*/
        case ADI_WIL_EVENT_SEC_CERTIFICATE_CALCULATION_ERROR:
            /* A certificate calculation error occurred, the MAC address of the
               device (uint8_t *) that triggered the event is returned*/
        case ADI_WIL_EVENT_SEC_JOIN_NO_KEY:
            /* A node does not have a valid join key, the MAC address of the
               device (uint8_t *) that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_JOIN_DUPLICATE_JOIN_COUNTER:
            /* A node has a duplicate join counter, the MAC address of the
               device (uint8_t *) that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_JOIN_MIC_FAILED:
            /* MIC verification failed for a join packet, the MAC address of the
               device (uint8_t *) that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_SESSION_MIC_FAILED:
            /* Session MIC Failure for a session packet, the MAC address of the
               device (uint8_t *) that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_M2M_JOIN_CNTR_ERROR:
            /* M2M Join Counter Security Error, the MAC address of the peer
               manager (uint8_t *) that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_M2M_SESSION_CNTR_ERROR:
            /* M2M Session Counter Security Error, the MAC address of the peer
               manager (uint8_t *) that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_UNKNOWN_ERROR:
            /* Unknown security error, the MAC address of the device (uint8_t *)
               that triggered the event is returned */
        case ADI_WIL_EVENT_SEC_CERTIFICATE_EXCHANGE_LOCK_ERROR:
            /* A certificate exchange error occurred, the MAC address of the
               device (uint8_t *) that triggered the event is returned */
            iSecurityEvtCount++;
            break;
        case ADI_WIL_EVENT_XFER_DEVICE_REMOVED:
            memcpy(&LF_NG_LIST[ADK_DEMO.LF_NG_CNT], pData, sizeof(adi_wil_device_removed_t));
            ADK_DEMO.LF_NG_CNT++;
            if( ADK_DEMO.LF_NG_CNT >= MAX_LF_RETRY ){
                /* @warning Load file command failed a lot */
                adk_debug_Report(DBG_need_investigation, ADI_WIL_ERR_FAIL);
            }
            /* This event applies only during the LoadFile API */
            /* pData points to a adi_wil_device_removed_t structure. This data
               can be copied out so that the thread that is executing the
               LoadFile API can determine which device has dropped off. */
            break;
        case ADI_WIL_EVENT_INSUFFICIENT_BUFFER:
            /* The user has provided a adi_wil_sensor_data_t (adi_wil_sensor_data_t)
               buffer that is insufficiently sized for this network */
            /* The correct number of buffers the user should provide is returned
               (uint16_t *). */
            break;
        default: ;
    }
}
/******************************************************************************
 * MAC <-> index retrieval function
 * This is a helper function that will return to the user either the MAC address or
 * the device ID of a node in the network
 *****************************************************************************/
void adi_wil_mac_deviceID_return(adi_wil_pack_t *pPack, bool bMacReturn, uint8_t *pMacPtr, uint8_t *pDeviceID)
{
    uint8_t iDeviceID = *pDeviceID;
    /* Check MAC return flag to ascertain if MAC address of the node is to be returned or the device ID */
    if(bMacReturn) {
        for(uint8_t i=0;i<ADI_WIL_MAC_ADDR_SIZE;i++) {
            /*Retrieving the MAC address */
            *(pMacPtr+i) = systemAcl.Data[(ADI_WIL_MAC_ADDR_SIZE*iDeviceID)+i];
        }
    }
    else {
        for(uint8_t i=0;i<ADI_WIL_MAX_NODES;i++) {
            bool bMacFound = true;
            for(uint8_t j=0;j<ADI_WIL_MAC_ADDR_SIZE && bMacFound;j++) {
                bMacFound = (systemAcl.Data[(ADI_WIL_MAC_ADDR_SIZE*i)+j] == *(pMacPtr+j));
            }
            if(bMacFound == true) {
                /*Retrieving the Device ID */
                *pDeviceID = i;
                break;
            }
        }
    }
}

/******************************************************************************
 * Read sensor packet count function
 *****************************************************************************/
uint8_t readSensorPacketCount(adi_wil_configuration_t* pPortConfig) {
    uint8_t sensorPacketCount;

    if(pPortConfig[0].iSensorPacketCount != pPortConfig[1].iSensorPacketCount) {
        //adi_wil_ex_info("Network Managers have different sensor packet count!");
        if(pPortConfig[0].iSensorPacketCount > pPortConfig[1].iSensorPacketCount) {
            sensorPacketCount = (uint8_t)pPortConfig[0].iSensorPacketCount;
        }
        else {
            sensorPacketCount = (uint8_t)pPortConfig[1].iSensorPacketCount;
        }
    }
    else {
        sensorPacketCount = (uint8_t)pPortConfig[0].iSensorPacketCount;
    }
    return sensorPacketCount;
}

/******************************************************************************
 * Print Event Statistics
 *****************************************************************************/
void adi_task_EventStatistics(void)
{
    //adi_wil_ex_info("Event Statistics...");
    //printf("ADI_WIL_EVENT_COMM_MGR_CONNECTED = %u\r\n", iMgrConnectCount);
    //printf("ADI_WIL_EVENT_COMM_MGR_DISCONNECTED = %u\r\n", iMgrDisconnectCount);
    //printf("ADI_WIL_EVENT_DATA_READY_BMS = %u\r\n", iBMSNotificationCount);
    //printf("ADI_WIL_EVENT_DATA_READY_PMS = %u\r\n", iPMSNotificationCount);
    //printf("ADI_WIL_EVENT_DATA_READY_EMS = %u\r\n", iEMSNotificationCount);
    //printf("ADI_WIL_EVENT_MGR_QUEUE_OVERFLOW = %u\r\n", iQueueOverflowNotificationCount);
}

/******************************************************************************
 * @remark : Custom functions for development
 *****************************************************************************/
uint16_t Compare_depth = 0;
uint16_t Compare_cnt = 0;
uint32_t User_ACL[64] = {0,}; // @remark  max noode
uint32_t Read_ACL[64] = {0,}; // @remark  max noode
uint16_t User_ACL_cnt = 0;

bool adi_wil_example_ADK_CompareACL(void){

    bool ACL_rc = false; /* false = ACL update needed, true = no need to update */

    if(userAcl.iCount == systemAcl.iCount){
        /* iCount is same */
        while(1){ /* Parse user MAC */
            if(userAcl.Data[Compare_cnt * 8] == 0){
                /* @remark : There are no MAC exist in user setting */
                break;
            }
            else{
                /* @remark : Parse node specific MAC */
                User_ACL[User_ACL_cnt] |= userAcl.Data[Compare_cnt * 8 + 5] << 16; //6th MAC
                User_ACL[User_ACL_cnt] |= userAcl.Data[Compare_cnt * 8 + 6] << 8; //7th MAC
                User_ACL[User_ACL_cnt] |= userAcl.Data[Compare_cnt * 8 + 7]; //8th MAC
                User_ACL_cnt ++;
            }
            Compare_cnt++;
        }

        Compare_cnt = 0; // counter re-init
        User_ACL_cnt = 0; // counter re-init

        while(1){ /* Parse read MAC */
            if(systemAcl.Data[Compare_cnt * 8] == 0){
                /* @remark : There are no MAC exist in get ACL setting */
                break;
            }
            else{
                /* @remark : Parse node specific MAC */
                Read_ACL[User_ACL_cnt] |= systemAcl.Data[Compare_cnt * 8 + 5] << 16; //6th MAC
                Read_ACL[User_ACL_cnt] |= systemAcl.Data[Compare_cnt * 8 + 6] << 8; //7th MAC
                Read_ACL[User_ACL_cnt] |= systemAcl.Data[Compare_cnt * 8 + 7]; //8th MAC
                User_ACL_cnt ++;
            }
            Compare_cnt++;
        }

        Compare_cnt = 0; // counter re-init
        User_ACL_cnt = 0; // counter re-init

        /* @remark : Compare MAC */
        for(Compare_cnt = 0; Compare_cnt < 64; Compare_cnt++){
            ACL_rc = false;
            for(User_ACL_cnt = 0; User_ACL_cnt < 64; User_ACL_cnt++){
                if(User_ACL[Compare_cnt] == Read_ACL[User_ACL_cnt]){
                    ACL_rc = true; /* found same MAC */
                    break;
                }
            }
            if(ACL_rc == false) break;
        }
    }
    else{
        /* iCount is different */
        ACL_rc = false;
        if (systemAcl.iCount == 0) ACL_EMPTY = true; //Empty managers case
    }

    return ACL_rc;    
}

/******************************************************************************
 * Inherit from TC275 project
 * @remark : These functions are only for TC387
 *****************************************************************************/

bool adi_wil_example_PeriodicallyCallProcessTask(void)
{
    return adi_wil_hal_TaskStart(PROCESS_TASK_INTERVAL_USEC, adi_task_serviceProcessTask);
}

/* service the adi_wil_ProcessTask() call and record result */
static void adi_task_serviceProcessTask(void)
{
    adi_gProcessTaskErrorCode = adi_wil_ProcessTask(&packInstance);
}

bool adi_wil_example_PeriodicallyCallProcessTaskCB(void)
{
    return adi_wil_hal_TaskCBStart(PROCESS_TASK_CB_INTERVAL_USEC, adi_task_serviceProcessTaskCB);
}

/* service the adi_wil_ProcessTask() call and record result */
static void adi_task_serviceProcessTaskCB(void)
{
    /* Read BMS data goes here */
    adi_task_bmsDataRetrieval();
}

void adk_debug_Report(ADK_FAIL_API_NAME api, adi_wil_err_t rc ){
    ADK_DEMO.DBG_FAIL_API = api;
    ADK_DEMO.DBG_FAIL__RC = rc;
#if 1 // @SURE - ADDED, This point occur error after switch from main to sub.
    while(ADK_DEMO.BOOT_STEP != 100)
    {
        ADK_DEMO.ERROR_COUNT = 1;
    }
#else
    while(1);
#endif
}

/**
 * @brief   Timing measurement for WIL example initialization, saved in BOOT_TIME structure [1ms tick]
 *
 * @param  bool                 Overall_, Interval
 *
 * @param  bool                 LogStart, LogEnd__
 * 
 * @param  uint16_t             ADK_DEMO.BOOT
 * 
 * @param  ADK_LOG_FUNCTION     function name
 *
 * @return None
 */
void adk_debug_BootTimeLog(bool final, bool start, uint16_t step, ADK_LOG_FUNCTION api ){
    if(final == true){
        if(start == true){
            BOOT_TIME[0].timestamp[0] = adk_debug_TickerBTGetTimestamp();
            BOOT_TIME[0].STEP = step;
        }
        else{
            BOOT_TIME[0].timestamp[1] = adk_debug_TickerBTGetTimestamp();
            BOOT_TIME[0].timestamp[2] = BOOT_TIME[0].timestamp[1] - BOOT_TIME[0].timestamp[0];  //result in msec
            BOOT_TIME[0].DURATION = ((float)BOOT_TIME[0].timestamp[2]) / 1000;                  //convert to sec
            BOOT_TIME[0].API = api;
        }
    }
    else{
        if(start == true){
            BOOT_TIME[G_BOOT_TIME_CNT].timestamp[0] = adk_debug_TickerBTGetTimestamp();
            BOOT_TIME[G_BOOT_TIME_CNT].STEP = step;
        }
        else{
            BOOT_TIME[G_BOOT_TIME_CNT].timestamp[1] = adk_debug_TickerBTGetTimestamp();
            BOOT_TIME[G_BOOT_TIME_CNT].timestamp[2] = BOOT_TIME[G_BOOT_TIME_CNT].timestamp[1] - BOOT_TIME[G_BOOT_TIME_CNT].timestamp[0];
            BOOT_TIME[G_BOOT_TIME_CNT].DURATION = ((float)BOOT_TIME[G_BOOT_TIME_CNT].timestamp[2]) / 1000;
            BOOT_TIME[G_BOOT_TIME_CNT].API = api;
            G_BOOT_TIME_CNT++;
        }
    }
}

/**
 * @brief  Covert WIL Device Id to uint8_t
 *
 * @param  adi_wil_device_t[in]      WilDeviceId
 *
 * @return uint8_t[out]              DeviceId
 */

uint8_t ADK_ConvertDeviceId (adi_wil_device_t WilDeviceId)
{
    uint8_t DeviceId = 100;

    if      (WilDeviceId == ADI_WIL_DEV_NODE_0 ) DeviceId = 0;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_1 ) DeviceId = 1;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_2 ) DeviceId = 2;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_3 ) DeviceId = 3;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_4 ) DeviceId = 4;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_5 ) DeviceId = 5;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_6 ) DeviceId = 6;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_7 ) DeviceId = 7;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_8 ) DeviceId = 8;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_9 ) DeviceId = 9;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_10) DeviceId = 10;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_11) DeviceId = 11;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_12) DeviceId = 12;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_13) DeviceId = 13;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_14) DeviceId = 14;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_15) DeviceId = 15;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_16) DeviceId = 16;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_17) DeviceId = 17;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_18) DeviceId = 18;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_19) DeviceId = 19;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_20) DeviceId = 20;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_21) DeviceId = 21;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_22) DeviceId = 22;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_23) DeviceId = 23;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_24) DeviceId = 24;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_25) DeviceId = 25;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_26) DeviceId = 26;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_27) DeviceId = 27;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_28) DeviceId = 28;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_29) DeviceId = 29;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_30) DeviceId = 30;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_31) DeviceId = 31;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_32) DeviceId = 32;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_33) DeviceId = 33;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_34) DeviceId = 34;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_35) DeviceId = 35;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_36) DeviceId = 36;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_37) DeviceId = 37;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_38) DeviceId = 38;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_39) DeviceId = 39;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_40) DeviceId = 40;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_41) DeviceId = 41;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_42) DeviceId = 42;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_43) DeviceId = 43;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_44) DeviceId = 44;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_45) DeviceId = 45;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_46) DeviceId = 46;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_47) DeviceId = 47;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_48) DeviceId = 48;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_49) DeviceId = 49;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_50) DeviceId = 50;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_51) DeviceId = 51;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_52) DeviceId = 52;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_53) DeviceId = 53;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_54) DeviceId = 54;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_55) DeviceId = 55;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_56) DeviceId = 56;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_57) DeviceId = 57;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_58) DeviceId = 58;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_59) DeviceId = 59;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_60) DeviceId = 60;
    else if (WilDeviceId == ADI_WIL_DEV_NODE_61) DeviceId = 61;
    else if (WilDeviceId == ADI_WIL_DEV_MANAGER_0) DeviceId = 240;
    else if (WilDeviceId == ADI_WIL_DEV_MANAGER_1) DeviceId = 241;
    else if (WilDeviceId == ADI_WIL_DEV_ALL_MANAGERS) DeviceId = 254;
    else if (WilDeviceId == ADI_WIL_DEV_ALL_NODES) DeviceId = 255;
    else DeviceId = 200;

    return DeviceId;
}

void adk_debug_log_GetDeviceVersion(ADK_OTAP_ARG_0 eDeviceID, ADK_OTAP_ARG_1 update, uint8_t idx)
{
#if 1 // V2.1.0 OTAP
    if(eDeviceID == OTAP_Mngr)
    {
        if(update == OTAP_P0)
        {
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
        else if(update == OTAP_P2)
        {
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P2_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P2_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P2_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P2_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
        else if(update == OTAP_P3)
        {
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P3_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P3_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P3_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_MNGR[idx].OTAP_P3_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
        else if(update == OTAP_NOW)
        {
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
    }
    else if(eDeviceID == OTAP_Node)
    {
        if(update == OTAP_P0)
        {
            ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
        else if(update == OTAP_P2)
        {
            ADK_DEMO.OTAP_NODE[idx].OTAP_P2_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P2_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P2_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P2_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
        else if(update == OTAP_P3)
        {
            ADK_DEMO.OTAP_NODE[idx].OTAP_P3_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P3_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P3_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_NODE[idx].OTAP_P3_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
        else if(update == OTAP_NOW)
        {
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
    }
#else
    if(eDeviceID == OTAP_Mngr)
    {
        if(update == OTAP_NOW)
        {
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_MNGR[idx].CURRENT_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
    }
    else if(eDeviceID == OTAP_Node)
    {
        if(update == OTAP_NOW)
        {
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionMajor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMajor;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionMinor = ClientData.DeviceVersion.MainProcSWVersion.iVersionMinor;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionPatch = ClientData.DeviceVersion.MainProcSWVersion.iVersionPatch;
            ADK_DEMO.OTAP_NODE[idx].CURRENT_OPFW_VER.iVersionBuild = ClientData.DeviceVersion.MainProcSWVersion.iVersionBuild;
        }
    }
#endif
}

#if 1 // V2.1.0 OTAP
adi_wil_err_t adi_wil_example_otap_QueryDevicePort0(adi_wil_configuration_t * const pConfig)
{
    return adi_wil_example_otap_QueryDeviceCommon(&PortManager0, pConfig, "Port 0");
}

adi_wil_err_t adi_wil_example_otap_QueryDevicePort1(adi_wil_configuration_t * const pConfig)
{
    return adi_wil_example_otap_QueryDeviceCommon(&PortManager1, pConfig, "Port 1");
}

adi_wil_err_t adi_wil_example_otap_QueryDeviceCommon(adi_wil_port_t * const pPort, adi_wil_configuration_t * const pConfig, char const pPortName[])
{
    // char macBuffer[ADI_WIL_MAC_ADDR_SIZE * 3];
    bool callback_success = false;

    adi_wil_err_t rc = adi_wil_QueryDevice(pPort);

    if (rc == ADI_WIL_ERR_SUCCESS)
    {
        /* Wait for non-blocking API to complete */
        pQueryDeviceConfig = pConfig;
        queryDeviceCallbackCalled = false;
        while (!queryDeviceCallbackCalled)  {  /* spin wait */ }

        rc = queryDeviceRc;
        callback_success = (rc == ADI_WIL_ERR_SUCCESS);
    }

    // info("adi_wil_QueryDevice returned result code = %s", adi_wil_ErrorToString(rc));
    if (callback_success)
    {
        // adi_wil_SprintMAC(macBuffer, pConfig->MAC);
        // info("  %s MAC = %s", pPortName, macBuffer);
        // adi_wil_SprintMAC(macBuffer, pConfig->PeerMAC);
        // info("  %s PeerMAC = %s", pPortName, macBuffer);
        // info("  %s sensor packet count = %u", pPortName, pConfig->iSensorPacketCount);
        // info("  %s configuraton hash = %u", pPortName, pConfig->iConfigurationHash);
        // info("  %s dual configuration = %s", pPortName, pConfig->bDualConfiguration ? "TRUE" : "FALSE");
    }

    return rc;
}

adi_wil_err_t adi_wil_example_confirmManagerFPA(void)
{
    adi_wil_err_t rc = ADI_WIL_ERR_FAIL;

    adi_wil_configuration_t port0Configuration;
    adi_wil_configuration_t port1Configuration;
    adi_wil_err_t port0Rc = adi_wil_example_otap_QueryDevicePort0(&port0Configuration);
    adi_wil_err_t port1Rc = adi_wil_example_otap_QueryDevicePort1(&port1Configuration);

    if ((port0Rc == ADI_WIL_ERR_SUCCESS) && (port1Rc == ADI_WIL_ERR_SUCCESS))
    {
        /* To be valid, verify the managers are running the expected FPA version */
        if((port0Configuration.MainProcSWVersion.iVersionMajor == 1) && 
           (port0Configuration.MainProcSWVersion.iVersionMinor == 100) && 
           (port0Configuration.MainProcSWVersion.iVersionPatch == 0) && 
           (port0Configuration.MainProcSWVersion.iVersionBuild == 255))
           {
                ADK_DEMO.OTAP_MNGR[0].OTAP_P1_FPA__VER.iVersionMajor = port0Configuration.MainProcSWVersion.iVersionMajor;
                ADK_DEMO.OTAP_MNGR[0].OTAP_P1_FPA__VER.iVersionMinor = port0Configuration.MainProcSWVersion.iVersionMinor;
                ADK_DEMO.OTAP_MNGR[0].OTAP_P1_FPA__VER.iVersionPatch = port0Configuration.MainProcSWVersion.iVersionPatch;
                ADK_DEMO.OTAP_MNGR[0].OTAP_P1_FPA__VER.iVersionBuild = port0Configuration.MainProcSWVersion.iVersionBuild;
           }
        else
        {
            while(1);
        }

        if((port1Configuration.MainProcSWVersion.iVersionMajor == 1) && 
           (port1Configuration.MainProcSWVersion.iVersionMinor == 100) && 
           (port1Configuration.MainProcSWVersion.iVersionPatch == 0) && 
           (port1Configuration.MainProcSWVersion.iVersionBuild == 255))
           {
                ADK_DEMO.OTAP_MNGR[1].OTAP_P1_FPA__VER.iVersionMajor = port1Configuration.MainProcSWVersion.iVersionMajor;
                ADK_DEMO.OTAP_MNGR[1].OTAP_P1_FPA__VER.iVersionMinor = port1Configuration.MainProcSWVersion.iVersionMinor;
                ADK_DEMO.OTAP_MNGR[1].OTAP_P1_FPA__VER.iVersionPatch = port1Configuration.MainProcSWVersion.iVersionPatch;
                ADK_DEMO.OTAP_MNGR[1].OTAP_P1_FPA__VER.iVersionBuild = port1Configuration.MainProcSWVersion.iVersionBuild;
           }
        else
        {
            while(1);
        }

        rc = ADI_WIL_ERR_SUCCESS;

    }
    else
    {
        while(1);
    }

    return rc;
}

/******************************************************************************
 * Example function using adi_wil_CheckDeviceVersion
 *****************************************************************************/
bool adi_wil_example_CheckDeviceVersion(ADK_OTAP_ARG_0 eDeviceID, ADK_DEVICE_VER ver, uint8_t idx)
{
    if(eDeviceID == OTAP_Mngr)
    {
        if(ver == VER_2_1_0)
        {
            if((ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionMajor == 2) && \
            (ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionMinor == 1) && \
            (ADK_DEMO.OTAP_MNGR[idx].OTAP_P0_PREV_VER.iVersionPatch == 0))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    else if(eDeviceID == OTAP_Node)
    {
        if(ver == VER_2_1_0)
        {
             if((ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionMajor == 2) && \
            (ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionMinor == 1) && \
            (ADK_DEMO.OTAP_NODE[idx].OTAP_P0_PREV_VER.iVersionPatch == 0))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    return false;
}
#endif


#if 0
#define TOTAL_ITER_TO_RUN               10   // Number of times to run the SPI test
 
uint8_t Spi_TxData_0[256];
static uint8_t Spi_RxData_0[10][256];
uint8_t Spi_TxData_1[256];
static uint8_t Spi_RxData_1[10][256];
static struct  wbms_cmd_resp_query_device_t QueryDeviceResp_0[10];
static struct  wbms_cmd_resp_query_device_t QueryDeviceResp_1[10];
uint8_t Cbk_0_cnt = 0;
uint8_t Cbk_1_cnt = 0;
 
void Spi_TxCompleteCbk_0(uint8_t iSPIDevice, uint8_t iChipSelect)
{
    if(Spi_RxData_0[Cbk_0_cnt][4] == 0x7F)
    {
        memcpy(&QueryDeviceResp_0[Cbk_0_cnt], &Spi_RxData_0[Cbk_0_cnt][6], sizeof(struct wbms_cmd_resp_query_device_t));
    }
    Cbk_0_cnt++;
}
 
void Spi_TxCompleteCbk_1(uint8_t iSPIDevice, uint8_t iChipSelect)
{
    if(Spi_RxData_1[Cbk_1_cnt][4] == 0x7F)
    {
        memcpy(&QueryDeviceResp_1[Cbk_1_cnt], &Spi_RxData_1[Cbk_1_cnt][6], sizeof(struct wbms_cmd_resp_query_device_t));
    }
    Cbk_1_cnt++;
}
 
void Test_Spi_Hal_0(void)
{
    uint32_t delay = 0;
    int i = 0;

    adi_wil_hal_SpiInit(0, &Spi_TxCompleteCbk_0);
     
    memset(&Spi_TxData_0[0], 0, 256);
     
    Spi_TxData_0[0]   = 0x04;
    Spi_TxData_0[1]   = 0xFF;
    Spi_TxData_0[2]   = 0x00;
    Spi_TxData_0[3]   = 0x00;
    Spi_TxData_0[4]   = 0x7F;
    Spi_TxData_0[5]   = 0x02;
     
    Spi_TxData_0[252] = 0xD6;
    Spi_TxData_0[253] = 0xEC;
    Spi_TxData_0[254] = 0x8B;
    Spi_TxData_0[255] = 0x01;
     
    for( i = 0; i < TOTAL_ITER_TO_RUN; i++)
    {
        adi_wil_hal_SpiTransmit(0, 0, &Spi_TxData_0[0], &Spi_RxData_0[i][0], 256);
        
        for(delay=0; delay<1250000; delay++){
            //5ms
        }
    }
}

int test_cnt = 0;

void Test_Spi_Hal_1(void)
{
    uint32_t delay = 0;
    int i = 0;

    adi_wil_hal_SpiInit(1, &Spi_TxCompleteCbk_1);
     
    memset(&Spi_TxData_1[0], 0, 256);
     
    Spi_TxData_1[0]   = 0x04;
    Spi_TxData_1[1]   = 0xFF;
    Spi_TxData_1[2]   = 0x00;
    Spi_TxData_1[3]   = 0x00;
    Spi_TxData_1[4]   = 0x7F;
    Spi_TxData_1[5]   = 0x02;
     
    Spi_TxData_1[252] = 0xD6;
    Spi_TxData_1[253] = 0xEC;
    Spi_TxData_1[254] = 0x8B;
    Spi_TxData_1[255] = 0x01;
     
    for( i = 0; i < TOTAL_ITER_TO_RUN; i++)
    {
        adi_wil_hal_SpiTransmit(1, 0, &Spi_TxData_1[0], &Spi_RxData_1[i][0], 256);
        test_cnt++;
        for(delay=0; delay<1250000; delay++){
            //5ms
        }
    }
}

#endif

#if 1 // @SURE - ADDED
uint8_t adi_wil_example_get_real_node_index(uint8_t nNode)
{
    uint8_t i_node = 0;
    unsigned char noNode = 0xFF;

    for(i_node = 0; i_node < NODE_NUM; i_node++)
    {
        noNode = ADK_DEMO.NODE[i_node].NO_OF_USERACL;
        if(noNode != 0xFF)
        {
            if(noNode == nNode)
            {
                return i_node;
            }
        }
    }

    return 0xFF;
}

int16_t adi_wil_example_get_cell_voltage(uint8_t nNode, uint8_t nCell)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node == 0xFF) 
    {
        return 0x8500; // 5.1072V, 0
    }

    return ADK_DEMO.NODE[i_node].CELL_Vi[nCell];
}

int16_t adi_wil_example_get_temp(uint8_t nNode, uint8_t nCell)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node == 0xFF)
    {
        return 0x8500; // 5.1072V, 0
    }

    return ADK_DEMO.NODE[i_node].TEMP_Vi[nCell];
}

int8_t adi_wil_example_get_rssi(uint8_t nMngr, uint8_t nNode, uint8_t nMode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return -127;
    }

    /* Mode 0:Current, 1:Worst, 2:Best, 3:Accumulated */
    return ADK_DEMO.NODE[i_node].RSSI[nMngr][nMode];
}

float adi_wil_example_get_pdr(uint8_t nNode, uint8_t nMode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return 0;
    }

    /* Mode 0:Current, 1:Worst, 2:Best, 3:Accumulated */
    return ADK_DEMO.NODE[i_node].PDR[nMode];
}

void adi_wil_example_set_node_recv_packet(void)
{
    uint8_t i_node = 0;
    unsigned char recv_confirm = 0x0;

    for(i_node = 0 ; i_node < NODE_NUM; i_node++)
    {
        recv_confirm = 0x0;
        if(ADK_DEMO.NODE[i_node].BMS_PKT_MAP[0] & 0x4)
        {
            recv_confirm |= 0x1;
        }
        
        if(ADK_DEMO.NODE[i_node].BMS_PKT_MAP[0] & 0x2)
        {
            recv_confirm |= 0x2;
        }
        
        if(ADK_DEMO.NODE[i_node].BMS_PKT_MAP[0] & 0x1)
        {
            recv_confirm |= 0x4;
        }
        
        ADK_DEMO.NODE[i_node].recv_confirm = (uint8_t)((~recv_confirm) & 0x7);
    }
}

uint8_t adi_wil_example_get_node_recv_packet(uint8_t nNode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return 0x07;
    }
    
    return ADK_DEMO.NODE[i_node].recv_confirm;
}

adi_wil_network_data_t *adi_wil_example_get_network_metadata(uint8_t nNode, uint8_t nIdx)
{
    uint8_t temp_cnt = 0;
    uint8_t temp_node = 0;
    uint8_t i_node = 0;

    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node != 0xFF)
    {
        for(temp_cnt = 0; temp_cnt < (NODE_NUM * ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL); temp_cnt++)
        {
            temp_node = ADK_ConvertDeviceId(userNetworkBuffer[temp_cnt].eSrcDeviceId);
            if(i_node == temp_node)
            {
                if((temp_cnt%ADI_BMS_PACKETS_PER_NODE_PER_INTERVAL) == nIdx)
                {
                    if(!ADK_DEMO.NODE[i_node].DISCONN_STAT)
                    {
                        return &userNetworkBuffer[temp_cnt];
                    }
                }
            }
        }
    }

    return NULL;
}

uint16_t adi_wil_example_get_bms_packet_latency(uint8_t nNode, uint8_t nIdx)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return 0xFFFF;
    }

    return adi_wil_example_GetBmsPacketLatency(nNode, nIdx);
}

uint16_t adi_wil_example_get_net_data_max_latency(uint8_t nNode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return 0xFFFF;
    }


    return ADK_DEMO.NODE[i_node].LATENCY[0];
}

adi_wil_health_report0_t *adi_wil_example_get_hr0_data(uint8_t nNode)
{
    unsigned char i_node = 0xFF;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return NULL;
    }
    
    return &userHR0Buffer[i_node];
}

adi_wil_health_report2_t *adi_wil_example_get_hr2_data(uint8_t nNode)
{
    unsigned char i_node = 0xFF;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return NULL;
    }
    
    return &userHR2Buffer[i_node];
}

adi_wil_health_report10_t *adi_wil_example_get_hr10_data(uint8_t nMngr)
{
    return &userHR10Buffer[nMngr];
}

adi_wil_health_report11_t *adi_wil_example_get_hr11_data(uint8_t nMngr)
{
    return &userHR11Buffer[nMngr];
}

adi_wil_health_report12_t *adi_wil_example_get_hr12_data(uint8_t nMngr)
{
    return &userHR12Buffer[nMngr];
}

int8_t adi_wil_example_get_node_rssi_ch_accumulated(uint8_t nMngr, uint8_t nNode)
{
    unsigned char i_node = 0xFF;
    int8_t nRssi = 0;
    int32_t nRssiAccumulated = 0;
    uint8_t nCh = 0;

    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return -127;
    }

    if(nMngr == 1) // Manager 2
    {
        if(i_node == 0) // Node 1
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 1) // Node 2
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 2) // Node 3
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 3) // Node 4
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 4) // Node 5
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 5) // Node 6
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 6) // Node 7
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 7) // Node 8
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 8) // Node 9
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 9) // Node 10
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 10) // Node 11
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR16Buffer[nMngr].signalRssi[i_node - 10][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 11) // Node 12
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR16Buffer[nMngr].signalRssi[i_node - 10][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
    }
    else // Manager 1
    {
        if(i_node == 0) // Node 1
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 1) // Node 2
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 2) // Node 3
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 3) // Node 4
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 4) // Node 5
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR14Buffer[nMngr].signalRssi[i_node][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 5) // Node 6
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 6) // Node 7
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 7) // Node 8
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 8) // Node 9
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 9) // Node 10
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR15Buffer[nMngr].signalRssi[i_node - 5][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 10) // Node 11
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR16Buffer[nMngr].signalRssi[i_node - 10][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
        else if(i_node == 11) // Node 12
        {
            for(nCh = 0; nCh < (NUM_OF_CHANNELS-1); nCh++)
            {
                nRssiAccumulated += userHR16Buffer[nMngr].signalRssi[i_node - 10][nCh];
            }

            nRssi = (nRssiAccumulated / 13); // idx 6, 14 except, because of there are zero 
        }
    }

    return nRssi;
}

adi_wil_health_report80_t *adi_wil_example_get_hr80_data(uint8_t nNode)
{
    unsigned char i_node = 0xFF;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if((i_node == 0xFF) || (ADK_DEMO.NODE[i_node].DISCONN_STAT))
    {
        return NULL;
    }

    return &userHR80Buffer[i_node];
}

uint16_t adi_wil_example_get_owd_status(uint8_t nNode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node == 0xFF)
    {
        return 0;
    }
    
    return ADK_DEMO.NODE[i_node].CELL_OWD_STAT;
}

ADK_DEMO_TYPE adi_wil_example_get_mode_status(void)
{
    return ADK_DEMO.DEMO_MODE;
}

void adi_wil_example_set_mode_status(ADK_DEMO_TYPE mode)
{
    ADK_DEMO.DEMO_MODE = mode;
}

void adi_wil_example_set_authority(unsigned char authority)
{
    ADK_DEMO.AUTHORITY = authority;
    ADK_DEMO.DBG_FAIL_API = NO_fail_api_so_far;
    ADK_DEMO.DBG_FAIL__RC = ADI_WIL_ERR_SUCCESS;
}

#if 1 // V2.1.0 OTAP
void adi_wil_example_set_otapfw_upgrade(unsigned char upgrade)
{
    ADK_DEMO.OTAPFW_UPGRADE = upgrade;
}

uint8_t adi_example_get_otap_mngr_progress(uint8_t nMngr)
{
    return (uint8_t)ADK_DEMO.OTAP_MNGR[nMngr].OTAP____PROGRESS;
}

uint8_t adi_example_get_otap_node_progress(uint8_t nNode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node == 0xFF)
    {
        return 0;
    }

    return (uint8_t)ADK_DEMO.OTAP_NODE[i_node].OTAP____PROGRESS;
}

uint16_t adi_example_get_otap_stat(void)
{
    return (uint16_t)ADK_DEMO.OTAP_STAT;
}

void adi_example_get_otap_mngr_current_version(uint8_t nMngr, uint8_t aOpFwVer[8])
{
    memcpy(aOpFwVer, &ADK_DEMO.OTAP_MNGR[nMngr].CURRENT_OPFW_VER, sizeof(adi_wil_version_t));
}

void adi_example_get_otap_node_current_version(uint8_t nNode, uint8_t aOpFwVer[8])
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node == 0xFF)
    {
        memset(aOpFwVer, 0x0, sizeof(aOpFwVer));
        return;
    }

    memcpy(aOpFwVer, &ADK_DEMO.OTAP_NODE[i_node].CURRENT_OPFW_VER, sizeof(adi_wil_version_t));
}
#endif

void adi_wil_example_set_over_voltage(void)
{
    uint8_t i_node = 0, i_cell = 0;

    for(i_node = 0 ; i_node < ADK_MAX_node; i_node++)
    {
        ADK_DEMO.NODE[i_node].OV_STAT = 0x0000;
    }

    for(i_node = 0 ; i_node < NODE_NUM; i_node++)
    {
        for(i_cell = 0 ; i_cell < ADK_MAX_cell ; i_cell++)
        {
            ADK_DEMO.NODE[i_node].OV_STAT |= (OVER_VOLTAGE(ADK_DEMO.NODE[i_node].CELL_Vi[i_cell] - 10000) << i_cell);
        }

        if(ADK_DEMO.NODE[i_node].OV_STAT != 0x0000)
        {
            ADK_DEMO.IS_OVER_VOLTAGE = 1;
        }
    }
}

unsigned char adi_wil_example_is_over_voltage(void)
{
    return ADK_DEMO.IS_OVER_VOLTAGE;
}

unsigned char adi_wil_example_is_notify_network_data(void)
{
    return (unsigned char)adi_gNotifyNetworkMeta;
}

bool adi_wil_example_is_fail(void)
{
    bool is_error = false;
    uint8_t nNode, i_node;
    
    if((ADK_DEMO.DBG_FAIL__RC != ADI_WIL_ERR_SUCCESS) && 
        (ADK_DEMO.DBG_FAIL__RC != ADI_WIL_ERR_TIMEOUT))
    {
        is_error = true;
    }

    for(nNode = 0; nNode < ADK_MAX_node; nNode++)
    {
        i_node = adi_wil_example_get_real_node_index(nNode);
        if(i_node != 0xFF)
        {
            if(ADK_DEMO.NODE[i_node].DISCONN_STAT)
            {
                is_error = true;
                break;
            }
        }
    }

    if(ADK_DEMO.ERROR_COUNT)
    {
        is_error = true;
    }
    
    return is_error;
}

void adi_wil_example_set_mngr_status(adi_wil_device_t eDeviceId, unsigned char connected)
{
    if(eDeviceId == ADI_WIL_DEV_MANAGER_0)
    {
        ADK_DEMO.MNGR_STAT[0] = connected;
    }
    
    if(eDeviceId == ADI_WIL_DEV_MANAGER_1)
    {
        ADK_DEMO.MNGR_STAT[1] = connected;
    }
}

void adi_wil_example_is_mngr_status(unsigned char *MNGR_STAT)
{
    memcpy(MNGR_STAT, &ADK_DEMO.MNGR_STAT, ADK_MAX_mngr);
}

void adi_wil_example_set_node_connected(adi_wil_pack_t const * const pPack)
{
    uint8_t i_node = 0, iConnectState;
    
    if(pPack != NULL)
    {
        adi_wil_pack_internals_t *Internals = pPack->pInternals;
        if(Internals != NULL)
        {
            adi_wil_node_state_t *NodeState = &Internals->NodeState;
            if(NodeState != NULL)
            {
                for(i_node = 0; i_node < NODE_NUM; i_node++)
                {
                    iConnectState = ((NodeState->iConnectState >> i_node) & 0x1);
                    if(iConnectState)
                    {
                        ADK_DEMO.NODE[i_node].DISCONN_STAT = false;
                    }
                    else
                    {
                        ADK_DEMO.NODE[i_node].DISCONN_STAT = true;
                        ADK_DEMO.NODE[i_node].PDR[0] = 0; // Current
                        ADK_DEMO.NODE[i_node].PDR[1] = 100.0; // Worst
                        ADK_DEMO.NODE[i_node].PDR[2] = 0; // Best
                        ADK_DEMO.NODE[i_node].PDR[3] = 0; // Accumulated
                    }
                }
            }
        }
    }
}

bool adi_wil_example_is_node_connected(uint8_t nNode)
{
    uint8_t i_node = 0;
    i_node = adi_wil_example_get_real_node_index(nNode);
    if(i_node == 0xFF)
    {
        return false;
    }

    return (ADK_DEMO.NODE[i_node].DISCONN_STAT) ? false : true;
}

void adi_example_get_mngr_sw_version(uint8_t aFwVer[8])
{
    if(pConfiguration != NULL)
    {
        memcpy(aFwVer, &pConfiguration->MainProcSWVersion, sizeof(adi_wil_version_t));
    }
}
#endif
