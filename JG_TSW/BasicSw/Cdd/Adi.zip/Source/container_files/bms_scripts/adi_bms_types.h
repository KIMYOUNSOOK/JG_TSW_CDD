/*******************************************************************************
* Copyright (c) 2020 Analog Devices, Inc. All Rights Reserved.
* This software is proprietary and confidential to Analog Devices, Inc. and its licensors.
*******************************************************************************/

#ifndef ADI_BMS_TYPES_H_
#define ADI_BMS_TYPES_H_

#include <stdint.h>
#include "adi_bms_defs.h"
#include "adi_wil_example_debug_functions.h"

#if     (ADK_ADBMS683x == 0) /* ADBMS6830 */
typedef struct {
    uint8_t	iPacket_id;                                     // Packet Format Id
    uint8_t	iPacket_timestamp_0;                            // Packet Timestamp, byte 0
    uint8_t	iPacket_timestamp_1;                            // Packet Timestamp, byte 1
    uint8_t	iPacket_timestamp_2;                            // Packet Timestamp, byte 2
    uint8_t	iPacket_crc[ADI_BMS_SIZE_PACKET_CRC];           // Bit reversed packet CRC
} adi_bms_packetheader_t;

typedef struct {
    uint8_t	iVref2[ADI_BMS_SIZE_VREF2];                     // Second Reference Voltage
    uint8_t	iItmp[ADI_BMS_SIZE_ITMP];                       // Internal Die Temperature
    uint8_t	iStar4;                                         // RDSTATA register STAR4
    uint8_t	iStar5;                                         // RDSTATA register STAR5
    uint8_t	iRdstata_pec[ADI_BMS_SIZE_RDSTATA_PEC];         // PEC for Status Register Group A
} adi_bms_rdstata_t;

typedef struct {
    uint8_t	iVd[ADI_BMS_SIZE_VD];                           // Digital Power Supply Voltage
    uint8_t	iVa[ADI_BMS_SIZE_VA];                           // Analog Power Supply Voltage
    uint8_t	iVres[ADI_BMS_SIZE_VRES];                       // Voltage Across Resistor
    uint8_t	iRdstatb_pec[ADI_BMS_SIZE_RDSTATB_PEC];         // PEC for Status Register Group B
} adi_bms_rdstatb_t;

typedef struct {
    uint8_t	iCsflt[ADI_BMS_SIZE_CSFLT];                     // C vs S Fault of Channels
    uint8_t	iCt_cts[ADI_BMS_SIZE_CT_CTS];                   // Conversion Counter and Sub-Counter
    uint8_t	iStcr4;                                         // RDSTATC register STCR4
    uint8_t	iStcr5;                                         // RDSTATC register STCR5
    uint8_t	iRdstatc_pec[ADI_BMS_SIZE_RDSTATC_PEC];         // PEC for Status Register Group C
} adi_bms_rdstatc_t;

typedef struct {
    uint8_t	iPwmr0;                                         // PWM Register 0
    uint8_t	iPwmr1;                                         // PWM Register 1
    uint8_t	iPwmr2;                                         // PWM Register 2
    uint8_t	iPwmr3;                                         // PWM Register 3
    uint8_t	iPwmr4;                                         // PWM Register 4
    uint8_t	iPwmr5;                                         // PWM Register 5
    uint8_t	iRdpwma_pec[ADI_BMS_SIZE_RDPWMA_PEC];           // PEC for PWMR[0:5]
} adi_bms_rdpwma_t;

typedef struct {
    uint8_t	iG10v[ADI_BMS_SIZE_G10V];                       // Auxiliary Register 10
    uint8_t	iVmv[ADI_BMS_SIZE_VMV];                         // V+ to V- Measurement
    uint8_t	iVpv[ADI_BMS_SIZE_VPV];                         // V- to V- Measurement
    uint8_t	iRdauxd_pec[ADI_BMS_SIZE_RDAUXD_PEC];           // PEC for Auxiliary Register Group D
} adi_bms_rdauxd_t;

typedef struct {
    uint8_t	iSidr0;                                         // Serial ID register, byte 0
    uint8_t	iSidr1;                                         // Serial ID register, byte 1
    uint8_t	iSidr2;                                         // Serial ID register, byte 2
    uint8_t	iSidr3;                                         // Serial ID register, byte 3
    uint8_t	iSidr4;                                         // Serial ID register, byte 4
    uint8_t	iSidr5;                                         // Serial ID register, byte 5
    uint8_t	iRdsid_pec[ADI_BMS_SIZE_RDSID_PEC];             // PEC for Serial Identification Code
} adi_bms_rdsid_t;

typedef struct {
    uint8_t	iFc1v[ADI_BMS_SIZE_FC1V];                       // Filtered Cell 1 Voltage
    uint8_t	iFc2v[ADI_BMS_SIZE_FC2V];                       // Filtered Cell 2 Voltage
    uint8_t	iFc3v[ADI_BMS_SIZE_FC3V];                       // Filtered Cell 3 Voltage
    uint8_t	iRdfca_pec[ADI_BMS_SIZE_RDFCA_PEC];             // PEC for RDFC Register Groups
} adi_bms_rdfca_t;

typedef struct {
    uint8_t	iFc4v[ADI_BMS_SIZE_FC4V];                       // Filtered Cell 4 Voltage
    uint8_t	iFc5v[ADI_BMS_SIZE_FC5V];                       // Filtered Cell 5 Voltage
    uint8_t	iFc6v[ADI_BMS_SIZE_FC6V];                       // Filtered Cell 6 Voltage
    uint8_t	iRdfcb_pec[ADI_BMS_SIZE_RDFCB_PEC];             // PEC for RDFC Register Groups
} adi_bms_rdfcb_t;

typedef struct {
    uint8_t	iFc7v[ADI_BMS_SIZE_FC7V];                       // Filtered Cell 7 Voltage
    uint8_t	iFc8v[ADI_BMS_SIZE_FC8V];                       // Filtered Cell 8 Voltage
    uint8_t	iFc9v[ADI_BMS_SIZE_FC9V];                       // Filtered Cell 9 Voltage
    uint8_t	iRdfcc_pec[ADI_BMS_SIZE_RDFCC_PEC];             // PEC for RDFC Register Groups
} adi_bms_rdfcc_t;

typedef struct {
    uint8_t	iFc10v[ADI_BMS_SIZE_FC10V];                     // Filtered Cell 10 Voltage
    uint8_t	iFc11v[ADI_BMS_SIZE_FC11V];                     // Filtered Cell 11 Voltage
    uint8_t	iFc12v[ADI_BMS_SIZE_FC12V];                     // Filtered Cell 12 Voltage
    uint8_t	iRdfcd_pec[ADI_BMS_SIZE_RDFCD_PEC];             // PEC for RDFC Register Groups
} adi_bms_rdfcd_t;

typedef struct {
    uint8_t	iFc13v[ADI_BMS_SIZE_FC13V];                     // Filtered Cell 13 Voltage
    uint8_t	iFc14v[ADI_BMS_SIZE_FC14V];                     // Filtered Cell 14 Voltage
    uint8_t	iFc15v[ADI_BMS_SIZE_FC15V];                     // Filtered Cell 15 Voltage
    uint8_t	iRdfce_pec[ADI_BMS_SIZE_RDFCE_PEC];             // PEC for RDFC Register Groups
} adi_bms_rdfce_t;

typedef struct {
    uint8_t	iFc16v[ADI_BMS_SIZE_FC16V];                     // Filtered Cell 16 Voltage
    uint8_t	iFcvfr2;                                        // FCVFR2 = 255
    uint8_t	iFcvfr3;                                        // FCVFR3 = 255
    uint8_t	iFcvfr4;                                        // FCVFR4 = 255
    uint8_t	iFcvfr5;                                        // FCVFR5 = 255
    uint8_t	iRdfcf_pec[ADI_BMS_SIZE_RDFCF_PEC];             // PEC for RDFC Register Groups
} adi_bms_rdfcf_t;

typedef struct {
    uint8_t	iG1v[ADI_BMS_SIZE_G1V];                         // Auxiliary Register 1
    uint8_t	iG2v[ADI_BMS_SIZE_G2V];                         // Auxiliary Register 2
    uint8_t	iG3v[ADI_BMS_SIZE_G3V];                         // Auxiliary Register 3
    uint8_t	iRdauxa_pec[ADI_BMS_SIZE_RDAUXA_PEC];           // PEC for Auxiliary Register Group A
} adi_bms_rdauxa_t;

typedef struct {
    uint8_t	iG4v[ADI_BMS_SIZE_G4V];                         // Auxiliary Register 4
    uint8_t	iG5v[ADI_BMS_SIZE_G5V];                         // Auxiliary Register 5
    uint8_t	iG6v[ADI_BMS_SIZE_G6V];                         // Auxiliary Register 6
    uint8_t	iRdauxb_pec[ADI_BMS_SIZE_RDAUXB_PEC];           // PEC for Auxiliary Register Group B
} adi_bms_rdauxb_t;

typedef struct {
    uint8_t	iS1v[ADI_BMS_SIZE_S1V];                         // Spin Voltage 1
    uint8_t	iS2v[ADI_BMS_SIZE_S2V];                         // Spin Voltage 2
    uint8_t	iS3v[ADI_BMS_SIZE_S3V];                         // Spin Voltage 3
    uint8_t	iRdsva_pec[ADI_BMS_SIZE_RDSVA_PEC];             // PEC for Spin Voltage Register Group A
} adi_bms_rdsva_t;

typedef struct {
    uint8_t	iS4v[ADI_BMS_SIZE_S4V];                         // Spin Voltage 4
    uint8_t	iS5v[ADI_BMS_SIZE_S5V];                         // Spin Voltage 5
    uint8_t	iS6v[ADI_BMS_SIZE_S6V];                         // Spin Voltage 6
    uint8_t	iRdsvb_pec[ADI_BMS_SIZE_RDSVB_PEC];             // PEC for Spin Voltage Register Group B
} adi_bms_rdsvb_t;

typedef struct {
    uint8_t	iS7v[ADI_BMS_SIZE_S7V];                         // Spin Voltage 7
    uint8_t	iS8v[ADI_BMS_SIZE_S8V];                         // Spin Voltage 8
    uint8_t	iS9v[ADI_BMS_SIZE_S9V];                         // Spin Voltage 9
    uint8_t	iRdsvc_pec[ADI_BMS_SIZE_RDSVC_PEC];             // PEC for Spin Voltage Register Group C
} adi_bms_rdsvc_t;

typedef struct {
    uint8_t	iS10v[ADI_BMS_SIZE_S10V];                       // Spin Voltage 10
    uint8_t	iS11v[ADI_BMS_SIZE_S11V];                       // Spin Voltage 11
    uint8_t	iS12v[ADI_BMS_SIZE_S12V];                       // Spin Voltage 12
    uint8_t	iRdsvd_pec[ADI_BMS_SIZE_RDSVD_PEC];             // PEC for Spin Voltage Register Group D
} adi_bms_rdsvd_t;

typedef struct {
    uint8_t	iS13v[ADI_BMS_SIZE_S13V];                       // Spin Voltage 13
    uint8_t	iS14v[ADI_BMS_SIZE_S14V];                       // Spin Voltage 14
    uint8_t	iS15v[ADI_BMS_SIZE_S15V];                       // Spin Voltage 15
    uint8_t	iRdsve_pec[ADI_BMS_SIZE_RDSVE_PEC];             // PEC for Spin Voltage Register Group E
} adi_bms_rdsve_t;

typedef struct {
    uint8_t	iS16v[ADI_BMS_SIZE_S16V];                       // Spin Voltage 16
    uint8_t	iSvfr2;                                         // SVFR2 = 255
    uint8_t	iSvfr3;                                         // SVFR3 = 255
    uint8_t	iSvfr4;                                         // SVFR4 = 255
    uint8_t	iSvfr5;                                         // SVFR5 = 255
    uint8_t	iRdsvf_pec[ADI_BMS_SIZE_RDSVF_PEC];             // PEC for Spin Voltage Register Group F
} adi_bms_rdsvf_t;

typedef struct {
    uint8_t	iCfgar0;                                        // Config Group A, register 0
    uint8_t	iCfgar1;                                        // Config Group A, register 1
    uint8_t	iCfgar2;                                        // Config Group A, register 2
    uint8_t	iCfgar3;                                        // Config Group A, register 3
    uint8_t	iCfgar4;                                        // Config Group A, register 4
    uint8_t	iCfgar5;                                        // Config Group A, register 5
    uint8_t	iRdcfga_pec[ADI_BMS_SIZE_RDCFGA_PEC];           // PEC for Cell Config Register Group A
} adi_bms_rdcfga_t;

typedef struct {
    uint8_t	iCfgbr0;                                        // Config Group B, register 0
    uint8_t	iCfgbr1;                                        // Config Group B, register 1
    uint8_t	iCfgbr2;                                        // Config Group B, register 2
    uint8_t	iCfgbr3;                                        // Config Group B, register 3
    uint8_t	iCfgbr4;                                        // Config Group B, register 4
    uint8_t	iCfgbr5;                                        // Config Group B, register 5
    uint8_t	iRdcfgb_pec[ADI_BMS_SIZE_RDCFGB_PEC];           // PEC for Cell Config Register Group B
} adi_bms_rdcfgb_t;

typedef struct {
    uint8_t	iR_g1v[ADI_BMS_SIZE_R_G1V];                     // Redundant Auxiliary Register 1
    uint8_t	iR_g2v[ADI_BMS_SIZE_R_G2V];                     // Redundant Auxiliary Register 2
    uint8_t	iR_g3v[ADI_BMS_SIZE_R_G3V];                     // Redundant Auxiliary Register 3
    uint8_t	iRdraxa_pec[ADI_BMS_SIZE_RDRAXA_PEC];           // PEC for Redundant Auxiliary Register Group A
} adi_bms_rdraxa_t;

typedef struct {
    uint8_t	iR_g10v[ADI_BMS_SIZE_R_G10V];                   // Redundant Auxiliary Register 10
    uint8_t	iRgpdr2;                                        // Group D - Redundant Aux Reg 2
    uint8_t	iRgpdr3;                                        // Group D - Redundant Aux Reg 3
    uint8_t	iRgpdr4;                                        // Group D - Redundant Aux Reg 4
    uint8_t	iRgpdr5;                                        // Group D - Redundant Aux Reg 5
    uint8_t	iRdraxd_pec[ADI_BMS_SIZE_RDRAXD_PEC];           // PEC for Redundant Auxiliary Register Group D
} adi_bms_rdraxd_t;

typedef struct {
    uint8_t	iAc1v[ADI_BMS_SIZE_AC1V];                       // Averaged Cell 1 Voltage
    uint8_t	iAc2v[ADI_BMS_SIZE_AC2V];                       // Averaged Cell 2 Voltage
    uint8_t	iAc3v[ADI_BMS_SIZE_AC3V];                       // Averaged Cell 3 Voltage
    uint8_t	iRdaca_pec[ADI_BMS_SIZE_RDACA_PEC];             // PEC for Averaged Cell Voltage Register Group A
} adi_bms_rdaca_t;

typedef struct {
    uint8_t	iAc4v[ADI_BMS_SIZE_AC4V];                       // Averaged Cell 4 Voltage
    uint8_t	iAc5v[ADI_BMS_SIZE_AC5V];                       // Averaged Cell 5 Voltage
    uint8_t	iAc6v[ADI_BMS_SIZE_AC6V];                       // Averaged Cell 6 Voltage
    uint8_t	iRdacb_pec[ADI_BMS_SIZE_RDACB_PEC];             // PEC for Averaged Cell Voltage Register Group B
} adi_bms_rdacb_t;

typedef struct {
    uint8_t	iAc7v[ADI_BMS_SIZE_AC7V];                       // Averaged Cell 7 Voltage
    uint8_t	iAc8v[ADI_BMS_SIZE_AC8V];                       // Averaged Cell 8 Voltage
    uint8_t	iAc9v[ADI_BMS_SIZE_AC9V];                       // Averaged Cell 9 Voltage
    uint8_t	iRdacc_pec[ADI_BMS_SIZE_RDACC_PEC];             // PEC for Averaged Cell Voltage Register Group C
} adi_bms_rdacc_t;

typedef struct {
    uint8_t	iAc10v[ADI_BMS_SIZE_AC10V];                     // Averaged Cell 10 Voltage
    uint8_t	iAc11v[ADI_BMS_SIZE_AC11V];                     // Averaged Cell 11 Voltage
    uint8_t	iAc12v[ADI_BMS_SIZE_AC12V];                     // Averaged Cell 12 Voltage
    uint8_t	iRdacd_pec[ADI_BMS_SIZE_RDACD_PEC];             // PEC for Averaged Cell Voltage Register Group D
} adi_bms_rdacd_t;

typedef struct {
    uint8_t	iAc13v[ADI_BMS_SIZE_AC13V];                     // Averaged Cell 13 Voltage
    uint8_t	iAc14v[ADI_BMS_SIZE_AC14V];                     // Averaged Cell 14 Voltage
    uint8_t	iAc15v[ADI_BMS_SIZE_AC15V];                     // Averaged Cell 15 Voltage
    uint8_t	iRdace_pec[ADI_BMS_SIZE_RDACE_PEC];             // PEC for Averaged Cell Voltage Register Group E
} adi_bms_rdace_t;

typedef struct {
    uint8_t	iAc16v[ADI_BMS_SIZE_AC16V];                     // Averaged Cell 16 Voltage
    uint8_t	iAcvfr2;                                        // ACVFR2 = 255
    uint8_t	iAcvfr3;                                        // ACVFR3 = 255
    uint8_t	iAcvfr4;                                        // ACVFR4 = 255
    uint8_t	iAcvfr5;                                        // ACVFR5 = 255
    uint8_t	iRdacf_pec[ADI_BMS_SIZE_RDACF_PEC];             // PEC for Averaged Cell Voltage Register Group F
} adi_bms_rdacf_t;

typedef struct {
    uint8_t	iC1v[ADI_BMS_SIZE_C1V];                         // Cell 1 Voltage
    uint8_t	iC2v[ADI_BMS_SIZE_C2V];                         // Cell 2 Voltage
    uint8_t	iC3v[ADI_BMS_SIZE_C3V];                         // Cell 3 Voltage
    uint8_t	iRdcva_pec[ADI_BMS_SIZE_RDCVA_PEC];             // PEC for Cell Voltage Register Group A
} adi_bms_rdcva_t;

typedef struct {
    uint8_t	iC4v[ADI_BMS_SIZE_C4V];                         // Cell 4 Voltage
    uint8_t	iC5v[ADI_BMS_SIZE_C5V];                         // Cell 5 Voltage
    uint8_t	iC6v[ADI_BMS_SIZE_C6V];                         // Cell 6 Voltage
    uint8_t	iRdcvb_pec[ADI_BMS_SIZE_RDCVB_PEC];             // PEC for Cell Voltage Register Group B
} adi_bms_rdcvb_t;

typedef struct {
    uint8_t	iC7v[ADI_BMS_SIZE_C7V];                         // Cell 7 Voltage
    uint8_t	iC8v[ADI_BMS_SIZE_C8V];                         // Cell 8 Voltage
    uint8_t	iC9v[ADI_BMS_SIZE_C9V];                         // Cell 9 Voltage
    uint8_t	iRdcvc_pec[ADI_BMS_SIZE_RDCVC_PEC];             // PEC for Cell Voltage Register Group C
} adi_bms_rdcvc_t;

typedef struct {
    uint8_t	iC10v[ADI_BMS_SIZE_C10V];                       // Cell 10 Voltage
    uint8_t	iC11v[ADI_BMS_SIZE_C11V];                       // Cell 11 Voltage
    uint8_t	iC12v[ADI_BMS_SIZE_C12V];                       // Cell 12 Voltage
    uint8_t	iRdcvd_pec[ADI_BMS_SIZE_RDCVD_PEC];             // PEC for Cell Voltage Register Group D
} adi_bms_rdcvd_t;

typedef struct {
    uint8_t	iC13v[ADI_BMS_SIZE_C13V];                       // Cell 13 Voltage
    uint8_t	iC14v[ADI_BMS_SIZE_C14V];                       // Cell 14 Voltage
    uint8_t	iC15v[ADI_BMS_SIZE_C15V];                       // Cell 15 Voltage
    uint8_t	iRdcve_pec[ADI_BMS_SIZE_RDCVE_PEC];             // PEC for Cell Voltage Register Group E
} adi_bms_rdcve_t;

typedef struct {
    uint8_t	iC16v[ADI_BMS_SIZE_C16V];                       // Cell 16 Voltage
    uint8_t	iCvfr2;                                         // CVFR2 = 255
    uint8_t	iCvfr3;                                         // CVFR3 = 255
    uint8_t	iCvfr4;                                         // CVFR4 = 255
    uint8_t	iCvfr5;                                         // CVFR5 = 255
    uint8_t	iRdcvf_pec[ADI_BMS_SIZE_RDCVF_PEC];             // PEC for Cell Voltage Register Group F
} adi_bms_rdcvf_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdstata_t         Rdstata;
    adi_bms_rdstatb_t         Rdstatb;
    adi_bms_rdstata_t         Rdstata_1;
    adi_bms_rdstatb_t         Rdstatb_1;
    adi_bms_rdstatc_t         Rdstatc;
    adi_bms_rdstatc_t         Rdstatc_1;
    adi_bms_rdstatc_t         Rdstatc_2;
    adi_bms_rdstatc_t         Rdstatc_3;
    adi_bms_rdstatc_t         Rdstatc_4;
} adi_bms_init_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdstatc_t         Rdstatc_5;
    adi_bms_rdstatc_t         Rdstatc_6;
    adi_bms_rdpwma_t          Rdpwma;
    adi_bms_rdpwma_t          Rdpwma_1;
    adi_bms_rdpwma_t          Rdpwma_2;
    adi_bms_rdstatc_t         Rdstatc_7;
    adi_bms_rdauxd_t          Rdauxd;
    adi_bms_rdsid_t           Rdsid;
    adi_bms_rdstatc_t         Rdstatc_8;
} adi_bms_init_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdfca_t           Rdfca;
    adi_bms_rdfcb_t           Rdfcb;
    adi_bms_rdfcc_t           Rdfcc;
    adi_bms_rdfcd_t           Rdfcd;
    adi_bms_rdfce_t           Rdfce;
    adi_bms_rdfcf_t           Rdfcf;
    adi_bms_rdauxa_t          Rdauxa;
    adi_bms_rdauxb_t          Rdauxb;
    adi_bms_rdsva_t           Rdsva;
} adi_bms_base_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdsvb_t           Rdsvb;
    adi_bms_rdsvc_t           Rdsvc;
    adi_bms_rdsvd_t           Rdsvd;
    adi_bms_rdsve_t           Rdsve;
    adi_bms_rdsvf_t           Rdsvf;
    adi_bms_rdcfga_t          Rdcfga;
    adi_bms_rdcfgb_t          Rdcfgb;
    adi_bms_rdstata_t         Rdstata;
    adi_bms_rdstatb_t         Rdstatb;
} adi_bms_base_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdstatc_t         Rdstatc;
    adi_bms_rdraxa_t          Rdraxa;
    adi_bms_rdraxd_t          Rdraxd;
} adi_bms_base_pkt_2_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdaca_t           Rdaca;
    adi_bms_rdacb_t           Rdacb;
    adi_bms_rdacc_t           Rdacc;
    adi_bms_rdacd_t           Rdacd;
    adi_bms_rdace_t           Rdace;
    adi_bms_rdacf_t           Rdacf;
    adi_bms_rdsva_t           Rdsva;
    adi_bms_rdsvb_t           Rdsvb;
    adi_bms_rdsvc_t           Rdsvc;
} adi_bms_latent1_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdsvd_t           Rdsvd;
    adi_bms_rdsve_t           Rdsve;
    adi_bms_rdsvf_t           Rdsvf;
    adi_bms_rdstatc_t         Rdstatc;
} adi_bms_latent1_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdaca_t           Rdaca;
    adi_bms_rdacb_t           Rdacb;
    adi_bms_rdacc_t           Rdacc;
    adi_bms_rdacd_t           Rdacd;
    adi_bms_rdace_t           Rdace;
    adi_bms_rdacf_t           Rdacf;
    adi_bms_rdsva_t           Rdsva;
    adi_bms_rdsvb_t           Rdsvb;
    adi_bms_rdsvc_t           Rdsvc;
} adi_bms_latent2_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdsvd_t           Rdsvd;
    adi_bms_rdsve_t           Rdsve;
    adi_bms_rdsvf_t           Rdsvf;
    adi_bms_rdstatc_t         Rdstatc;
} adi_bms_latent2_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdcva_t           Rdcva;
    adi_bms_rdcvb_t           Rdcvb;
    adi_bms_rdcvc_t           Rdcvc;
    adi_bms_rdcvd_t           Rdcvd;
    adi_bms_rdcve_t           Rdcve;
    adi_bms_rdcvf_t           Rdcvf;
} adi_bms_monitor_pkt_0_t;

typedef struct {
    uint8_t	iMcmd_0_assert_threshold[ADI_BMS_SIZE_MCMD_0_ASSERT_THRESHOLD]; // mcmd_0_assert_threshold
    uint8_t	iBitmask[ADI_BMS_SIZE_BITMASK];                 // bitmask
} adi_bms_monitor_params_t;

#elif   (ADK_ADBMS683x == 3) /* ADBMS6833 */
typedef struct {
    uint8_t	iPacket_id;                                     // Packet Format Id
    uint8_t	iPacket_timestamp_0;                            // Packet Timestamp, byte 0
    uint8_t	iPacket_timestamp_1;                            // Packet Timestamp, byte 1
    uint8_t	iPacket_timestamp_2;                            // Packet Timestamp, byte 2
    uint8_t	iPacket_crc[ADI_BMS_SIZE_PACKET_CRC];           // Bit reversed packet CRC
} adi_bms_packetheader_t;

typedef struct {
    uint8_t	iVref2[ADI_BMS_SIZE_VREF2];                     // Second Reference Voltage
    uint8_t	iItmp[ADI_BMS_SIZE_ITMP];                       // Internal Die Temperature
    uint8_t	iStar4;                                         // Reserved
    uint8_t	iStar5;                                         // Reserved
    uint8_t	iRdstata_pec[ADI_BMS_SIZE_RDSTATA_PEC];         // PEC for Status Register Group A
} adi_bms_rdstata_t;

typedef struct {
    uint8_t	iVd[ADI_BMS_SIZE_VD];                           // Digital Power Supply Voltage
    uint8_t	iVa[ADI_BMS_SIZE_VA];                           // Analog Power Supply Voltage
    uint8_t	iVres[ADI_BMS_SIZE_VRES];                       // Voltage Across Resistor
    uint8_t	iRdstatb_pec[ADI_BMS_SIZE_RDSTATB_PEC];         // PEC for Status Register Group B
} adi_bms_rdstatb_t;

typedef struct {
    uint8_t	iStcr0;                                         // RDSTATC register STCR0
    uint8_t	iStcr1;                                         // RDSTATC register STCR1
    uint8_t	iStcr2;                                         // RDSTATC register STCR2
    uint8_t	iStcr3;                                         // RDSTATC register STCR3
    uint8_t	iStcr4;                                         // RDSTATC register STCR4
    uint8_t	iStcr5;                                         // RDSTATC register STCR5
    uint8_t	iRdstatc_pec[ADI_BMS_SIZE_RDSTATC_PEC];         // PEC for Status Register Group C
} adi_bms_rdstatc_t;

typedef struct {
    uint8_t	iPwmr0;                                         // PWM Register 0
    uint8_t	iPwmr1;                                         // PWM Register 1
    uint8_t	iPwmr2;                                         // PWM Register 2
    uint8_t	iPwmr3;                                         // PWM Register 3
    uint8_t	iPwmr4;                                         // PWM Register 4
    uint8_t	iPwmr5;                                         // PWM Register 5
    uint8_t	iRdpwma_pec[ADI_BMS_SIZE_RDPWMA_PEC];           // PEC for PWMR[0:5]
} adi_bms_rdpwma_t;

typedef struct {
    uint8_t	iG10v[ADI_BMS_SIZE_G10V];                       // Auxiliary Register 10
    uint8_t	iVmv[ADI_BMS_SIZE_VMV];                         // V+ to V- Measurement
    uint8_t	iVpv[ADI_BMS_SIZE_VPV];                         // V- to V- Measurement
    uint8_t	iRdauxd_pec[ADI_BMS_SIZE_RDAUXD_PEC];           // PEC for Auxiliary Register Group D
} adi_bms_rdauxd_t;

typedef struct {
    uint8_t	iSidr0;                                         // Serial ID register, byte 0
    uint8_t	iSidr1;                                         // Serial ID register, byte 1
    uint8_t	iSidr2;                                         // Serial ID register, byte 2
    uint8_t	iSidr3;                                         // Serial ID register, byte 3
    uint8_t	iSidr4;                                         // Serial ID register, byte 4
    uint8_t	iSidr5;                                         // Serial ID register, byte 5
    uint8_t	iRdsid_pec[ADI_BMS_SIZE_RDSID_PEC];             // PEC for Serial Identification Code
} adi_bms_rdsid_t;

typedef struct {
    uint8_t	iFc1v[ADI_BMS_SIZE_FC1V];                       // Filtered Cell 1 Voltage, #6, #7
    uint8_t	iFc2v[ADI_BMS_SIZE_FC2V];                       // Filtered Cell 2 Voltage, #8, #9
    uint8_t	iFc3v[ADI_BMS_SIZE_FC3V];                       // Filtered Cell 3 Voltage, #10, #11
    uint8_t	iRdfca_pec[ADI_BMS_SIZE_RDFCA_PEC];             // PEC for RDFC Register Groups, #12, #13
} adi_bms_rdfca_t;

typedef struct {
    uint8_t	iFc4v[ADI_BMS_SIZE_FC4V];                       // Filtered Cell 4 Voltage, #14, #15
    uint8_t	iFc5v[ADI_BMS_SIZE_FC5V];                       // Filtered Cell 5 Voltage, #16, #17
    uint8_t	iFc6v[ADI_BMS_SIZE_FC6V];                       // Filtered Cell 6 Voltage, #18, #19
    uint8_t	iRdfcb_pec[ADI_BMS_SIZE_RDFCB_PEC];             // PEC for RDFC Register Groups, #20, #21
} adi_bms_rdfcb_t;

typedef struct {
    uint8_t	iFc7v[ADI_BMS_SIZE_FC7V];                       // Filtered Cell 7 Voltage, #22, #23
    uint8_t	iFc8v[ADI_BMS_SIZE_FC8V];                       // Filtered Cell 8 Voltage, #24, #25
    uint8_t	iFc9v[ADI_BMS_SIZE_FC9V];                       // Filtered Cell 9 Voltage, #26, #27
    uint8_t	iRdfcc_pec[ADI_BMS_SIZE_RDFCC_PEC];             // PEC for RDFC Register Groups, #28, #29
} adi_bms_rdfcc_t;

typedef struct {
    uint8_t	iFc10v[ADI_BMS_SIZE_FC10V];                     // Filtered Cell 10 Voltage, #30, #31
    uint8_t	iFc11v[ADI_BMS_SIZE_FC11V];                     // Filtered Cell 11 Voltage, #32, #33
    uint8_t	iFc12v[ADI_BMS_SIZE_FC12V];                     // Filtered Cell 12 Voltage, #34, #35
    uint8_t	iRdfcd_pec[ADI_BMS_SIZE_RDFCD_PEC];             // PEC for RDFC Register Groups, #36, #37
} adi_bms_rdfcd_t;

typedef struct {
    uint8_t	iFc13v[ADI_BMS_SIZE_FC13V];                     // Filtered Cell 13 Voltage, #38, #39
    uint8_t	iFc14v[ADI_BMS_SIZE_FC14V];                     // Filtered Cell 14 Voltage, #40, #41
    uint8_t	iFc15v[ADI_BMS_SIZE_FC15V];                     // Filtered Cell 15 Voltage, #42, #43
    uint8_t	iRdfce_pec[ADI_BMS_SIZE_RDFCE_PEC];             // PEC for RDFC Register Groups, #44, #45
} adi_bms_rdfce_t;

typedef struct {
    uint8_t	iFc16v[ADI_BMS_SIZE_FC16V];                     // Filtered Cell 16 Voltage, #46, #47
    uint8_t	iFc17v[ADI_BMS_SIZE_FC17V];                     // Filtered Cell 17 Voltage, #48, #49
    uint8_t	iFc18v[ADI_BMS_SIZE_FC18V];                     // Filtered Cell 18 Voltage, #50, #51
    uint8_t	iRdfcf_pec[ADI_BMS_SIZE_RDFCF_PEC];             // PEC for RDFC Register Groups, #52, #53
} adi_bms_rdfcf_t;

typedef struct {
    uint8_t	iG1v[ADI_BMS_SIZE_G1V];                         // Auxiliary Register 1, #54, #55
    uint8_t	iG2v[ADI_BMS_SIZE_G2V];                         // Auxiliary Register 2, #56, #57
    uint8_t	iGa11v[ADI_BMS_SIZE_GA11V];                     // Auxiliary Register A11, #58, #59
    uint8_t	iRdauxa_pec[ADI_BMS_SIZE_RDAUXA_PEC];           // PEC for Auxiliary Register Group A, #60, #61
} adi_bms_rdauxa_t;

typedef struct {
    uint8_t	iG3v[ADI_BMS_SIZE_G3V];                         // Auxiliary Register 3, #62, #63
    uint8_t	iG4v[ADI_BMS_SIZE_G4V];                         // Auxiliary Register 4, #64, #65
    uint8_t	iGper4;                                         // GPER4 = 255, #66
    uint8_t	iGper5;                                         // GPER5 = 255, #67
    uint8_t	iRdauxe_pec[ADI_BMS_SIZE_RDAUXE_PEC];           // PEC for Auxiliary Register Group E, #68, #69
} adi_bms_rdauxe_t;

typedef struct {
    uint8_t	iS1v[ADI_BMS_SIZE_S1V];                         // Spin Voltage 1, #70, #71
    uint8_t	iS2v[ADI_BMS_SIZE_S2V];                         // Spin Voltage 2, #72, #73
    uint8_t	iS3v[ADI_BMS_SIZE_S3V];                         // Spin Voltage 3, #74, #75
    uint8_t	iRdsva_pec[ADI_BMS_SIZE_RDSVA_PEC];             // PEC for Spin Voltage Register Group A, #76, #77
} adi_bms_rdsva_t;

typedef struct {
    uint8_t	iS4v[ADI_BMS_SIZE_S4V];                         // Spin Voltage 4
    uint8_t	iS5v[ADI_BMS_SIZE_S5V];                         // Spin Voltage 5
    uint8_t	iS6v[ADI_BMS_SIZE_S6V];                         // Spin Voltage 6
    uint8_t	iRdsvb_pec[ADI_BMS_SIZE_RDSVB_PEC];             // PEC for Spin Voltage Register Group B
} adi_bms_rdsvb_t;

typedef struct {
    uint8_t	iS7v[ADI_BMS_SIZE_S7V];                         // Spin Voltage 7
    uint8_t	iS8v[ADI_BMS_SIZE_S8V];                         // Spin Voltage 8
    uint8_t	iS9v[ADI_BMS_SIZE_S9V];                         // Spin Voltage 9
    uint8_t	iRdsvc_pec[ADI_BMS_SIZE_RDSVC_PEC];             // PEC for Spin Voltage Register Group C
} adi_bms_rdsvc_t;

typedef struct {
    uint8_t	iS10v[ADI_BMS_SIZE_S10V];                       // Spin Voltage 10
    uint8_t	iS11v[ADI_BMS_SIZE_S11V];                       // Spin Voltage 11
    uint8_t	iS12v[ADI_BMS_SIZE_S12V];                       // Spin Voltage 12
    uint8_t	iRdsvd_pec[ADI_BMS_SIZE_RDSVD_PEC];             // PEC for Spin Voltage Register Group D
} adi_bms_rdsvd_t;

typedef struct {
    uint8_t	iS13v[ADI_BMS_SIZE_S13V];                       // Spin Voltage 13
    uint8_t	iS14v[ADI_BMS_SIZE_S14V];                       // Spin Voltage 14
    uint8_t	iS15v[ADI_BMS_SIZE_S15V];                       // Spin Voltage 15
    uint8_t	iRdsve_pec[ADI_BMS_SIZE_RDSVE_PEC];             // PEC for Spin Voltage Register Group E
} adi_bms_rdsve_t;

typedef struct {
    uint8_t	iS16v[ADI_BMS_SIZE_S16V];                       // Spin Voltage 16
    uint8_t	iS17v[ADI_BMS_SIZE_S17V];                       // Spin Voltage 17
    uint8_t	iS18v[ADI_BMS_SIZE_S18V];                       // Spin Voltage 18
    uint8_t	iRdsvf_pec[ADI_BMS_SIZE_RDSVF_PEC];             // PEC for Spin Voltage Register Group F
} adi_bms_rdsvf_t;

typedef struct {
    uint8_t	iCfgar0;                                        // Config Group A, register 0
    uint8_t	iCfgar1;                                        // Config Group A, register 1
    uint8_t	iCfgar2;                                        // Config Group A, register 2
    uint8_t	iCfgar3;                                        // Config Group A, register 3
    uint8_t	iCfgar4;                                        // Config Group A, register 4
    uint8_t	iCfgar5;                                        // Config Group A, register 5
    uint8_t	iRdcfga_pec[ADI_BMS_SIZE_RDCFGA_PEC];           // PEC for Cell Config Register Group A
} adi_bms_rdcfga_t;

typedef struct {
    uint8_t	iCfgbr0;                                        // Config Group B, register 0
    uint8_t	iCfgbr1;                                        // Config Group B, register 1
    uint8_t	iCfgbr2;                                        // Config Group B, register 2
    uint8_t	iCfgbr3;                                        // Config Group B, register 3
    uint8_t	iCfgbr4;                                        // Config Group B, register 4
    uint8_t	iCfgbr5;                                        // Config Group B, register 5
    uint8_t	iRdcfgb_pec[ADI_BMS_SIZE_RDCFGB_PEC];           // PEC for Cell Config Register Group B
} adi_bms_rdcfgb_t;

typedef struct {
    uint8_t	iR_g1v[ADI_BMS_SIZE_R_G1V];                     // Redundant Auxiliary Register 1
    uint8_t	iR_g2v[ADI_BMS_SIZE_R_G2V];                     // Redundant Auxiliary Register 2
    uint8_t	iR_ga11v[ADI_BMS_SIZE_R_GA11V];                 // Redundant Auxiliary Register A11
    uint8_t	iRdraxa_pec[ADI_BMS_SIZE_RDRAXA_PEC];           // PEC for Redundant Auxiliary Register Group A
} adi_bms_rdraxa_t;

typedef struct {
    uint8_t	iR_g10v[ADI_BMS_SIZE_R_G10V];                   // Redundant Auxiliary Register 10
    uint8_t	iR_g3v[ADI_BMS_SIZE_R_G3V];                     // Redundant Auxiliary Register 3
    uint8_t	iR_g4v[ADI_BMS_SIZE_R_G4V];                     // Redundant Auxiliary Register 4
    uint8_t	iRdraxd_pec[ADI_BMS_SIZE_RDRAXD_PEC];           // PEC for Redundant Auxiliary Register Group D
} adi_bms_rdraxd_t;

typedef struct {
    uint8_t	iAc1v[ADI_BMS_SIZE_AC1V];                       // Averaged Cell 1 Voltage
    uint8_t	iAc2v[ADI_BMS_SIZE_AC2V];                       // Averaged Cell 2 Voltage
    uint8_t	iAc3v[ADI_BMS_SIZE_AC3V];                       // Averaged Cell 3 Voltage
    uint8_t	iRdaca_pec[ADI_BMS_SIZE_RDACA_PEC];             // PEC for Averaged Cell Voltage Register Group A
} adi_bms_rdaca_t;

typedef struct {
    uint8_t	iAc4v[ADI_BMS_SIZE_AC4V];                       // Averaged Cell 4 Voltage
    uint8_t	iAc5v[ADI_BMS_SIZE_AC5V];                       // Averaged Cell 5 Voltage
    uint8_t	iAc6v[ADI_BMS_SIZE_AC6V];                       // Averaged Cell 6 Voltage
    uint8_t	iRdacb_pec[ADI_BMS_SIZE_RDACB_PEC];             // PEC for Averaged Cell Voltage Register Group B
} adi_bms_rdacb_t;

typedef struct {
    uint8_t	iAc7v[ADI_BMS_SIZE_AC7V];                       // Averaged Cell 7 Voltage
    uint8_t	iAc8v[ADI_BMS_SIZE_AC8V];                       // Averaged Cell 8 Voltage
    uint8_t	iAc9v[ADI_BMS_SIZE_AC9V];                       // Averaged Cell 9 Voltage
    uint8_t	iRdacc_pec[ADI_BMS_SIZE_RDACC_PEC];             // PEC for Averaged Cell Voltage Register Group C
} adi_bms_rdacc_t;

typedef struct {
    uint8_t	iAc10v[ADI_BMS_SIZE_AC10V];                     // Averaged Cell 10 Voltage
    uint8_t	iAc11v[ADI_BMS_SIZE_AC11V];                     // Averaged Cell 11 Voltage
    uint8_t	iAc12v[ADI_BMS_SIZE_AC12V];                     // Averaged Cell 12 Voltage
    uint8_t	iRdacd_pec[ADI_BMS_SIZE_RDACD_PEC];             // PEC for Averaged Cell Voltage Register Group D
} adi_bms_rdacd_t;

typedef struct {
    uint8_t	iAc13v[ADI_BMS_SIZE_AC13V];                     // Averaged Cell 13 Voltage
    uint8_t	iAc14v[ADI_BMS_SIZE_AC14V];                     // Averaged Cell 14 Voltage
    uint8_t	iAc15v[ADI_BMS_SIZE_AC15V];                     // Averaged Cell 15 Voltage
    uint8_t	iRdace_pec[ADI_BMS_SIZE_RDACE_PEC];             // PEC for Averaged Cell Voltage Register Group E
} adi_bms_rdace_t;

typedef struct {
    uint8_t	iAc16v[ADI_BMS_SIZE_AC16V];                     // Averaged Cell 16 Voltage
    uint8_t	iAc17v[ADI_BMS_SIZE_AC17V];                     // Averaged Cell 17 Voltage
    uint8_t	iAc18v[ADI_BMS_SIZE_AC18V];                     // Averaged Cell 18 Voltage
    uint8_t	iRdacf_pec[ADI_BMS_SIZE_RDACF_PEC];             // PEC for Averaged Cell Voltage Register Group F
} adi_bms_rdacf_t;

typedef struct {
    uint8_t	iC1v[ADI_BMS_SIZE_C1V];                         // Cell 1 Voltage
    uint8_t	iC2v[ADI_BMS_SIZE_C2V];                         // Cell 2 Voltage
    uint8_t	iC3v[ADI_BMS_SIZE_C3V];                         // Cell 3 Voltage
    uint8_t	iRdcva_pec[ADI_BMS_SIZE_RDCVA_PEC];             // PEC for Cell Voltage Register Group A
} adi_bms_rdcva_t;

typedef struct {
    uint8_t	iC4v[ADI_BMS_SIZE_C4V];                         // Cell 4 Voltage
    uint8_t	iC5v[ADI_BMS_SIZE_C5V];                         // Cell 5 Voltage
    uint8_t	iC6v[ADI_BMS_SIZE_C6V];                         // Cell 6 Voltage
    uint8_t	iRdcvb_pec[ADI_BMS_SIZE_RDCVB_PEC];             // PEC for Cell Voltage Register Group B
} adi_bms_rdcvb_t;

typedef struct {
    uint8_t	iC7v[ADI_BMS_SIZE_C7V];                         // Cell 7 Voltage
    uint8_t	iC8v[ADI_BMS_SIZE_C8V];                         // Cell 8 Voltage
    uint8_t	iC9v[ADI_BMS_SIZE_C9V];                         // Cell 9 Voltage
    uint8_t	iRdcvc_pec[ADI_BMS_SIZE_RDCVC_PEC];             // PEC for Cell Voltage Register Group C
} adi_bms_rdcvc_t;

typedef struct {
    uint8_t	iC10v[ADI_BMS_SIZE_C10V];                       // Cell 10 Voltage
    uint8_t	iC11v[ADI_BMS_SIZE_C11V];                       // Cell 11 Voltage
    uint8_t	iC12v[ADI_BMS_SIZE_C12V];                       // Cell 12 Voltage
    uint8_t	iRdcvd_pec[ADI_BMS_SIZE_RDCVD_PEC];             // PEC for Cell Voltage Register Group D
} adi_bms_rdcvd_t;

typedef struct {
    uint8_t	iC13v[ADI_BMS_SIZE_C13V];                       // Cell 13 Voltage
    uint8_t	iC14v[ADI_BMS_SIZE_C14V];                       // Cell 14 Voltage
    uint8_t	iC15v[ADI_BMS_SIZE_C15V];                       // Cell 15 Voltage
    uint8_t	iRdcve_pec[ADI_BMS_SIZE_RDCVE_PEC];             // PEC for Cell Voltage Register Group E
} adi_bms_rdcve_t;

typedef struct {
    uint8_t	iC16v[ADI_BMS_SIZE_C16V];                       // Cell 16 Voltage
    uint8_t	iC17v[ADI_BMS_SIZE_C17V];                       // Cell 17 Voltage
    uint8_t	iC18v[ADI_BMS_SIZE_C18V];                       // Cell 18 Voltage
    uint8_t	iRdcvf_pec[ADI_BMS_SIZE_RDCVF_PEC];             // PEC for Cell Voltage Register Group F
} adi_bms_rdcvf_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdstata_t         Rdstata;
    adi_bms_rdstatb_t         Rdstatb;
    adi_bms_rdstata_t         Rdstata_1;
    adi_bms_rdstatb_t         Rdstatb_1;
    adi_bms_rdstatc_t         Rdstatc;
    adi_bms_rdstatc_t         Rdstatc_1;
    adi_bms_rdstatc_t         Rdstatc_2;
    adi_bms_rdstatc_t         Rdstatc_3;
    adi_bms_rdstatc_t         Rdstatc_4;
} adi_bms_init_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdstatc_t         Rdstatc_5;
    adi_bms_rdstatc_t         Rdstatc_6;
    adi_bms_rdpwma_t          Rdpwma;
    adi_bms_rdpwma_t          Rdpwma_1;
    adi_bms_rdpwma_t          Rdpwma_2;
    adi_bms_rdstatc_t         Rdstatc_7;
    adi_bms_rdauxd_t          Rdauxd;
    adi_bms_rdsid_t           Rdsid;
    adi_bms_rdstatc_t         Rdstatc_8;
} adi_bms_init_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdfca_t           Rdfca;
    adi_bms_rdfcb_t           Rdfcb;
    adi_bms_rdfcc_t           Rdfcc;
    adi_bms_rdfcd_t           Rdfcd;
    adi_bms_rdfce_t           Rdfce;
    adi_bms_rdfcf_t           Rdfcf;
    adi_bms_rdauxa_t          Rdauxa;
    adi_bms_rdauxe_t          Rdauxe;
    adi_bms_rdsva_t           Rdsva;
} adi_bms_base_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdsvb_t           Rdsvb;
    adi_bms_rdsvc_t           Rdsvc;
    adi_bms_rdsvd_t           Rdsvd;
    adi_bms_rdsve_t           Rdsve;
    adi_bms_rdsvf_t           Rdsvf;
    adi_bms_rdcfga_t          Rdcfga;
    adi_bms_rdcfgb_t          Rdcfgb;
    adi_bms_rdstata_t         Rdstata;
    adi_bms_rdstatb_t         Rdstatb;
} adi_bms_base_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdstatc_t         Rdstatc;
    adi_bms_rdraxa_t          Rdraxa;
    adi_bms_rdraxd_t          Rdraxd;
} adi_bms_base_pkt_2_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdaca_t           Rdaca;
    adi_bms_rdacb_t           Rdacb;
    adi_bms_rdacc_t           Rdacc;
    adi_bms_rdacd_t           Rdacd;
    adi_bms_rdace_t           Rdace;
    adi_bms_rdacf_t           Rdacf;
    adi_bms_rdsva_t           Rdsva;
    adi_bms_rdsvb_t           Rdsvb;
    adi_bms_rdsvc_t           Rdsvc;
} adi_bms_latent1_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdsvd_t           Rdsvd;
    adi_bms_rdsve_t           Rdsve;
    adi_bms_rdsvf_t           Rdsvf;
    adi_bms_rdstatc_t         Rdstatc;
} adi_bms_latent1_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdaca_t           Rdaca;
    adi_bms_rdacb_t           Rdacb;
    adi_bms_rdacc_t           Rdacc;
    adi_bms_rdacd_t           Rdacd;
    adi_bms_rdace_t           Rdace;
    adi_bms_rdacf_t           Rdacf;
    adi_bms_rdsva_t           Rdsva;
    adi_bms_rdsvb_t           Rdsvb;
    adi_bms_rdsvc_t           Rdsvc;
} adi_bms_latent2_pkt_0_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdsvd_t           Rdsvd;
    adi_bms_rdsve_t           Rdsve;
    adi_bms_rdsvf_t           Rdsvf;
    adi_bms_rdstatc_t         Rdstatc;
} adi_bms_latent2_pkt_1_t;

typedef struct {
    adi_bms_packetheader_t    Packetheader;
    adi_bms_rdcva_t           Rdcva;
    adi_bms_rdcvb_t           Rdcvb;
    adi_bms_rdcvc_t           Rdcvc;
    adi_bms_rdcvd_t           Rdcvd;
    adi_bms_rdcve_t           Rdcve;
    adi_bms_rdcvf_t           Rdcvf;
} adi_bms_monitor_pkt_0_t;

typedef struct {
    uint8_t	iMcmd_0_assert_threshold[ADI_BMS_SIZE_MCMD_0_ASSERT_THRESHOLD]; // mcmd_0_assert_threshold
    uint8_t	iBitmask[ADI_BMS_SIZE_BITMASK];                 // bitmask
} adi_bms_monitor_params_t;
#else   /* Not supported */
#endif



#endif  /* ADI_BMS_TYPES_H_ */
