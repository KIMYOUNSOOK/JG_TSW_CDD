/*******************************************************************************
* Copyright (c) 2020 Analog Devices, Inc. All Rights Reserved.
* This software is proprietary and confidential to Analog Devices, Inc. and its licensors.
*******************************************************************************/

#include <stdint.h>

void adi_bms_GetMngrOPFW210Ptr(uint8_t **pFPA, uint32_t *pFPA_len);