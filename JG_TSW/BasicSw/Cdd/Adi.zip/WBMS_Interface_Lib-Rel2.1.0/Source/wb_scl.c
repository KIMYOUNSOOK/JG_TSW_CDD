/******************************************************************************
 * @file    wb_scl.c
 *
 * @brief   WIL FE Safety Communications Layer
 *
 * Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
 * This software is proprietary to Analog Devices, Inc. and its licensors.
 *****************************************************************************/

#include "wb_scl.h"
#include "wb_scl_fusa.h"
#include "wb_scl_msg_defs.h"
#include "adi_wil_pack.h"
#include "wb_assl_fusa.h"
#include "wb_wil_msg_header.h"
#include <string.h>

/******************************************************************************
 *   Defines
 *****************************************************************************/

/* 21-bit reversed version of (1u << 5u) */
#define WB_SCL_CRC_INITIAL_SEED_VALUE            (0x8000u)

#define WB_SCL_HDR_SOURCE_ID_OFFSET              (0u)
#define WB_SCL_HDR_DEST_ID_OFFSET                (1u)
#define WB_SCL_HDR_SEQ_NUM_OFFSET                (2u)
#define WB_SCL_HDR_MSG_TYPE_OFFSET               (3u)
#define WB_SCL_HDR_PAYLOAD_LEN_OFFSET            (4u)
#define WB_SCL_PAYLOAD_OFFSET                    (WB_SCL_MSG_HDR_LEN)
#define WB_WIL_DEV_HOST_CONTROLLER               (230u)
#define WB_WIL_DEV_ALL_NODES                     (255u)

/******************************************************************************
 *  Static function declarations
 *****************************************************************************/

static bool wb_scl_ValidateCrc (uint8_t const * const pBuffer,
                                uint8_t iLength);

static void wb_scl_ComputeCrc (uint8_t const * const pBuffer,
                               uint8_t iLength,
                               uint32_t * pCrc);

static void wb_scl_PackCrc (uint8_t * const pBuffer,
                            uint32_t const * const pCrc);

static void wb_scl_UnpackCrc (uint8_t const * const pBuffer,
                              uint32_t * const pCrc);

static adi_wil_safety_internals_t * wb_scl_GetSafetyInternalsPointer (adi_wil_pack_t const * const pPack);

static void wb_scl_ReadSCLHeader (uint8_t const * const pSCLFrame,
                                  wb_msg_header_t * pMsgHeader,
                                  uint8_t * pDestDeviceId);

static void wb_scl_WriteSCLHeader (uint8_t * const pSCLFrame,
                                   wb_msg_header_t const * const pMsgHeader);

static bool wb_scl_ValidateIncomingMessageHeader (wb_msg_header_t const * const pMsgHeader,
                                                  uint8_t iDestDeviceId,
                                                  uint8_t iSourceDeviceId);

static bool wb_scl_ValidateOutgoingMessageHeader (wb_msg_header_t const * const pMsgHeader);

static bool wb_scl_ValidateHandleSCLFrameParameters (adi_wil_safety_internals_t const * const pInternals,
                                                     uint8_t iDeviceId,
                                                     uint8_t iLength,
                                                     uint8_t const * const pData);

static uint32_t wb_scl_BitReverseCrc (uint32_t iCrc);

/******************************************************************************
 *   Public function definitions
 *****************************************************************************/

void wb_scl_HandleSCLFrame (adi_wil_pack_t const * const pPack,
                            uint8_t iDeviceId,
                            uint8_t iLength,
                            uint8_t const * const pData)
{
    /* Static variable for retrieving safety internals pointer */
    adi_wil_safety_internals_t * pInternals;

    /* Destination device ID read from the SCL frame */
    uint8_t iDestDeviceId;

    /* SCL message header */
    wb_msg_header_t MsgHeader;

    /* Retrieve safety internals pointer */
    pInternals = wb_scl_GetSafetyInternalsPointer (pPack);

    /* Validate input parameters */
    if (!wb_scl_ValidateHandleSCLFrameParameters (pInternals, iDeviceId, iLength, pData))
    {
        /* SCL frame error - report to ASSL */
        wb_assl_ReportValidationError (pPack);
    }
    else
    {
        /* Copy out the SCL frame to ASSL memory before parsing */
        (void) memcpy (&pInternals->ASSL.iSCLFrame [0], pData, iLength);

        /* Extract SCL frame header fields from the SCL frame */
        wb_scl_ReadSCLHeader (&pInternals->ASSL.iSCLFrame [0], &MsgHeader, &iDestDeviceId);

        /* Validate SCL frame header fields and CRC */
        if (!wb_scl_ValidateIncomingMessageHeader (&MsgHeader, iDestDeviceId, iDeviceId) ||
            !wb_scl_ValidateCrc (&pInternals->ASSL.iSCLFrame [0], (uint8_t) (WB_SCL_MSG_HDR_LEN + MsgHeader.iPayloadLength)))
        {
            /* SCL frame error - report to ASSL */
            wb_assl_ReportValidationError (pPack);
        }
        else if (MsgHeader.iPayloadLength > 0u)
        {
            /* Validated frame with non-zero payload length. Pass on to ASSL
             * for processing */
            wb_assl_HandleValidatedSCLFrame (pInternals, &MsgHeader, &pInternals->ASSL.iSCLFrame [WB_SCL_PAYLOAD_OFFSET]);
        }
        else
        {
            /* Validated frame with zero payload length. Pass on to ASSL for
             * processing */
            wb_assl_HandleValidatedSCLFrame (pInternals, &MsgHeader, (void*) 0);
        }
    }
}

bool wb_scl_WrapSCLFrame (wb_msg_header_t const * const pMsgHeader,
                          uint8_t * const pBuffer)
{
    /* Boolean result indicating if the SCL frame was written to
     * successfully */
    bool bComplete;

    /* CRC of message and header to write into the SCL frame */
    uint32_t crc;

    /* Validate input parameters */
    /* Validate input message header parameters */
    if ((pBuffer == (void *) 0) ||
        (pMsgHeader == (void *) 0) ||
        !wb_scl_ValidateOutgoingMessageHeader (pMsgHeader))
    {
        bComplete = false;
    }
    else
    {
        /* Write SCL frame header */
        wb_scl_WriteSCLHeader (pBuffer, pMsgHeader);

        /* Compute CRC over message data and header of the SCL frame */
        wb_scl_ComputeCrc (pBuffer, (uint8_t) (WB_SCL_MSG_HDR_LEN + pMsgHeader->iPayloadLength), &crc);

        /* Skip over the data block and write the CRC */
        wb_scl_PackCrc (&pBuffer [WB_SCL_MSG_HDR_LEN + pMsgHeader->iPayloadLength], &crc);

        bComplete = true;
    }

    return bComplete;
}

/******************************************************************************
 *  Static function definitions
 *****************************************************************************/

static bool wb_scl_ValidateCrc (uint8_t const * const pBuffer,
                                uint8_t iLength)
{
    /* Computed CRC value */
    uint32_t crc1;

    /* CRC value unpacked from the SCL Frame */
    uint32_t crc2;

    /* Initialize local variables */
    crc1 = 0u;
    crc2 = 0u;

    /* Compute the CRC for the given input data */
    wb_scl_ComputeCrc (pBuffer, iLength, &crc1);

    /* Unpack the CRC from the SCL frame */
    wb_scl_UnpackCrc (&pBuffer [iLength], &crc2);

    /* Check if CRC value in the SCL frame matches the computed value */
    return (crc1 == crc2);
}

static void wb_scl_ComputeCrc (uint8_t const * const pBuffer,
                               uint8_t iLength,
                               uint32_t * pCrc)
{
    /* CRC look-up table for 21-bit CRC */
    static const uint32_t iSclCrcLUT[] =
    {
        0x000000u, 0x122D5Bu, 0x19E5D9u, 0x0BC882u, 0x0E74DDu, 0x1C5986u, 0x179104u, 0x05BC5Fu,
        0x1CE9BAu, 0x0EC4E1u, 0x050C63u, 0x172138u, 0x129D67u, 0x00B03Cu, 0x0B78BEu, 0x1955E5u,
        0x046C1Bu, 0x164140u, 0x1D89C2u, 0x0FA499u, 0x0A18C6u, 0x18359Du, 0x13FD1Fu, 0x01D044u,
        0x1885A1u, 0x0AA8FAu, 0x016078u, 0x134D23u, 0x16F17Cu, 0x04DC27u, 0x0F14A5u, 0x1D39FEu,
        0x08D836u, 0x1AF56Du, 0x113DEFu, 0x0310B4u, 0x06ACEBu, 0x1481B0u, 0x1F4932u, 0x0D6469u,
        0x14318Cu, 0x061CD7u, 0x0DD455u, 0x1FF90Eu, 0x1A4551u, 0x08680Au, 0x03A088u, 0x118DD3u,
        0x0CB42Du, 0x1E9976u, 0x1551F4u, 0x077CAFu, 0x02C0F0u, 0x10EDABu, 0x1B2529u, 0x090872u,
        0x105D97u, 0x0270CCu, 0x09B84Eu, 0x1B9515u, 0x1E294Au, 0x0C0411u, 0x07CC93u, 0x15E1C8u,
        0x11B06Cu, 0x039D37u, 0x0855B5u, 0x1A78EEu, 0x1FC4B1u, 0x0DE9EAu, 0x062168u, 0x140C33u,
        0x0D59D6u, 0x1F748Du, 0x14BC0Fu, 0x069154u, 0x032D0Bu, 0x110050u, 0x1AC8D2u, 0x08E589u,
        0x15DC77u, 0x07F12Cu, 0x0C39AEu, 0x1E14F5u, 0x1BA8AAu, 0x0985F1u, 0x024D73u, 0x106028u,
        0x0935CDu, 0x1B1896u, 0x10D014u, 0x02FD4Fu, 0x074110u, 0x156C4Bu, 0x1EA4C9u, 0x0C8992u,
        0x19685Au, 0x0B4501u, 0x008D83u, 0x12A0D8u, 0x171C87u, 0x0531DCu, 0x0EF95Eu, 0x1CD405u,
        0x0581E0u, 0x17ACBBu, 0x1C6439u, 0x0E4962u, 0x0BF53Du, 0x19D866u, 0x1210E4u, 0x003DBFu,
        0x1D0441u, 0x0F291Au, 0x04E198u, 0x16CCC3u, 0x13709Cu, 0x015DC7u, 0x0A9545u, 0x18B81Eu,
        0x01EDFBu, 0x13C0A0u, 0x180822u, 0x0A2579u, 0x0F9926u, 0x1DB47Du, 0x167CFFu, 0x0451A4u,
        0x1EDFB7u, 0x0CF2ECu, 0x073A6Eu, 0x151735u, 0x10AB6Au, 0x028631u, 0x094EB3u, 0x1B63E8u,
        0x02360Du, 0x101B56u, 0x1BD3D4u, 0x09FE8Fu, 0x0C42D0u, 0x1E6F8Bu, 0x15A709u, 0x078A52u,
        0x1AB3ACu, 0x089EF7u, 0x035675u, 0x117B2Eu, 0x14C771u, 0x06EA2Au, 0x0D22A8u, 0x1F0FF3u,
        0x065A16u, 0x14774Du, 0x1FBFCFu, 0x0D9294u, 0x082ECBu, 0x1A0390u, 0x11CB12u, 0x03E649u,
        0x160781u, 0x042ADAu, 0x0FE258u, 0x1DCF03u, 0x18735Cu, 0x0A5E07u, 0x019685u, 0x13BBDEu,
        0x0AEE3Bu, 0x18C360u, 0x130BE2u, 0x0126B9u, 0x049AE6u, 0x16B7BDu, 0x1D7F3Fu, 0x0F5264u,
        0x126B9Au, 0x0046C1u, 0x0B8E43u, 0x19A318u, 0x1C1F47u, 0x0E321Cu, 0x05FA9Eu, 0x17D7C5u,
        0x0E8220u, 0x1CAF7Bu, 0x1767F9u, 0x054AA2u, 0x00F6FDu, 0x12DBA6u, 0x191324u, 0x0B3E7Fu,
        0x0F6FDBu, 0x1D4280u, 0x168A02u, 0x04A759u, 0x011B06u, 0x13365Du, 0x18FEDFu, 0x0AD384u,
        0x138661u, 0x01AB3Au, 0x0A63B8u, 0x184EE3u, 0x1DF2BCu, 0x0FDFE7u, 0x041765u, 0x163A3Eu,
        0x0B03C0u, 0x192E9Bu, 0x12E619u, 0x00CB42u, 0x05771Du, 0x175A46u, 0x1C92C4u, 0x0EBF9Fu,
        0x17EA7Au, 0x05C721u, 0x0E0FA3u, 0x1C22F8u, 0x199EA7u, 0x0BB3FCu, 0x007B7Eu, 0x125625u,
        0x07B7EDu, 0x159AB6u, 0x1E5234u, 0x0C7F6Fu, 0x09C330u, 0x1BEE6Bu, 0x1026E9u, 0x020BB2u,
        0x1B5E57u, 0x09730Cu, 0x02BB8Eu, 0x1096D5u, 0x152A8Au, 0x0707D1u, 0x0CCF53u, 0x1EE208u,
        0x03DBF6u, 0x11F6ADu, 0x1A3E2Fu, 0x081374u, 0x0DAF2Bu, 0x1F8270u, 0x144AF2u, 0x0667A9u,
        0x1F324Cu, 0x0D1F17u, 0x06D795u, 0x14FACEu, 0x114691u, 0x036BCAu, 0x08A348u, 0x1A8E13u
    };

    /* Lookup table index computed using input data byte */
    uint8_t iLUTIndex;

    /* Computed 21-bit CRC value */
    uint32_t iCrcValue;

    /* Initialize the CRC value with the initial seed */
    iCrcValue = WB_SCL_CRC_INITIAL_SEED_VALUE;

    for (uint8_t i = 0u; i < iLength; i++)
    {
        /* XOR-in next input byte into LSB of CRC and get this LSB, that's our
         * new intermediate dividend */
        iLUTIndex = (uint8_t) ((iCrcValue ^ pBuffer [i]) & 0xffu);

        /* Shift out the LSB used for division per look-up table and XOR with
         * the remainder */
        iCrcValue = ((iCrcValue >> 8u) ^ iSclCrcLUT [iLUTIndex]) & 0x1fffffu;
    }

    /* Reverse the bits in the CRC to produce corrected CRC value*/
    *pCrc = wb_scl_BitReverseCrc (iCrcValue);
}

static void wb_scl_PackCrc (uint8_t * const pBuffer, uint32_t const * const pCrc)
{
    /* Write CRC value in big-endian format */
    pBuffer [0] = (uint8_t) ((*pCrc >> 16u) & 0xffu);
    pBuffer [1] = (uint8_t) ((*pCrc >> 8u) & 0xffu);
    pBuffer [2] = (uint8_t) ((*pCrc >> 0u) & 0xffu);
}

static void wb_scl_UnpackCrc (uint8_t const * const pBuffer, uint32_t * const pCrc)
{
    /* Unpack CRC value in big-endian format */
    *pCrc = (((((uint32_t) pBuffer [0]) << 16u) & 0xff0000u) |
             ((((uint32_t) pBuffer [1]) << 8u) & 0x00ff00u) |
             ((((uint32_t) pBuffer [2]) << 0u) & 0x0000ffu));
}

static adi_wil_safety_internals_t * wb_scl_GetSafetyInternalsPointer (adi_wil_pack_t const * const pPack)
{
    /* Return value of this method */
    adi_wil_safety_internals_t * pInternals;

    /* Initialize local variable to NULL */
    pInternals = (void *) 0;

    /* Check pack instance before dereferencing */
    if ((void *) 0 != pPack)
    {
        /* Assign safety internals pointer to local variable */
        pInternals = pPack->pSafetyInternals;
    }

    /* Return local variable pointer to safety internals */
    return pInternals;
}

static void wb_scl_ReadSCLHeader (uint8_t const * const pSCLFrame,
                                  wb_msg_header_t * pMsgHeader,
                                  uint8_t * pDestDeviceId)
{
    /* Unpack source device ID */
    pMsgHeader->iSourceDeviceId = pSCLFrame [WB_SCL_HDR_SOURCE_ID_OFFSET];

    /* Unpack destination device ID - this should match the host controller
     * ID */
    *pDestDeviceId = pSCLFrame [WB_SCL_HDR_DEST_ID_OFFSET];

    /* Unpack sequence number of the message */
    pMsgHeader->iSequenceNumber = pSCLFrame [WB_SCL_HDR_SEQ_NUM_OFFSET];

    /* Unpack message type */
    pMsgHeader->iMessageType = pSCLFrame [WB_SCL_HDR_MSG_TYPE_OFFSET];

    /* Unpack the length of the SCL payload excluding the header and CRC */
    pMsgHeader->iPayloadLength = pSCLFrame [WB_SCL_HDR_PAYLOAD_LEN_OFFSET];
}

static void wb_scl_WriteSCLHeader (uint8_t * const pSCLFrame,
                                   wb_msg_header_t const * const pMsgHeader)
{
    /* Pack source device ID for outgoing messages from the host controller */
    pSCLFrame [WB_SCL_HDR_SOURCE_ID_OFFSET] = WB_WIL_DEV_HOST_CONTROLLER;

    /* Pack destination device ID */
    pSCLFrame [WB_SCL_HDR_DEST_ID_OFFSET] = pMsgHeader->iSourceDeviceId;

    /* Pack sequence number of the message */
    pSCLFrame [WB_SCL_HDR_SEQ_NUM_OFFSET] = pMsgHeader->iSequenceNumber;

    /* Pack message type */
    pSCLFrame [WB_SCL_HDR_MSG_TYPE_OFFSET] = pMsgHeader->iMessageType;

    /* Pack the length of the SCL payload excluding the header and CRC */
    pSCLFrame [WB_SCL_HDR_PAYLOAD_LEN_OFFSET] = pMsgHeader->iPayloadLength;
}

static bool wb_scl_ValidateIncomingMessageHeader (wb_msg_header_t const * const pMsgHeader,
                                                  uint8_t iDestDeviceId,
                                                  uint8_t iSourceDeviceId)
{
    /* Returns true if all parameters are within valid range */
    /* Checks if SCL frame header is valid for an incoming message from a
     * safety CPU */
    /* Ensure SCL payload length is in valid range */
    /* Verify that device ID in the SCL header matches originating device ID */
    return ((pMsgHeader->iPayloadLength <= WB_SCL_PAYLOAD_LEN_MAX) &&
            (iDestDeviceId == WB_WIL_DEV_HOST_CONTROLLER) &&
            (pMsgHeader->iSourceDeviceId == iSourceDeviceId));
}

static bool wb_scl_ValidateOutgoingMessageHeader (wb_msg_header_t const * const pMsgHeader)
{
    /* Returns true if all parameters are within valid range */
    /* Checks if message header is valid for an outgoing message to one or all
     * safety CPUs */
    /* Checks if message is addressed to a valid node ID */
    /* Checks if SCL payload length exceeds maximum value */
    return (((pMsgHeader->iSourceDeviceId < ADI_WIL_MAX_NODES) || (pMsgHeader->iSourceDeviceId == WB_WIL_DEV_ALL_NODES)) &&
             (pMsgHeader->iPayloadLength <= WB_SCL_PAYLOAD_LEN_MAX));
}

static bool wb_scl_ValidateHandleSCLFrameParameters (adi_wil_safety_internals_t const * const pInternals,
                                                     uint8_t iDeviceId,
                                                     uint8_t iLength,
                                                     uint8_t const * const pData)
{
    /* Returns true if all parameters are within valid range */
    /* Ensure input pointers are not NULL */
    /* Ensure source device is a valid node or manager */
    /* Ensure length is within valid range */
    return ((pInternals != (void *) 0) &&
            (pData != (void *) 0) &&
            ((iDeviceId < ADI_WIL_MAX_NODES) || (iDeviceId == WB_SCL_MANAGER_0_DEVICE_ID) || (iDeviceId == WB_SCL_MANAGER_1_DEVICE_ID)) &&
            (iLength >= WB_SCL_FRAME_LEN_MIN) &&
            (iLength <= WB_SCL_FRAME_LEN_MAX));
}

static uint32_t wb_scl_BitReverseCrc (uint32_t iCrc)
{
    /* Look-up table containing the inverted bits for each possible value */
    static const uint32_t BitReverseLUT [] =
    {
      0x00u, 0x80u, 0x40u, 0xC0u, 0x20u, 0xA0u, 0x60u, 0xE0u,
      0x10u, 0x90u, 0x50u, 0xD0u, 0x30u, 0xB0u, 0x70u, 0xF0u,
      0x08u, 0x88u, 0x48u, 0xC8u, 0x28u, 0xA8u, 0x68u, 0xE8u,
      0x18u, 0x98u, 0x58u, 0xD8u, 0x38u, 0xB8u, 0x78u, 0xF8u,
      0x04u, 0x84u, 0x44u, 0xC4u, 0x24u, 0xA4u, 0x64u, 0xE4u,
      0x14u, 0x94u, 0x54u, 0xD4u, 0x34u, 0xB4u, 0x74u, 0xF4u,
      0x0Cu, 0x8Cu, 0x4Cu, 0xCCu, 0x2Cu, 0xACu, 0x6Cu, 0xECu,
      0x1Cu, 0x9Cu, 0x5Cu, 0xDCu, 0x3Cu, 0xBCu, 0x7Cu, 0xFCu,
      0x02u, 0x82u, 0x42u, 0xC2u, 0x22u, 0xA2u, 0x62u, 0xE2u,
      0x12u, 0x92u, 0x52u, 0xD2u, 0x32u, 0xB2u, 0x72u, 0xF2u,
      0x0Au, 0x8Au, 0x4Au, 0xCAu, 0x2Au, 0xAAu, 0x6Au, 0xEAu,
      0x1Au, 0x9Au, 0x5Au, 0xDAu, 0x3Au, 0xBAu, 0x7Au, 0xFAu,
      0x06u, 0x86u, 0x46u, 0xC6u, 0x26u, 0xA6u, 0x66u, 0xE6u,
      0x16u, 0x96u, 0x56u, 0xD6u, 0x36u, 0xB6u, 0x76u, 0xF6u,
      0x0Eu, 0x8Eu, 0x4Eu, 0xCEu, 0x2Eu, 0xAEu, 0x6Eu, 0xEEu,
      0x1Eu, 0x9Eu, 0x5Eu, 0xDEu, 0x3Eu, 0xBEu, 0x7Eu, 0xFEu,
      0x01u, 0x81u, 0x41u, 0xC1u, 0x21u, 0xA1u, 0x61u, 0xE1u,
      0x11u, 0x91u, 0x51u, 0xD1u, 0x31u, 0xB1u, 0x71u, 0xF1u,
      0x09u, 0x89u, 0x49u, 0xC9u, 0x29u, 0xA9u, 0x69u, 0xE9u,
      0x19u, 0x99u, 0x59u, 0xD9u, 0x39u, 0xB9u, 0x79u, 0xF9u,
      0x05u, 0x85u, 0x45u, 0xC5u, 0x25u, 0xA5u, 0x65u, 0xE5u,
      0x15u, 0x95u, 0x55u, 0xD5u, 0x35u, 0xB5u, 0x75u, 0xF5u,
      0x0Du, 0x8Du, 0x4Du, 0xCDu, 0x2Du, 0xADu, 0x6Du, 0xEDu,
      0x1Du, 0x9Du, 0x5Du, 0xDDu, 0x3Du, 0xBDu, 0x7Du, 0xFDu,
      0x03u, 0x83u, 0x43u, 0xC3u, 0x23u, 0xA3u, 0x63u, 0xE3u,
      0x13u, 0x93u, 0x53u, 0xD3u, 0x33u, 0xB3u, 0x73u, 0xF3u,
      0x0Bu, 0x8Bu, 0x4Bu, 0xCBu, 0x2Bu, 0xABu, 0x6Bu, 0xEBu,
      0x1Bu, 0x9Bu, 0x5Bu, 0xDBu, 0x3Bu, 0xBBu, 0x7Bu, 0xFBu,
      0x07u, 0x87u, 0x47u, 0xC7u, 0x27u, 0xA7u, 0x67u, 0xE7u,
      0x17u, 0x97u, 0x57u, 0xD7u, 0x37u, 0xB7u, 0x77u, 0xF7u,
      0x0Fu, 0x8Fu, 0x4Fu, 0xCFu, 0x2Fu, 0xAFu, 0x6Fu, 0xEFu,
      0x1Fu, 0x9Fu, 0x5Fu, 0xDFu, 0x3Fu, 0xBFu, 0x7Fu, 0xFFu
    };

    /* Look up each byte of the 32-bit value, invert the bits and put in the
     * reflected position. Shift down by 11-bits (32 minus 21 bits) to restore
     * 21-bit CRC */
    return ((BitReverseLUT [(iCrc >> 0u) & 0xFFu] << 24u) |
            (BitReverseLUT [(iCrc >> 8u) & 0xFFu] << 16u) |
            (BitReverseLUT [(iCrc >> 16u) & 0xFFu] << 8u) |
            (BitReverseLUT [(iCrc >> 24u) & 0xFFu] << 0u)) >> 11u;
}
