/******************************************************************************
 * Copyright (c) 2022 Analog Devices, Inc. All Rights Reserved.
 * This software is proprietary to Analog Devices, Inc. and its licensors.
 *****************************************************************************/

/* This is an auto-generated file - please do not edit */

#ifndef WB_WIL_VERSION_H
#define WB_WIL_VERSION_H

#define WIL_VERSION_MAJOR 2
#define WIL_VERSION_MINOR 1
#define WIL_VERSION_PATCH 0
#define WIL_VERSION_BUILD 73

#endif /* WB_WIL_VERSION_H */
